using System.Runtime.InteropServices;
public static class GlobalMembersY_tab
{
//C++ TO C# CONVERTER NOTE: 'extern' variable declarations are not required in C#:
	//extern YYSTYPE yylval;
}

//C++ TO C# CONVERTER TODO TASK: Unions are not supported in C#, but the following union can be simulated with the StructLayout and FieldOffset attributes.
//ORIGINAL LINE: typedef union
[StructLayout(LayoutKind.Explicit)]
public struct YYSTYPE
{
 [FieldOffset(0)]
 public int vInt;
 [FieldOffset(0)]
 public int vLong;
 [FieldOffset(0)]
 public float vFloat;
 [FieldOffset(0)]
 public string pChar;
#if Word_AlternateDefinition1
 [FieldOffset(0)]
 public ushort vWord;
#elif Word_AlternateDefinition2
 [FieldOffset(0)]
 public ushort vWord;
#endif
#if Byte_AlternateDefinition1
 [FieldOffset(0)]
 public byte pByte;
#elif Byte_AlternateDefinition2
 [FieldOffset(0)]
 public byte pByte;
#endif
}
#define WRONGTOKEN
#define NIL
#define IF
#define THEN
#define ELSE
#define ELSEIF
#define WHILE
#define DO
#define REPEAT
#define UNTIL
#define END
#define RETURN
#define LOCAL
#define NUMBER
#define FUNCTION
#define STRING
#define NAME
#define DEBUG
#define AND
#define OR
#define NE
#define LE
#define GE
#define CONC
#define UNARY
#define NOT
