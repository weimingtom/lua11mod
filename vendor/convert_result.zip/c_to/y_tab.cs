using System.Runtime.InteropServices;
using System;
public static class GlobalMembersY_tab
{

	//# line 2 "lua.stx"

	public static string rcs_luastx = "$Id: lua.stx,v 2.4 1994/04/20 16:22:21 celes Exp $";




	#define LISTING

	#if ! GAPCODE
	#define GAPCODE
	#endif
	#if Word_AlternateDefinition1
	internal static ushort maxcode;
	#elif Word_AlternateDefinition2
	internal static ushort maxcode;
	#endif
	#if Word_AlternateDefinition1
	internal static ushort maxmain;
	#elif Word_AlternateDefinition2
	internal static ushort maxmain;
	#endif
	#if Word_AlternateDefinition1
	internal static ushort maxcurr;
	#elif Word_AlternateDefinition2
	internal static ushort maxcurr;
	#endif
	#if Byte_AlternateDefinition1
	internal static byte code = null;
	#elif Byte_AlternateDefinition2
	internal static byte code = null;
	#endif
	#if Byte_AlternateDefinition1
	internal static byte initcode;
	#elif Byte_AlternateDefinition2
	internal static byte initcode;
	#endif
	#if Byte_AlternateDefinition1
	internal static byte[] basepc;
	#elif Byte_AlternateDefinition2
	internal static byte[] basepc;
	#endif
	#if Word_AlternateDefinition1
	internal static ushort maincode;
	#elif Word_AlternateDefinition2
	internal static ushort maincode;
	#endif
	#if Word_AlternateDefinition1
	internal static ushort pc;
	#elif Word_AlternateDefinition2
	internal static ushort pc;
	#endif

	#define MAXVAR
	internal static int[] varbuffer = new int[DefineConstantsY_tab.MAXVAR]; // variables in an assignment list;
	//				it's long to store negative Word values 
	internal static int nvarbuffer =0; // number of variables at a list 

	#if Word_AlternateDefinition1
	internal static ushort[] localvar = new ushort[DefineConstantsY_tab.STACKGAP];
	#elif Word_AlternateDefinition2
	internal static ushort[] localvar = new ushort[DefineConstantsY_tab.STACKGAP];
	#endif
	internal static int nlocalvar =0; // number of local variables 

	//C++ TO C# CONVERTER NOTE: The following #define macro was replaced in-line:
	//ORIGINAL LINE: #define MAXFIELDS FIELDS_PER_FLUSH*2
	#define MAXFIELDS
	#if Word_AlternateDefinition1
	internal static ushort[] fields = new ushort[DefineConstantsY_tab.FIELDS_PER_FLUSH *2];
	#elif Word_AlternateDefinition2
	internal static ushort[] fields = new ushort[DefineConstantsY_tab.FIELDS_PER_FLUSH *2];
	#endif
	internal static int nfields =0;
	internal static int ntemp; // number of temporary var into stack 
	internal static int err; // flag to indicate error 

	// Internal functions 

	#if Byte_AlternateDefinition1
	internal static void code_byte(byte c)
	#elif Byte_AlternateDefinition2
	internal static void code_byte(byte c)
	#endif
	{
	 if (pc>maxcurr-2) // 1 byte free to code HALT of main code 
	 {
	  maxcurr += DefineConstantsY_tab.GAPCODE;
	#if Byte_AlternateDefinition1
	#if Byte_AlternateDefinition1
//C++ TO C# CONVERTER TODO TASK: The memory management function 'realloc' has no equivalent in C#:
	  basepc = (byte)realloc(basepc, maxcurr *sizeof(byte));
	#elif Byte_AlternateDefinition2
//C++ TO C# CONVERTER TODO TASK: The memory management function 'realloc' has no equivalent in C#:
	  basepc = (byte)realloc(basepc, maxcurr *sizeof(byte));
	#endif
	#elif Byte_AlternateDefinition2
	#if Byte_AlternateDefinition1
//C++ TO C# CONVERTER TODO TASK: The memory management function 'realloc' has no equivalent in C#:
	  basepc = (byte)realloc(basepc, maxcurr *sizeof(byte));
	#elif Byte_AlternateDefinition2
//C++ TO C# CONVERTER TODO TASK: The memory management function 'realloc' has no equivalent in C#:
	  basepc = (byte)realloc(basepc, maxcurr *sizeof(byte));
	#endif
	#endif
	  if (basepc == null)
	  {
	   lua_error ("not enough memory");
	   err = 1;
	  }
	 }
	 basepc[pc++] = c;
	}

	#if Word_AlternateDefinition1
	internal static void code_word(ushort n)
	#elif Word_AlternateDefinition2
	internal static void code_word(ushort n)
	#endif
	{
	 CodeWord code = new CodeWord();
	 code.w = n;
	 code_byte(code.m.c1);
	 code_byte(code.m.c2);
	}

	internal static void code_float(float n)
	{
	 CodeFloat code = new CodeFloat();
	 code.f = n;
	 code_byte(code.m.c1);
	 code_byte(code.m.c2);
	 code_byte(code.m.c3);
	 code_byte(code.m.c4);
	}

	#if Byte_AlternateDefinition1
	#if Word_AlternateDefinition1
	internal static void code_word_at(ref byte p, ushort n)
	#elif Word_AlternateDefinition2
	internal static void code_word_at(ref byte p, ushort n)
	#endif
	#elif Byte_AlternateDefinition2
	#if Word_AlternateDefinition1
	internal static void code_word_at(ref byte p, ushort n)
	#elif Word_AlternateDefinition2
	internal static void code_word_at(ref byte p, ushort n)
	#endif
	#endif
	{
	 CodeWord code = new CodeWord();
	 code.w = n;
	 p++= code.m.c1;
	 p++= code.m.c2;
	}

	#if Word_AlternateDefinition1
	internal static void push_field(ushort name)
	#elif Word_AlternateDefinition2
	internal static void push_field(ushort name)
	#endif
	{
	  if (nfields < DefineConstantsY_tab.STACKGAP-1)
		fields[nfields++] = name;
	  else
	  {
	   lua_error ("too many fields in a constructor");
	   err = 1;
	  }
	}

	internal static void flush_record(int n)
	{
	  int i;
	  if (n == 0)
		  return;
	  code_byte(AnonymousEnum.STORERECORD);
	  code_byte(n);
	  for (i =0; i<n; i++)
		code_word(fields[--nfields]);
	  ntemp -= n;
	}

	internal static void flush_list(int m, int n)
	{
	  if (n == 0)
		  return;
	  if (m == 0)
		code_byte(AnonymousEnum.STORELIST0);
	  else
	  {
		code_byte(AnonymousEnum.STORELIST);
		code_byte(m);
	  }
	  code_byte(n);
	  ntemp-=n;
	}

	internal static void incr_ntemp()
	{
	 if (ntemp+nlocalvar+DefineConstantsY_tab.MAXVAR+1 < DefineConstantsY_tab.STACKGAP)
	  ntemp++;
	 else
	 {
	  lua_error ("stack overflow");
	  err = 1;
	 }
	}

	internal static void add_nlocalvar(int n)
	{
	 if (ntemp+nlocalvar+DefineConstantsY_tab.MAXVAR+n < DefineConstantsY_tab.STACKGAP)
	  nlocalvar += n;
	 else
	 {
	  lua_error ("too many local variables or expression too complicate");
	  err = 1;
	 }
	}

	internal static void incr_nvarbuffer()
	{
	 if (nvarbuffer < DefineConstantsY_tab.MAXVAR-1)
	  nvarbuffer++;
	 else
	 {
	  lua_error ("variable buffer overflow");
	  err = 1;
	 }
	}

	internal static void code_number(float f)
	{
	#if Word_AlternateDefinition1
	#if Word_AlternateDefinition1
		ushort i = (ushort)f;
	#elif Word_AlternateDefinition2
		ushort i = (ushort)f;
	#endif
	#elif Word_AlternateDefinition2
	#if Word_AlternateDefinition1
		ushort i = (ushort)f;
	#elif Word_AlternateDefinition2
		ushort i = (ushort)f;
	#endif
	#endif
	  if (f == (float)i) // f has an (short) integer value 
	  {
	   if (i <= 2)
		   code_byte(AnonymousEnum.PUSH0 + i);
	   else if (i <= 255)
	   {
		code_byte(AnonymousEnum.PUSHBYTE);
		code_byte(i);
	   }
	   else
	   {
		code_byte(AnonymousEnum.PUSHWORD);
		code_word(i);
	   }
	  }
	  else
	  {
	   code_byte(AnonymousEnum.PUSHFLOAT);
	   code_float(f);
	  }
	  incr_ntemp();
	}
	#define WRONGTOKEN
	#define NIL
	#define IF
	#define THEN
	#define ELSE
	#define ELSEIF
	#define WHILE
	#define DO
	#define REPEAT
	#define UNTIL
	#define END
	#define RETURN
	#define LOCAL
	#define NUMBER
	#define FUNCTION
	#define STRING
	#define NAME
	#define DEBUG
	#define AND
	#define OR
	#define NE
	#define LE
	#define GE
	#define CONC
	#define UNARY
	#define NOT
	//C++ TO C# CONVERTER NOTE: The following #define macro was replaced in-line:
	//ORIGINAL LINE: #define yyclearin yychar = -1
	#define yyclearin
	//C++ TO C# CONVERTER NOTE: The following #define macro was replaced in-line:
	//ORIGINAL LINE: #define yyerrok yyerrflag = 0
	#define yyerrok
//C++ TO C# CONVERTER NOTE: 'extern' variable declarations are not required in C#:
	//extern int yychar;
//C++ TO C# CONVERTER NOTE: 'extern' variable declarations are not required in C#:
	//extern int yyerrflag;
	#if ! YYMAXDEPTH
	#define YYMAXDEPTH
	#endif
	public static YYSTYPE yylval = new YYSTYPE();
	public static YYSTYPE yyval = new YYSTYPE();
	#define YYERRCODE

	//# line 622 "lua.stx"


	//
	//** Search a local name and if find return its index. If do not find return -1
	//
	#if Word_AlternateDefinition1
	internal static int lua_localname(ushort n)
	#elif Word_AlternateDefinition2
	internal static int lua_localname(ushort n)
	#endif
	{
	 int i;
	 for (i =nlocalvar-1; i >= 0; i--)
	  if (n == localvar[i]) // local var 
		  return i;
	 return -1; // global var 
	}

	//
	//** Push a variable given a number. If number is positive, push global variable
	//** indexed by (number -1). If negative, push local indexed by ABS(number)-1.
	//** Otherwise, if zero, push indexed variable (record).
	//
	internal static void lua_pushvar(int number)
	{
	 if (number > 0) // global var 
	 {
	  code_byte(AnonymousEnum.PUSHGLOBAL);
	  code_word(number-1);
	  incr_ntemp();
	 }
	 else if (number < 0) // local var 
	 {
	  number = (-number) - 1;
	  if (number < 10)
		  code_byte(AnonymousEnum.PUSHLOCAL0 + number);
	  else
	  {
	   code_byte(AnonymousEnum.PUSHLOCAL);
	   code_byte(number);
	  }
	  incr_ntemp();
	 }
	 else
	 {
	  code_byte(AnonymousEnum.PUSHINDEXED);
	  ntemp--;
	 }
	}

	internal static void lua_codeadjust(int n)
	{
	 code_byte(AnonymousEnum.ADJUST);
	 code_byte(n + nlocalvar);
	}

	internal static void lua_codestore(int i)
	{
	 if (varbuffer[i] > 0) // global var 
	 {
	  code_byte(AnonymousEnum.STOREGLOBAL);
	  code_word(varbuffer[i]-1);
	 }
	 else if (varbuffer[i] < 0) // local var 
	 {
	  int number = (-varbuffer[i]) - 1;
	  if (number < 10)
		  code_byte(AnonymousEnum.STORELOCAL0 + number);
	  else
	  {
	   code_byte(AnonymousEnum.STORELOCAL);
	   code_byte(number);
	  }
	 }
	 else // indexed var 
	 {
	  int j;
	  int upper =0; // number of indexed variables upper 
	  int param; // number of itens until indexed expression 
	  for (j =i+1; j <nvarbuffer; j++)
	   if (varbuffer[j] == 0)
		   upper++;
	  param = upper *2 + i;
	  if (param == 0)
	   code_byte(AnonymousEnum.STOREINDEXED0);
	  else
	  {
	   code_byte(AnonymousEnum.STOREINDEXED);
	   code_byte(param);
	  }
	 }
	}
//C++ TO C# CONVERTER NOTE: This was formerly a static local variable declaration (not allowed in C#):
private string msg = new string(new char[256]);

	public static void yyerror(ref string s)
	{
	//C++ TO C# CONVERTER NOTE: This static local variable declaration (not allowed in C#) has been moved just prior to the method:
	// static sbyte msg[256];
	 msg = string.Format ("{0} near \"{1}\" at line {2:D} in file \"{3}\"", s, lua_lasttext (), lua_linenumber, lua_filename());
	 lua_error (ref msg);
	 err = 1;
	}

	public static int yywrap()
	{
	 return 1;
	}


	//
	//** Parse LUA code and execute global statement.
	//** Return 0 on success or 1 on error.
	//
	public static int lua_parse()
	{
	#if Byte_AlternateDefinition1
	#if Byte_AlternateDefinition1
	#if Byte_AlternateDefinition1
//C++ TO C# CONVERTER TODO TASK: The memory management function 'calloc' has no equivalent in C#:
	 byte init = initcode = (byte) calloc(DefineConstantsY_tab.GAPCODE, sizeof(byte));
	#elif Byte_AlternateDefinition2
//C++ TO C# CONVERTER TODO TASK: The memory management function 'calloc' has no equivalent in C#:
	 byte init = initcode = (byte) calloc(DefineConstantsY_tab.GAPCODE, sizeof(byte));
	#endif
	#elif Byte_AlternateDefinition2
	#if Byte_AlternateDefinition1
//C++ TO C# CONVERTER TODO TASK: The memory management function 'calloc' has no equivalent in C#:
	 byte init = initcode = (byte) calloc(DefineConstantsY_tab.GAPCODE, sizeof(byte));
	#elif Byte_AlternateDefinition2
//C++ TO C# CONVERTER TODO TASK: The memory management function 'calloc' has no equivalent in C#:
	 byte init = initcode = (byte) calloc(DefineConstantsY_tab.GAPCODE, sizeof(byte));
	#endif
	#endif
	#elif Byte_AlternateDefinition2
	#if Byte_AlternateDefinition1
	#if Byte_AlternateDefinition1
//C++ TO C# CONVERTER TODO TASK: The memory management function 'calloc' has no equivalent in C#:
	 byte init = initcode = (byte) calloc(DefineConstantsY_tab.GAPCODE, sizeof(byte));
	#elif Byte_AlternateDefinition2
//C++ TO C# CONVERTER TODO TASK: The memory management function 'calloc' has no equivalent in C#:
	 byte init = initcode = (byte) calloc(DefineConstantsY_tab.GAPCODE, sizeof(byte));
	#endif
	#elif Byte_AlternateDefinition2
	#if Byte_AlternateDefinition1
//C++ TO C# CONVERTER TODO TASK: The memory management function 'calloc' has no equivalent in C#:
	 byte init = initcode = (byte) calloc(DefineConstantsY_tab.GAPCODE, sizeof(byte));
	#elif Byte_AlternateDefinition2
//C++ TO C# CONVERTER TODO TASK: The memory management function 'calloc' has no equivalent in C#:
	 byte init = initcode = (byte) calloc(DefineConstantsY_tab.GAPCODE, sizeof(byte));
	#endif
	#endif
	#endif
	 maincode = 0;
	 maxmain = DefineConstantsY_tab.GAPCODE;
	 if (init == null)
	 {
	  lua_error("not enough memory");
	  return 1;
	 }
	 err = 0;
	 if (yyparse () != 0 || (err ==1))
		 return 1;
	 initcode[maincode++] = AnonymousEnum.HALT;
	 init = initcode;
	#if LISTING
	 PrintCode(ref init, ref init+maincode);
	#endif
	 if (lua_execute (ref init) != 0)
		 return 1;
//C++ TO C# CONVERTER TODO TASK: The memory management function 'free' has no equivalent in C#:
	 free(init);
	 return 0;
	}


	#if LISTING

	#if Byte_AlternateDefinition1
	#if Byte_AlternateDefinition1
	internal static void PrintCode(ref byte code, ref byte end)
	#elif Byte_AlternateDefinition2
	internal static void PrintCode(ref byte code, ref byte end)
	#endif
	#elif Byte_AlternateDefinition2
	#if Byte_AlternateDefinition1
	internal static void PrintCode(ref byte code, ref byte end)
	#elif Byte_AlternateDefinition2
	internal static void PrintCode(ref byte code, ref byte end)
	#endif
	#endif
	{
	#if Byte_AlternateDefinition1
//C++ TO C# CONVERTER TODO TASK: Pointer arithmetic is detected on this variable, so pointers on this variable are left unchanged.
	 byte *p = code;
	#elif Byte_AlternateDefinition2
//C++ TO C# CONVERTER TODO TASK: Pointer arithmetic is detected on this variable, so pointers on this variable are left unchanged.
	 byte *p = code;
	#endif
	 Console.Write ("\n\nCODE\n");
	 while (p != end)
	 {
	  switch ((OpCode)*p)
	  {
	   case AnonymousEnum.PUSHNIL:
		   Console.Write ("{0:D}    PUSHNIL\n", (p++)-code);
		   break;
	   case AnonymousEnum.PUSH0:
		   case AnonymousEnum.PUSH1:
			   case AnonymousEnum.PUSH2:
					Console.Write ("{0:D}    PUSH{1}\n", p-code, *p-AnonymousEnum.PUSH0+'0');
					p++;
				   break;
	   case AnonymousEnum.PUSHBYTE:
					Console.Write ("{0:D}    PUSHBYTE   {1:D}\n", p-code, *(++p));
					p++;
				   break;
	   case AnonymousEnum.PUSHWORD:
							{
				 CodeWord c = new CodeWord();
				 int n = p-code;
				 p++;
	#if get_word_AlternateDefinition1
				 {
					 c.m.c1 = *p++;
					 c.m.c2 = *p++;
				 }
	#elif get_word_AlternateDefinition2
				 {
					 c.m.c1 = *p++;
					 c.m.c2 = *p++;
				 }
	#endif
					 Console.Write ("{0:D}    PUSHWORD   {1:D}\n", n, c.w);
				}
				   break;
	   case AnonymousEnum.PUSHFLOAT:
				{
				 CodeFloat c = new CodeFloat();
				 int n = p-code;
				 p++;
	#if get_float_AlternateDefinition1
				 {
					 c.m.c1 = *p++;
					 c.m.c2 = *p++;
					 c.m.c3 = *p++;
					 c.m.c4 = *p++;
				 }
	#elif get_float_AlternateDefinition2
				 {
					 c.m.c1 = *p++;
					 c.m.c2 = *p++;
					 c.m.c3 = *p++;
					 c.m.c4 = *p++;
				 }
	#endif
					 Console.Write ("{0:D}    PUSHFLOAT  {1:f}\n", n, c.f);
				}
				   break;
	   case AnonymousEnum.PUSHSTRING:
					{
				 CodeWord c = new CodeWord();
				 int n = p-code;
				 p++;
	#if get_word_AlternateDefinition1
				 {
					 c.m.c1 = *p++;
					 c.m.c2 = *p++;
				 }
	#elif get_word_AlternateDefinition2
				 {
					 c.m.c1 = *p++;
					 c.m.c2 = *p++;
				 }
	#endif
					 Console.Write ("{0:D}    PUSHSTRING   {1:D}\n", n, c.w);
				}
				   break;
	   case AnonymousEnum.PUSHLOCAL0:
		   case AnonymousEnum.PUSHLOCAL1:
			   case AnonymousEnum.PUSHLOCAL2:
				   case AnonymousEnum.PUSHLOCAL3:
	   case AnonymousEnum.PUSHLOCAL4:
		   case AnonymousEnum.PUSHLOCAL5:
			   case AnonymousEnum.PUSHLOCAL6:
				   case AnonymousEnum.PUSHLOCAL7:
	   case AnonymousEnum.PUSHLOCAL8:
		   case AnonymousEnum.PUSHLOCAL9:
					Console.Write ("{0:D}    PUSHLOCAL{1}\n", p-code, *p-AnonymousEnum.PUSHLOCAL0+'0');
					p++;
				   break;
	   case AnonymousEnum.PUSHLOCAL:
		   Console.Write ("{0:D}    PUSHLOCAL   {1:D}\n", p-code, *(++p));
					p++;
				   break;
	   case AnonymousEnum.PUSHGLOBAL:
					{
				 CodeWord c = new CodeWord();
				 int n = p-code;
				 p++;
	#if get_word_AlternateDefinition1
				 {
					 c.m.c1 = *p++;
					 c.m.c2 = *p++;
				 }
	#elif get_word_AlternateDefinition2
				 {
					 c.m.c1 = *p++;
					 c.m.c2 = *p++;
				 }
	#endif
					 Console.Write ("{0:D}    PUSHGLOBAL   {1:D}\n", n, c.w);
				}
				   break;
	   case AnonymousEnum.PUSHINDEXED:
		   Console.Write ("{0:D}    PUSHINDEXED\n", (p++)-code);
		   break;
	   case AnonymousEnum.PUSHMARK:
		   Console.Write ("{0:D}    PUSHMARK\n", (p++)-code);
		   break;
	   case AnonymousEnum.PUSHOBJECT:
		   Console.Write ("{0:D}    PUSHOBJECT\n", (p++)-code);
		   break;
	   case AnonymousEnum.STORELOCAL0:
		   case AnonymousEnum.STORELOCAL1:
			   case AnonymousEnum.STORELOCAL2:
				   case AnonymousEnum.STORELOCAL3:
	   case AnonymousEnum.STORELOCAL4:
		   case AnonymousEnum.STORELOCAL5:
			   case AnonymousEnum.STORELOCAL6:
				   case AnonymousEnum.STORELOCAL7:
	   case AnonymousEnum.STORELOCAL8:
		   case AnonymousEnum.STORELOCAL9:
					Console.Write ("{0:D}    STORELOCAL{1}\n", p-code, *p-AnonymousEnum.STORELOCAL0+'0');
					p++;
				   break;
	   case AnonymousEnum.STORELOCAL:
					Console.Write ("{0:D}    STORELOCAL   {1:D}\n", p-code, *(++p));
					p++;
				   break;
	   case AnonymousEnum.STOREGLOBAL:
					{
				 CodeWord c = new CodeWord();
				 int n = p-code;
				 p++;
	#if get_word_AlternateDefinition1
				 {
					 c.m.c1 = *p++;
					 c.m.c2 = *p++;
				 }
	#elif get_word_AlternateDefinition2
				 {
					 c.m.c1 = *p++;
					 c.m.c2 = *p++;
				 }
	#endif
					 Console.Write ("{0:D}    STOREGLOBAL   {1:D}\n", n, c.w);
				}
				   break;
	   case AnonymousEnum.STOREINDEXED0:
		   Console.Write ("{0:D}    STOREINDEXED0\n", (p++)-code);
		   break;
	   case AnonymousEnum.STOREINDEXED:
		   Console.Write ("{0:D}    STOREINDEXED   {1:D}\n", p-code, *(++p));
					p++;
				   break;
	   case AnonymousEnum.STORELIST0:
		Console.Write("{0:D}      STORELIST0  {1:D}\n", p-code, *(++p));
			p++;
			break;
	   case AnonymousEnum.STORELIST:
		Console.Write("{0:D}      STORELIST  {1:D} {2:D}\n", p-code, *(p+1), *(p+2));
			p+=3;
			break;
	   case AnonymousEnum.STORERECORD:
		   Console.Write("{0:D}      STORERECORD  {1:D}\n", p-code, *(++p));
	#if Word_AlternateDefinition1
		   p += *p *sizeof(ushort) + 1;
	#elif Word_AlternateDefinition2
		   p += *p *sizeof(ushort) + 1;
	#endif
		   break;
	   case AnonymousEnum.ADJUST:
					Console.Write ("{0:D}    ADJUST   {1:D}\n", p-code, *(++p));
					p++;
				   break;
	   case AnonymousEnum.CREATEARRAY:
		   Console.Write ("{0:D}    CREATEARRAY\n", (p++)-code);
		   break;
	   case AnonymousEnum.EQOP:
		   Console.Write ("{0:D}    EQOP\n", (p++)-code);
		   break;
	   case AnonymousEnum.LTOP:
		   Console.Write ("{0:D}    LTOP\n", (p++)-code);
		   break;
	   case AnonymousEnum.LEOP:
		   Console.Write ("{0:D}    LEOP\n", (p++)-code);
		   break;
	   case AnonymousEnum.ADDOP:
		   Console.Write ("{0:D}    ADDOP\n", (p++)-code);
		   break;
	   case AnonymousEnum.SUBOP:
		   Console.Write ("{0:D}    SUBOP\n", (p++)-code);
		   break;
	   case AnonymousEnum.MULTOP:
		   Console.Write ("{0:D}    MULTOP\n", (p++)-code);
		   break;
	   case AnonymousEnum.DIVOP:
		   Console.Write ("{0:D}    DIVOP\n", (p++)-code);
		   break;
	   case AnonymousEnum.CONCOP:
		   Console.Write ("{0:D}    CONCOP\n", (p++)-code);
		   break;
	   case AnonymousEnum.MINUSOP:
		   Console.Write ("{0:D}    MINUSOP\n", (p++)-code);
		   break;
	   case AnonymousEnum.NOTOP:
		   Console.Write ("{0:D}    NOTOP\n", (p++)-code);
		   break;
	   case AnonymousEnum.ONTJMP:
					{
				 CodeWord c = new CodeWord();
				 int n = p-code;
				 p++;
	#if get_word_AlternateDefinition1
				 {
					 c.m.c1 = *p++;
					 c.m.c2 = *p++;
				 }
	#elif get_word_AlternateDefinition2
				 {
					 c.m.c1 = *p++;
					 c.m.c2 = *p++;
				 }
	#endif
					 Console.Write ("{0:D}    ONTJMP  {1:D}\n", n, c.w);
				}
				   break;
	   case AnonymousEnum.ONFJMP:
					{
				 CodeWord c = new CodeWord();
				 int n = p-code;
				 p++;
	#if get_word_AlternateDefinition1
				 {
					 c.m.c1 = *p++;
					 c.m.c2 = *p++;
				 }
	#elif get_word_AlternateDefinition2
				 {
					 c.m.c1 = *p++;
					 c.m.c2 = *p++;
				 }
	#endif
					 Console.Write ("{0:D}    ONFJMP  {1:D}\n", n, c.w);
				}
				   break;
	   case AnonymousEnum.JMP:
					{
				 CodeWord c = new CodeWord();
				 int n = p-code;
				 p++;
	#if get_word_AlternateDefinition1
				 {
					 c.m.c1 = *p++;
					 c.m.c2 = *p++;
				 }
	#elif get_word_AlternateDefinition2
				 {
					 c.m.c1 = *p++;
					 c.m.c2 = *p++;
				 }
	#endif
					 Console.Write ("{0:D}    JMP  {1:D}\n", n, c.w);
				}
				   break;
	   case AnonymousEnum.UPJMP:
					{
				 CodeWord c = new CodeWord();
				 int n = p-code;
				 p++;
	#if get_word_AlternateDefinition1
				 {
					 c.m.c1 = *p++;
					 c.m.c2 = *p++;
				 }
	#elif get_word_AlternateDefinition2
				 {
					 c.m.c1 = *p++;
					 c.m.c2 = *p++;
				 }
	#endif
					 Console.Write ("{0:D}    UPJMP  {1:D}\n", n, c.w);
				}
				   break;
	   case AnonymousEnum.IFFJMP:
					{
				 CodeWord c = new CodeWord();
				 int n = p-code;
				 p++;
	#if get_word_AlternateDefinition1
				 {
					 c.m.c1 = *p++;
					 c.m.c2 = *p++;
				 }
	#elif get_word_AlternateDefinition2
				 {
					 c.m.c1 = *p++;
					 c.m.c2 = *p++;
				 }
	#endif
					 Console.Write ("{0:D}    IFFJMP  {1:D}\n", n, c.w);
				}
				   break;
	   case AnonymousEnum.IFFUPJMP:
					{
				 CodeWord c = new CodeWord();
				 int n = p-code;
				 p++;
	#if get_word_AlternateDefinition1
				 {
					 c.m.c1 = *p++;
					 c.m.c2 = *p++;
				 }
	#elif get_word_AlternateDefinition2
				 {
					 c.m.c1 = *p++;
					 c.m.c2 = *p++;
				 }
	#endif
					 Console.Write ("{0:D}    IFFUPJMP  {1:D}\n", n, c.w);
				}
				   break;
	   case AnonymousEnum.POP:
		   Console.Write ("{0:D}    POP\n", (p++)-code);
		   break;
	   case AnonymousEnum.CALLFUNC:
		   Console.Write ("{0:D}    CALLFUNC\n", (p++)-code);
		   break;
	   case AnonymousEnum.RETCODE:
					Console.Write ("{0:D}    RETCODE   {1:D}\n", p-code, *(++p));
					p++;
				   break;
	   case AnonymousEnum.HALT:
		   Console.Write ("{0:D}    HALT\n", (p++)-code);
		   break;
	   case AnonymousEnum.SETFUNCTION:
							{
							 CodeWord c1 = new CodeWord();
							 CodeWord c2 = new CodeWord();
							 int n = p-code;
							 p++;
	#if get_word_AlternateDefinition1
							 {
								 c1.m.c1 = *p++;
								 c1.m.c2 = *p++;
							 }
	#elif get_word_AlternateDefinition2
							 {
								 c1.m.c1 = *p++;
								 c1.m.c2 = *p++;
							 }
	#endif
	#if get_word_AlternateDefinition1
							 {
								 c2.m.c1 = *p++;
								 c2.m.c2 = *p++;
							 }
	#elif get_word_AlternateDefinition2
							 {
								 c2.m.c1 = *p++;
								 c2.m.c2 = *p++;
							 }
	#endif
							 Console.Write ("{0:D}    SETFUNCTION  {1:D}  {2:D}\n", n, c1.w, c2.w);
							}
							break;
	   case AnonymousEnum.SETLINE:
							{
							 CodeWord c = new CodeWord();
							 int n = p-code;
							 p++;
	#if get_word_AlternateDefinition1
							 {
								 c.m.c1 = *p++;
								 c.m.c2 = *p++;
							 }
	#elif get_word_AlternateDefinition2
							 {
								 c.m.c1 = *p++;
								 c.m.c2 = *p++;
							 }
	#endif
							 Console.Write ("{0:D}    SETLINE  {1:D}\n", n, c.w);
							}
							break;

	   case AnonymousEnum.RESET:
		   Console.Write ("{0:D}    RESET\n", (p++)-code);
		   break;
	   default:
		   Console.Write ("{0:D}    Cannot happen: code {1:D}\n", (p++)-code, *(p-1));
		   break;
	  }
	 }
	}
	#endif

	public static int[] yyexca ={ -1, 1, 0, -1, -2, 2, -1, 20, 40, 67, 91, 94, 46, 96, -2, 91, -1, 32, 40, 67, 91, 94, 46, 96, -2, 51, -1, 73, 275, 34, 276, 34, 61, 34, 277, 34, 62, 34, 60, 34, 278, 34, 279, 34, 280, 34, 43, 34, 45, 34, 42, 34, 47, 34, -2, 70, -1, 74, 91, 94, 46, 96, -2, 92, -1, 105, 261, 28, 262, 28, 266, 28, 267, 28, 268, 28, -2, 11, -1, 125, 268, 31, -2, 30, -1, 146, 275, 34, 276, 34, 61, 34, 277, 34, 62, 34, 60, 34, 278, 34, 279, 34, 280, 34, 43, 34, 45, 34, 42, 34, 47, 34, -2, 72};
	#define YYNPROD
	#define YYLAST
	public static int[] yyact ={ 58, 56, 22, 57, 132, 59, 58, 56, 137, 57, 110, 59, 58, 56, 107, 57, 85, 59, 51, 50, 52, 82, 23, 43, 51, 50, 52, 58, 56, 9, 57, 157, 59, 58, 56, 165, 57, 5, 59, 162, 6, 161, 104, 154, 155, 51, 50, 52, 64, 153, 70, 51, 50, 52, 26, 58, 56, 127, 57, 10, 59, 111, 25, 78, 27, 58, 56, 28, 57, 29, 59, 131, 147, 51, 50, 52, 7, 65, 66, 115, 150, 112, 63, 51, 50, 52, 68, 69, 31, 159, 11, 79, 58, 76, 128, 73, 41, 59, 151, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 77, 114, 148, 40, 58, 56, 102, 57, 106, 59, 117, 32, 72, 121, 116, 100, 80, 109, 67, 48, 20, 36, 73, 30, 45, 73, 44, 118, 149, 84, 17, 126, 18, 46, 21, 47, 120, 119, 101, 145, 144, 125, 71, 123, 75, 39, 38, 12, 8, 108, 105, 136, 83, 74, 135, 24, 4, 3, 139, 140, 2, 81, 134, 141, 133, 130, 129, 42, 113, 16, 1, 146, 124, 0, 143, 0, 0, 152, 0, 0, 0, 86, 0, 0, 0, 0, 0, 13, 0, 0, 160, 14, 0, 15, 164, 163, 0, 19, 167, 0, 0, 23, 73, 0, 0, 0, 0, 0, 168, 166, 158, 171, 173, 0, 0, 0, 169, 0, 0, 0, 0, 0, 0, 61, 62, 53, 54, 55, 60, 61, 62, 53, 54, 55, 60, 0, 0, 0, 0, 103, 60, 49, 0, 98, 99, 0, 0, 0, 0, 0, 61, 62, 53, 54, 55, 60, 61, 62, 53, 54, 55, 60, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35, 0, 0, 0, 0, 0, 61, 62, 53, 54, 55, 60, 33, 122, 34, 23, 0, 0, 53, 54, 55, 60, 0, 0, 37, 0, 0, 0, 138, 0, 0, 0, 0, 142, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 156, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 170, 0, 0, 172 };
	public static int[] yypact ={ -1000, -234, -1000, -1000, -1000, -244, -1000, 31, -62, -1000, -1000, -1000, -1000, 24, -1000, -1000, 52, -1000, -1000, -250, -1000, -1000, -1000, -1000, 89, -9, -1000, 24, 24, 24, -1000, 88, -1000, -1000, -1000, -1000, -1000, 24, 24, -1000, 24, -251, 49, -1000, -28, 45, 86, -252, -257, -1000, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, -1000, -1000, 84, 13, -1000, -1000, 24, -1000, -15, -224, -1000, 74, -1000, -1000, -1000, -259, 24, 24, -263, 24, -12, -1000, 83, 76, -1000, -1000, -30, -30, -30, -30, -30, -30, 50, 50, -1000, -1000, 72, -1000, -1000, -1000, 82, 13, -1000, 24, -1000, -1000, -1000, 74, -36, -1000, 53, 74, -1000, -269, 24, -1000, -265, -1000, 24, 24, -1000, -1000, 13, 31, -1000, 24, -1000, -1000, -53, 68, -1000, -1000, -13, 54, 13, -1000, -1000, -218, 23, 23, -1000, -1000, -1000, -1000, -237, -1000, -1000, -269, 28, -1000, 24, -226, -228, -1000, 24, -232, 24, -1000, 24, 13, -1000, -1000, -1000, -42, -1000, 31, 13, -1000, -1000, -1000, -1000, -218, -1000 };
	public static int[] yypgo ={ 0, 180, 191, 54, 61, 81, 179, 133, 178, 177, 176, 175, 174, 172, 121, 171, 170, 76, 59, 167, 166, 165, 162, 161, 50, 160, 158, 157, 48, 49, 156, 155, 131, 154, 152, 151, 150, 149, 148, 147, 146, 145, 144, 143, 141, 139, 71, 138, 136, 134 };
	public static int[] yyr1 ={ 0, 1, 16, 1, 1, 1, 21, 23, 19, 25, 25, 26, 17, 18, 18, 27, 30, 27, 31, 27, 27, 27, 27, 27, 29, 29, 29, 34, 35, 24, 36, 37, 36, 2, 28, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 39, 3, 40, 3, 41, 7, 38, 38, 43, 32, 42, 4, 4, 5, 44, 5, 22, 22, 45, 45, 15, 15, 8, 8, 10, 10, 11, 11, 47, 46, 12, 12, 13, 13, 6, 6, 14, 48, 14, 49, 14, 9, 9, 33, 33, 20 };
	public static int[] yyr2 ={ 0, 0, 1, 9, 4, 4, 1, 1, 19, 0, 6, 1, 4, 0, 2, 17, 1, 17, 1, 13, 7, 3, 3, 7, 0, 4, 15, 1, 1, 9, 0, 1, 9, 1, 3, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 5, 5, 3, 9, 3, 3, 3, 3, 3, 5, 1, 11, 1, 11, 1, 9, 1, 2, 1, 11, 3, 1, 3, 3, 1, 9, 0, 2, 3, 7, 1, 3, 7, 7, 1, 3, 3, 7, 1, 9, 1, 3, 3, 7, 3, 7, 3, 1, 11, 1, 9, 3, 7, 0, 4, 3 };
	public static int[] yychk ={ -1000, -1, -16, -19, -20, 271, 274, -17, -26, 273, -18, 59, -27, 259, 263, 265, -6, -32, -7, 269, -14, -42, 64, 273, -21, -28, -3, 40, 43, 45, -7, 64, -14, 270, 272, 258, -32, 282, -30, -31, 61, 44, -9, 273, -48, -49, -43, -41, 40, 260, 61, 60, 62, 277, 278, 279, 43, 45, 42, 47, 280, 275, 276, -3, -28, -28, -28, 40, -28, -28, -24, -34, -5, -3, -14, -33, 44, 61, 91, 46, 40, -15, 273, -22, -45, 273, -2, -28, -28, -28, -28, -28, -28, -28, -28, -28, -28, -28, -2, -2, 41, -38, -28, 264, 266, -25, 44, 273, -5, -28, 273, -4, -5, -8, 123, 91, 41, 44, -24, -39, -40, 41, -2, -28, -17, -35, -44, 93, 41, -10, -11, -46, 273, -12, -13, -28, -23, 273, -2, -28, -28, -24, -2, -18, -36, -37, -3, 125, 44, -47, 93, 44, -24, -29, 261, 262, -2, 268, -46, 61, -28, 267, 267, -24, -28, 267, -4, -28, 260, -18, -2, -24, -2, -29 };
	public static int[] yydef ={ 1, -2, 11, 4, 5, 0, 102, 13, 0, 6, 3, 14, 12, 0, 16, 18, 0, 21, 22, 0, -2, 65, 61, 93, 0, 0, 34, 0, 0, 0, 49, 61, -2, 52, 53, 54, 55, 0, 0, 27, 0, 0, 100, 98, 0, 0, 0, 77, 73, 33, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 33, 33, 34, 0, 47, 48, 63, 56, 0, 0, 9, 20, -2, -2, 23, 0, 0, 0, 0, 68, 0, 78, 0, 74, 75, 27, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 57, 59, 35, 0, 64, 33, 0, -2, 71, 99, 101, 0, 97, 0, 69, 62, 81, 87, 7, 0, 33, 0, 0, 50, 27, 33, 13, -2, 0, 95, 66, 0, 82, 83, 85, 0, 88, 89, 27, 76, 24, 58, 60, 33, 19, 10, 29, 0, -2, 79, 0, 0, 80, 0, 0, 0, 27, 0, 0, 68, 84, 0, 90, 8, 15, 25, 0, 17, 13, 86, 33, 32, 27, 33, 24, 26 };

	#if YYDEBUG

	//C++ TO C# CONVERTER NOTE: Embedded comments are not maintained by C++ to C# Converter
	//ORIGINAL LINE: yytoktype yytoks[] = { "WRONGTOKEN",    257, "NIL",    258, "IF",    259, "THEN",    260, "ELSE",    261, "ELSEIF",    262, "WHILE",    263, "DO",    264, "REPEAT",    265, "UNTIL",    266, "END",    267, "RETURN",    268, "LOCAL",    269, "NUMBER",    270, "FUNCTION",    271, "STRING",    272, "NAME",    273, "DEBUG",    274, "AND",    275, "OR",    276, "=",    61, "NE",    277, ">",    62, "<",    60, "LE",    278, "GE",    279, "CONC",    280, "+",    43, "-",    45, "*",    42, "/",    47, "UNARY",    281, "NOT",    282, "-unknown-",    -1    /* ends search */ };
	public static yytoktype[] yytoks = { new yytoktype("WRONGTOKEN", 257), new yytoktype("NIL", 258), new yytoktype("IF", 259), new yytoktype("THEN", 260), new yytoktype("ELSE", 261), new yytoktype("ELSEIF", 262), new yytoktype("WHILE", 263), new yytoktype("DO", 264), new yytoktype("REPEAT", 265), new yytoktype("UNTIL", 266), new yytoktype("END", 267), new yytoktype("RETURN", 268), new yytoktype("LOCAL", 269), new yytoktype("NUMBER", 270), new yytoktype("FUNCTION", 271), new yytoktype("STRING", 272), new yytoktype("NAME", 273), new yytoktype("DEBUG", 274), new yytoktype("AND", 275), new yytoktype("OR", 276), new yytoktype("=", 61), new yytoktype("NE", 277), new yytoktype(">", 62), new yytoktype("<", 60), new yytoktype("LE", 278), new yytoktype("GE", 279), new yytoktype("CONC", 280), new yytoktype("+", 43), new yytoktype("-", 45), new yytoktype("*", 42), new yytoktype("/", 47), new yytoktype("UNARY", 281), new yytoktype("NOT", 282), new yytoktype("-unknown-", -1) };

	public static string[] yyreds = { "-no such reduction-", "functionlist : /* empty */", "functionlist : functionlist", "functionlist : functionlist stat sc", "functionlist : functionlist function", "functionlist : functionlist setdebug", "function : FUNCTION NAME", "function : FUNCTION NAME '(' parlist ')'", "function : FUNCTION NAME '(' parlist ')' block END", "statlist : /* empty */", "statlist : statlist stat sc", "stat : /* empty */", "stat : stat1", "sc : /* empty */", "sc : ';'", "stat1 : IF expr1 THEN PrepJump block PrepJump elsepart END", "stat1 : WHILE", "stat1 : WHILE expr1 DO PrepJump block PrepJump END", "stat1 : REPEAT", "stat1 : REPEAT block UNTIL expr1 PrepJump", "stat1 : varlist1 '=' exprlist1", "stat1 : functioncall", "stat1 : typeconstructor", "stat1 : LOCAL localdeclist decinit", "elsepart : /* empty */", "elsepart : ELSE block", "elsepart : ELSEIF expr1 THEN PrepJump block PrepJump elsepart", "block : /* empty */", "block : statlist", "block : statlist ret", "ret : /* empty */", "ret : /* empty */", "ret : RETURN exprlist sc", "PrepJump : /* empty */", "expr1 : expr", "expr : '(' expr ')'", "expr : expr1 '=' expr1", "expr : expr1 '<' expr1", "expr : expr1 '>' expr1", "expr : expr1 NE expr1", "expr : expr1 LE expr1", "expr : expr1 GE expr1", "expr : expr1 '+' expr1", "expr : expr1 '-' expr1", "expr : expr1 '*' expr1", "expr : expr1 '/' expr1", "expr : expr1 CONC expr1", "expr : '+' expr1", "expr : '-' expr1", "expr : typeconstructor", "expr : '@' '(' dimension ')'", "expr : var", "expr : NUMBER", "expr : STRING", "expr : NIL", "expr : functioncall", "expr : NOT expr1", "expr : expr1 AND PrepJump", "expr : expr1 AND PrepJump expr1", "expr : expr1 OR PrepJump", "expr : expr1 OR PrepJump expr1", "typeconstructor : '@'", "typeconstructor : '@' objectname fieldlist", "dimension : /* empty */", "dimension : expr1", "functioncall : functionvalue", "functioncall : functionvalue '(' exprlist ')'", "functionvalue : var", "exprlist : /* empty */", "exprlist : exprlist1", "exprlist1 : expr", "exprlist1 : exprlist1 ','", "exprlist1 : exprlist1 ',' expr", "parlist : /* empty */", "parlist : parlist1", "parlist1 : NAME", "parlist1 : parlist1 ',' NAME", "objectname : /* empty */", "objectname : NAME", "fieldlist : '{' ffieldlist '}'", "fieldlist : '[' lfieldlist ']'", "ffieldlist : /* empty */", "ffieldlist : ffieldlist1", "ffieldlist1 : ffield", "ffieldlist1 : ffieldlist1 ',' ffield", "ffield : NAME", "ffield : NAME '=' expr1", "lfieldlist : /* empty */", "lfieldlist : lfieldlist1", "lfieldlist1 : expr1", "lfieldlist1 : lfieldlist1 ',' expr1", "varlist1 : var", "varlist1 : varlist1 ',' var", "var : NAME", "var : var", "var : var '[' expr1 ']'", "var : var", "var : var '.' NAME", "localdeclist : NAME", "localdeclist : localdeclist ',' NAME", "decinit : /* empty */", "decinit : '=' exprlist1", "setdebug : DEBUG"};
	#endif // YYDEBUG 
	#line 1 "/usr/lib/yaccpar"
	//	@(#)yaccpar 1.10 89/04/04 SMI; from S5R3 1.10	

	//
	//** Skeleton parser driver for yacc output
	//

	//
	//** yacc user known macros and defines
	//
	//C++ TO C# CONVERTER NOTE: The following #define macro was replaced in-line:
	//ORIGINAL LINE: #define YYERROR goto yyerrlab
	#define YYERROR
	//C++ TO C# CONVERTER NOTE: The following #define macro was replaced in-line:
	//ORIGINAL LINE: #define YYACCEPT { free(yys); free(yyv); return(0); }
	#define YYACCEPT
	//C++ TO C# CONVERTER NOTE: The following #define macro was replaced in-line:
	//ORIGINAL LINE: #define YYABORT { free(yys); free(yyv); return(1); }
	#define YYABORT
	//C++ TO C# CONVERTER NOTE: The following #define macro was replaced in-line:
	//ORIGINAL LINE: #define YYBACKUP( newtoken, newvalue ) { if ( yychar >= 0 || ( yyr2[ yytmp ] >> 1 ) != 1 ) { yyerror( "syntax error - cannot backup" ); goto yyerrlab; } yychar = newtoken; yystate = *yyps; yylval = newvalue; goto yynewstate; }
	#define YYBACKUP
	//C++ TO C# CONVERTER NOTE: The following #define macro was replaced in-line:
	//ORIGINAL LINE: #define YYRECOVERING() (!!yyerrflag)
	#define YYRECOVERING
	#if ! YYDEBUG
	#define YYDEBUG_AlternateDefinition2
	#define YYDEBUG
	#endif

	//
	//** user known globals
	//
	public static int yydebug; // set to 1 to get debugging 

	//
	//** driver internal defines
	//
	//C++ TO C# CONVERTER NOTE: The following #define macro was replaced in-line:
	//ORIGINAL LINE: #define YYFLAG (-1000)
	#define YYFLAG

	//
	//** static variables used by the parser
	//
	internal static YYSTYPE[] yyv; // value stack 
	internal static int[] yys; // state stack 

	internal static YYSTYPE yypv; // top of value stack 
	internal static int yyps; // top of state stack 

	internal static int yystate; // current state 
	internal static int yytmp; // extra var (lasts between blocks) 

	public static int yynerrs; // number of errors 

	public static int yyerrflag; // error recovery flag 
	public static int yychar; // current input token number 


	//
	//** yyparse - return 0 if worked, 1 if syntax error not recovered from
	//
	public static int yyparse()
	{
//C++ TO C# CONVERTER NOTE: 'register' variable declarations are not supported in C#:
//ORIGINAL LINE: register YYSTYPE *yypvt;
		YYSTYPE yypvt; // top of value stack for $vars 
		uint yymaxdepth = DefineConstantsY_tab.YYMAXDEPTH;

	//    
	//	** Initialize externals - yyparse may be called more than once
	//	
//C++ TO C# CONVERTER TODO TASK: The memory management function 'malloc' has no equivalent in C#:
		yyv = (YYSTYPE)malloc(yymaxdepth *sizeof(YYSTYPE));
//C++ TO C# CONVERTER TODO TASK: The memory management function 'malloc' has no equivalent in C#:
		yys = (int)malloc(yymaxdepth *sizeof(int));
		if (yyv == null || yys == 0)
		{
			yyerror("out of memory");
			return(1);
		}
		yypv = yyv[-1];
		yyps = yys[-1];
		yystate = 0;
		yytmp = 0;
		yynerrs = 0;
		yyerrflag = 0;
		yychar = -1;

		goto yystack;
		{
//C++ TO C# CONVERTER NOTE: 'register' variable declarations are not supported in C#:
//ORIGINAL LINE: register YYSTYPE *yy_pv;
			YYSTYPE yy_pv; // top of value stack 
//C++ TO C# CONVERTER NOTE: 'register' variable declarations are not supported in C#:
//ORIGINAL LINE: register int *yy_ps;
			int yy_ps; // top of state stack 
//C++ TO C# CONVERTER NOTE: 'register' variable declarations are not supported in C#:
//ORIGINAL LINE: register int yy_state;
			int yy_state; // current state 
//C++ TO C# CONVERTER NOTE: 'register' variable declarations are not supported in C#:
//ORIGINAL LINE: register int yy_n;
			int yy_n; // internal state number info 

	//        
	//		** get globals into registers.
	//		** branch to here only if YYBACKUP was called.
	//		
		yynewstate:
			yy_pv = yypv;
			yy_ps = yyps;
			yy_state = yystate;
			goto yy_newstate;

	//        
	//		** get globals into registers.
	//		** either we just started, or we just finished a reduction
	//		
		yystack:
			yy_pv = yypv;
			yy_ps = yyps;
			yy_state = yystate;

	//        
	//		** top of for (;;) loop while no reductions done
	//		
		yy_stack:
	//        
	//		** put a state and value onto the stacks
	//		
	#if YYDEBUG
	//        
	//		** if debugging, look up token value in list of value vs.
	//		** name pairs.  0 and negative (-1) are special values.
	//		** Note: linear search is used since time is not a real
	//		** consideration while debugging.
	//		
			if (yydebug != 0)
			{
//C++ TO C# CONVERTER NOTE: 'register' variable declarations are not supported in C#:
//ORIGINAL LINE: register int yy_i;
				int yy_i;

				()printf("State %d, token ", yy_state);
				if (yychar == 0)
					()printf("end-of-file\n");
				else if (yychar < 0)
					()printf("-none-\n");
				else
				{
					for (yy_i = 0; yytoks[yy_i].t_val >= 0; yy_i++)
					{
						if (yytoks[yy_i].t_val == yychar)
							break;
					}
					()printf("%s\n", yytoks[yy_i].t_name);
				}
			}
	#endif // YYDEBUG 
			if (++yy_ps >= &yys[yymaxdepth]) // room on stack? 
			{
	//            
	//			** reallocate and recover.  Note that pointers
	//			** have to be reset, or bad things will happen
	//			
				int yyps_index = (yy_ps - yys);
				int yypv_index = (yy_pv - yyv);
				int yypvt_index = (yypvt - yyv);
				yymaxdepth += DefineConstantsY_tab.YYMAXDEPTH;
//C++ TO C# CONVERTER TODO TASK: The memory management function 'realloc' has no equivalent in C#:
				yyv = (YYSTYPE)realloc((string)yyv, yymaxdepth * sizeof(YYSTYPE));
//C++ TO C# CONVERTER TODO TASK: The memory management function 'realloc' has no equivalent in C#:
				yys = (int)realloc((string)yys, yymaxdepth * sizeof(int));
				if (yyv == null || yys == 0)
				{
					yyerror("yacc stack overflow");
					return(1);
				}
				yy_ps = yys + yyps_index;
				yy_pv = yyv + yypv_index;
				yypvt = yyv + yypvt_index;
			}
			yy_ps = yy_state;
			*++yy_pv = yyval;

	//        
	//		** we have a new state - find out what to do
	//		
		yy_newstate:
			if ((yy_n = yypact[yy_state]) <= -1000)
				goto yydefault; // simple state 
	#if YYDEBUG
	//        
	//		** if debugging, need to mark whether new token grabbed
	//		
			yytmp = yychar < 0;
	#endif
			if ((yychar < 0) && ((yychar = yylex()) < 0))
				yychar = 0; // reached EOF 
	#if YYDEBUG
			if (yydebug != 0 && yytmp != 0)
			{
//C++ TO C# CONVERTER NOTE: 'register' variable declarations are not supported in C#:
//ORIGINAL LINE: register int yy_i;
				int yy_i;

				()printf("Received token ");
				if (yychar == 0)
					()printf("end-of-file\n");
				else if (yychar < 0)
					()printf("-none-\n");
				else
				{
					for (yy_i = 0; yytoks[yy_i].t_val >= 0; yy_i++)
					{
						if (yytoks[yy_i].t_val == yychar)
							break;
					}
					()printf("%s\n", yytoks[yy_i].t_name);
				}
			}
	#endif // YYDEBUG 
			if (((yy_n += yychar) < 0) || (yy_n >= DefineConstantsY_tab.YYLAST))
				goto yydefault;
			if (yychk[yy_n = yyact[yy_n]] == yychar) //valid shift
			{
				yychar = -1;
//C++ TO C# CONVERTER WARNING: The following line was determined to be a copy assignment (rather than a reference assignment) - this should be verified and a 'CopyFrom' method should be created if it does not yet exist:
//ORIGINAL LINE: yyval = yylval;
				yyval.CopyFrom(yylval);
				yy_state = yy_n;
				if (yyerrflag > 0)
					yyerrflag--;
				goto yy_stack;
			}

		yydefault:
			if ((yy_n = yydef[yy_state]) == -2)
			{
	#if YYDEBUG
				yytmp = yychar < 0;
	#endif
				if ((yychar < 0) && ((yychar = yylex()) < 0))
					yychar = 0; // reached EOF 
	#if YYDEBUG
				if (yydebug != 0 && yytmp != 0)
				{
//C++ TO C# CONVERTER NOTE: 'register' variable declarations are not supported in C#:
//ORIGINAL LINE: register int yy_i;
					int yy_i;

					()printf("Received token ");
					if (yychar == 0)
						()printf("end-of-file\n");
					else if (yychar < 0)
						()printf("-none-\n");
					else
					{
						for (yy_i = 0; yytoks[yy_i].t_val >= 0; yy_i++)
						{
							if (yytoks[yy_i].t_val == yychar)
							{
								break;
							}
						}
						()printf("%s\n", yytoks[yy_i].t_name);
					}
				}
	#endif // YYDEBUG 
	//            
	//			** look through exception table
	//			
				{
//C++ TO C# CONVERTER NOTE: 'register' variable declarations are not supported in C#:
//ORIGINAL LINE: register int *yyxi = yyexca;
					int[] yyxi = yyexca;

					while ((*yyxi != -1) || (yyxi[1] != yy_state))
					{
						yyxi += 2;
					}
					while ((*(yyxi += 2) >= 0) && (*yyxi != yychar))
						;
					if ((yy_n = yyxi[1]) < 0)
						{ free(yys); free(yyv); return(0); };
				}
			}

	//        
	//		** check for syntax error
	//		
			if (yy_n == 0) // have an error 
			{
				// no worry about speed here! 
				switch (yyerrflag)
				{
				case 0: // new error 
					yyerror("syntax error");
					goto skip_init;
				yyerrlab:
	//                
	//				** get globals into registers.
	//				** we have a user generated syntax type error
	//				
					yy_pv = yypv;
					yy_ps = yyps;
					yy_state = yystate;
					yynerrs++;
				skip_init:
//C++ TO C# CONVERTER TODO TASK: C# does not allow fall-through from a non-empty 'case':
				case 1:
				case 2: // incompletely recovered error 
						// try again... 
					yyerrflag = 3;
	//                
	//				** find state where "error" is a legal
	//				** shift action
	//				
					while (yy_ps >= yys)
					{
						yy_n = yypact[ yy_ps] + DefineConstantsY_tab.YYERRCODE;
						if (yy_n >= 0 && yy_n < DefineConstantsY_tab.YYLAST && yychk[yyact[yy_n]] == DefineConstantsY_tab.YYERRCODE)
						{
	//                        
	//						** simulate shift of "error"
	//						
							yy_state = yyact[yy_n];
							goto yy_stack;
						}
	//                    
	//					** current state has no shift on
	//					** "error", pop stack
	//					
	#if YYDEBUG
	#define _POP_
						if (yydebug != 0)
							()printf(DefineConstantsY_tab._POP_, yy_ps, yy_ps[-1]);
	#undef _POP_
	#endif
						yy_ps--;
						yy_pv--;
					}
	//                
	//				** there is no state on stack with "error" as
	//				** a valid shift.  give up.
	//				
					{ free(yys); free(yyv); return(1); };
//C++ TO C# CONVERTER TODO TASK: C# does not allow fall-through from a non-empty 'case':
				case 3: // no shift yet; eat a token 
	#if YYDEBUG
	//                
	//				** if debugging, look up token in list of
	//				** pairs.  0 and negative shouldn't occur,
	//				** but since timing doesn't matter when
	//				** debugging, it doesn't hurt to leave the
	//				** tests here.
	//				
					if (yydebug != 0)
					{
//C++ TO C# CONVERTER NOTE: 'register' variable declarations are not supported in C#:
//ORIGINAL LINE: register int yy_i;
						int yy_i;

						()printf("Error recovery discards ");
						if (yychar == 0)
							()printf("token end-of-file\n");
						else if (yychar < 0)
							()printf("token -none-\n");
						else
						{
							for (yy_i = 0; yytoks[yy_i].t_val >= 0; yy_i++)
							{
								if (yytoks[yy_i].t_val == yychar)
								{
									break;
								}
							}
							()printf("token %s\n", yytoks[yy_i].t_name);
						}
					}
	#endif // YYDEBUG 
					if (yychar == 0) // reached EOF. quit 
						{ free(yys); free(yyv); return(1); };
					yychar = -1;
					goto yy_newstate;
				}
			} // end if ( yy_n == 0 ) 
	//        
	//		** reduction by production yy_n
	//		** put stack tops, etc. so things right after switch
	//		
	#if YYDEBUG
	//        
	//		** if debugging, print the string that is the user's
	//		** specification of the reduction which is just about
	//		** to be done.
	//		
			if (yydebug != 0)
				()printf("Reduce by (%d) \"%s\"\n", yy_n, yyreds[yy_n]);
	#endif
			yytmp = yy_n; // value to switch over 
			yypvt = yy_pv; // $vars top of value stack 
	//        
	//		** Look in goto table for next state
	//		** Sorry about using yy_state here as temporary
	//		** register variable, but why not, if it works...
	//		** If yyr2[ yy_n ] doesn't have the low order bit
	//		** set, then there is no action to be done for
	//		** this reduction.  So, no saving & unsaving of
	//		** registers done.  The only difference between the
	//		** code just after the if and the body of the if is
	//		** the goto yy_stack in the body.  This way the test
	//		** can be made before the choice of what to do is needed.
	//		
			{
				// length of production doubled with extra bit 
//C++ TO C# CONVERTER NOTE: 'register' variable declarations are not supported in C#:
//ORIGINAL LINE: register int yy_len = yyr2[yy_n];
				int yy_len = yyr2[yy_n];

	//C++ TO C# CONVERTER TODO TASK: Octal literals cannot be represented in C#:
				if (!(yy_len & 01))
				{
					yy_len >>= 1;
					yyval = (yy_pv -= yy_len)[1]; // $$ = $1 
					yy_state = yypgo[yy_n = yyr1[yy_n]] + *(yy_ps -= yy_len) + 1;
					if (yy_state >= DefineConstantsY_tab.YYLAST || yychk[yy_state = yyact[yy_state]] != -yy_n)
					{
						yy_state = yyact[yypgo[yy_n]];
					}
					goto yy_stack;
				}
				yy_len >>= 1;
				yyval = (yy_pv -= yy_len)[1]; // $$ = $1 
				yy_state = yypgo[yy_n = yyr1[yy_n]] + *(yy_ps -= yy_len) + 1;
				if (yy_state >= DefineConstantsY_tab.YYLAST || yychk[yy_state = yyact[yy_state]] != -yy_n)
				{
					yy_state = yyact[yypgo[yy_n]];
				}
			}
						// save until reenter driver code 
			yystate = yy_state;
			yyps = yy_ps;
			yypv = yy_pv;
		}
	//    
	//	** code supplied by user is placed in this switch
	//	
		switch(yytmp)
		{

	case 2:
	//# line 227 "lua.stx"
	{
				pc =maincode;
				basepc =initcode;
				maxcurr =maxmain;
			  nlocalvar =0;
				}
				break;
	case 3:
	//# line 232 "lua.stx"
	{
			  maincode =pc;
			  initcode =basepc;
			  maxmain =maxcurr;
			}
			break;
	case 6:
	//# line 240 "lua.stx"
	{
			if (code == null) // first function 
			{
	#if Byte_AlternateDefinition1
	#if Byte_AlternateDefinition1
//C++ TO C# CONVERTER TODO TASK: The memory management function 'calloc' has no equivalent in C#:
			 code = (byte) calloc(DefineConstantsY_tab.GAPCODE, sizeof(byte));
	#elif Byte_AlternateDefinition2
//C++ TO C# CONVERTER TODO TASK: The memory management function 'calloc' has no equivalent in C#:
			 code = (byte) calloc(DefineConstantsY_tab.GAPCODE, sizeof(byte));
	#endif
	#elif Byte_AlternateDefinition2
	#if Byte_AlternateDefinition1
//C++ TO C# CONVERTER TODO TASK: The memory management function 'calloc' has no equivalent in C#:
			 code = (byte) calloc(DefineConstantsY_tab.GAPCODE, sizeof(byte));
	#elif Byte_AlternateDefinition2
//C++ TO C# CONVERTER TODO TASK: The memory management function 'calloc' has no equivalent in C#:
			 code = (byte) calloc(DefineConstantsY_tab.GAPCODE, sizeof(byte));
	#endif
	#endif
			 if (code == null)
			 {
			  lua_error("not enough memory");
			  err = 1;
			 }
			 maxcode = DefineConstantsY_tab.GAPCODE;
			}
			pc =0;
			basepc =code;
			maxcurr =maxcode;
			nlocalvar =0;
			yyval.vWord = lua_findsymbol(ref yypvt[-0].pChar);
			   }
			   break;
	case 7:
	//# line 256 "lua.stx"
	{
				if (lua_debug != 0)
			{
				 code_byte(AnonymousEnum.SETFUNCTION);
					 code_word(lua_nfile-1);
			 code_word(yypvt[-3].vWord);
			}
				lua_codeadjust (0);
			   }
			   break;
	case 8:
	//# line 267 "lua.stx"
	{
					if (lua_debug != 0)
						code_byte(AnonymousEnum.RESET);
				code_byte(AnonymousEnum.RETCODE);
				code_byte(nlocalvar);
	#if s_tag_AlternateDefinition1
				((((lua_table[yypvt[-6].vWord].object)).tag)) = AnonymousEnum.T_FUNCTION;
	#elif s_tag_AlternateDefinition2
				((((lua_table[yypvt[-6].vWord].object)).tag)) = AnonymousEnum.T_FUNCTION;
	#elif s_tag_AlternateDefinition3
				((((lua_table[yypvt[-6].vWord].object)).tag)) = AnonymousEnum.T_FUNCTION;
	#endif
	#if s_bvalue_AlternateDefinition1
	#if Byte_AlternateDefinition1
//C++ TO C# CONVERTER TODO TASK: The memory management function 'calloc' has no equivalent in C#:
				((((lua_table[yypvt[-6].vWord].object)).value.b)) = calloc (pc, sizeof(byte));
	#elif Byte_AlternateDefinition2
//C++ TO C# CONVERTER TODO TASK: The memory management function 'calloc' has no equivalent in C#:
				((((lua_table[yypvt[-6].vWord].object)).value.b)) = calloc (pc, sizeof(byte));
	#endif
	#elif s_bvalue_AlternateDefinition2
	#if Byte_AlternateDefinition1
//C++ TO C# CONVERTER TODO TASK: The memory management function 'calloc' has no equivalent in C#:
				((((lua_table[yypvt[-6].vWord].object)).value.b)) = calloc (pc, sizeof(byte));
	#elif Byte_AlternateDefinition2
//C++ TO C# CONVERTER TODO TASK: The memory management function 'calloc' has no equivalent in C#:
				((((lua_table[yypvt[-6].vWord].object)).value.b)) = calloc (pc, sizeof(byte));
	#endif
	#endif
	#if s_bvalue_AlternateDefinition1
			if (((((lua_table[yypvt[-6].vWord].object)).value.b)) == null)
	#elif s_bvalue_AlternateDefinition2
			if (((((lua_table[yypvt[-6].vWord].object)).value.b)) == null)
	#endif
			{
			 lua_error("not enough memory");
			 err = 1;
			}
	#if s_bvalue_AlternateDefinition1
	#if Byte_AlternateDefinition1
//C++ TO C# CONVERTER TODO TASK: The memory management function 'memcpy' has no equivalent in C#:
				memcpy (((((lua_table[yypvt[-6].vWord].object)).value.b)), basepc, pc *sizeof(byte));
	#elif Byte_AlternateDefinition2
//C++ TO C# CONVERTER TODO TASK: The memory management function 'memcpy' has no equivalent in C#:
				memcpy (((((lua_table[yypvt[-6].vWord].object)).value.b)), basepc, pc *sizeof(byte));
	#endif
	#elif s_bvalue_AlternateDefinition2
	#if Byte_AlternateDefinition1
//C++ TO C# CONVERTER TODO TASK: The memory management function 'memcpy' has no equivalent in C#:
				memcpy (((((lua_table[yypvt[-6].vWord].object)).value.b)), basepc, pc *sizeof(byte));
	#elif Byte_AlternateDefinition2
//C++ TO C# CONVERTER TODO TASK: The memory management function 'memcpy' has no equivalent in C#:
				memcpy (((((lua_table[yypvt[-6].vWord].object)).value.b)), basepc, pc *sizeof(byte));
	#endif
	#endif
			code = basepc;
			maxcode =maxcurr;
	#if LISTING
	PrintCode(ref code, ref code+pc);
	#endif
			   }
			   break;
	case 11:
	//# line 289 "lua.stx"
	{
				ntemp = 0;
				if (lua_debug != 0)
				{
				 code_byte(AnonymousEnum.SETLINE);
				 code_word(lua_linenumber);
				}
		   }
		   break;
	case 15:
	//# line 302 "lua.stx"
	{
			{
	#if Word_AlternateDefinition1
	#if Word_AlternateDefinition1
		 ushort elseinit = yypvt[-2].vWord+sizeof(ushort)+1;
	#elif Word_AlternateDefinition2
		 ushort elseinit = yypvt[-2].vWord+sizeof(ushort)+1;
	#endif
	#elif Word_AlternateDefinition2
	#if Word_AlternateDefinition1
		 ushort elseinit = yypvt[-2].vWord+sizeof(ushort)+1;
	#elif Word_AlternateDefinition2
		 ushort elseinit = yypvt[-2].vWord+sizeof(ushort)+1;
	#endif
	#endif
		 if (pc - elseinit == 0) // no else 
		 {
	#if Word_AlternateDefinition1
		  pc -= sizeof(ushort)+1;
	#elif Word_AlternateDefinition2
		  pc -= sizeof(ushort)+1;
	#endif
		  elseinit = pc;
		 }
		 else
		 {
		  basepc[yypvt[-2].vWord] = AnonymousEnum.JMP;
		  code_word_at(ref basepc+yypvt[-2].vWord+1, pc - elseinit);
		 }
		 basepc[yypvt[-4].vWord] = AnonymousEnum.IFFJMP;
	#if Word_AlternateDefinition1
		 code_word_at(ref basepc+yypvt[-4].vWord+1, elseinit-(yypvt[-4].vWord+sizeof(ushort)+1));
	#elif Word_AlternateDefinition2
		 code_word_at(ref basepc+yypvt[-4].vWord+1, elseinit-(yypvt[-4].vWord+sizeof(ushort)+1));
	#endif
		}
		   }
		   break;
	case 16:
	//# line 320 "lua.stx"
	{
		yyval.vWord =pc;
	}
	break;
	case 17:
	//# line 322 "lua.stx"
	{
			basepc[yypvt[-3].vWord] = AnonymousEnum.IFFJMP;
	#if Word_AlternateDefinition1
		code_word_at(ref basepc+yypvt[-3].vWord+1, pc - (yypvt[-3].vWord + sizeof(ushort)+1));
	#elif Word_AlternateDefinition2
		code_word_at(ref basepc+yypvt[-3].vWord+1, pc - (yypvt[-3].vWord + sizeof(ushort)+1));
	#endif

			basepc[yypvt[-1].vWord] = AnonymousEnum.UPJMP;
		code_word_at(ref basepc+yypvt[-1].vWord+1, pc - (yypvt[-6].vWord));
		   }
		   break;
	case 18:
	//# line 330 "lua.stx"
	{
		yyval.vWord =pc;
	}
	break;
	case 19:
	//# line 332 "lua.stx"
	{
			basepc[yypvt[-0].vWord] = AnonymousEnum.IFFUPJMP;
		code_word_at(ref basepc+yypvt[-0].vWord+1, pc - (yypvt[-4].vWord));
		   }
		   break;
	case 20:
	//# line 339 "lua.stx"
	{
			{
			 int i;
			 if (yypvt[-0].vInt == 0 || nvarbuffer != ntemp - yypvt[-2].vInt * 2)
		  lua_codeadjust (yypvt[-2].vInt * 2 + nvarbuffer);
		 for (i =nvarbuffer-1; i>=0; i--)
		  lua_codestore (i);
		 if (yypvt[-2].vInt > 1 || (yypvt[-2].vInt == 1 && varbuffer[0] != 0))
		  lua_codeadjust (0);
		}
		   }
		   break;
	case 21:
	//# line 350 "lua.stx"
	{
		lua_codeadjust (0);
	}
	break;
	case 22:
	//# line 351 "lua.stx"
	{
		lua_codeadjust (0);
	}
	break;
	case 23:
	//# line 352 "lua.stx"
	{
		add_nlocalvar(yypvt[-1].vInt);
		lua_codeadjust (0);
	}
	break;
	case 26:
	//# line 358 "lua.stx"
	{
			  {
	#if Word_AlternateDefinition1
	#if Word_AlternateDefinition1
			 ushort elseinit = yypvt[-1].vWord+sizeof(ushort)+1;
	#elif Word_AlternateDefinition2
			 ushort elseinit = yypvt[-1].vWord+sizeof(ushort)+1;
	#endif
	#elif Word_AlternateDefinition2
	#if Word_AlternateDefinition1
			 ushort elseinit = yypvt[-1].vWord+sizeof(ushort)+1;
	#elif Word_AlternateDefinition2
			 ushort elseinit = yypvt[-1].vWord+sizeof(ushort)+1;
	#endif
	#endif
			 if (pc - elseinit == 0) // no else 
			 {
	#if Word_AlternateDefinition1
			  pc -= sizeof(ushort)+1;
	#elif Word_AlternateDefinition2
			  pc -= sizeof(ushort)+1;
	#endif
			elseinit = pc;
		   }
		   else
		   {
			basepc[yypvt[-1].vWord] = AnonymousEnum.JMP;
			code_word_at(ref basepc+yypvt[-1].vWord+1, pc - elseinit);
		   }
		   basepc[yypvt[-3].vWord] = AnonymousEnum.IFFJMP;
	#if Word_AlternateDefinition1
		   code_word_at(ref basepc+yypvt[-3].vWord+1, elseinit - (yypvt[-3].vWord + sizeof(ushort)+1));
	#elif Word_AlternateDefinition2
		   code_word_at(ref basepc+yypvt[-3].vWord+1, elseinit - (yypvt[-3].vWord + sizeof(ushort)+1));
	#endif
		  }
			 }
			 break;
	case 27:
	//# line 377 "lua.stx"
	{
		yyval.vInt = nlocalvar;
	}
	break;
	case 28:
	//# line 377 "lua.stx"
	{
		ntemp = 0;
	}
	break;
	case 29:
	//# line 378 "lua.stx"
	{
		  if (nlocalvar != yypvt[-3].vInt)
		  {
			   nlocalvar = yypvt[-3].vInt;
		   lua_codeadjust (0);
		  }
			 }
			 break;
	case 31:
	//# line 388 "lua.stx"
	{
		if (lua_debug != 0)
		{
			code_byte(AnonymousEnum.SETLINE);
			code_word(lua_linenumber);
		}
	}
	break;
	case 32:
	//# line 390 "lua.stx"
	{
			   if (lua_debug != 0)
				   code_byte(AnonymousEnum.RESET);
			   code_byte(AnonymousEnum.RETCODE);
			   code_byte(nlocalvar);
			  }
			  break;
	case 33:
	//# line 397 "lua.stx"
	{
		  yyval.vWord = pc;
		  code_byte(0); // open space 
		  code_word (0);
			 }
			 break;
	case 34:
	//# line 403 "lua.stx"
	{
		if (yypvt[-0].vInt == 0)
		{
			lua_codeadjust (ntemp+1);
			incr_ntemp();
		}
	}
	break;
	case 35:
	//# line 406 "lua.stx"
	{
		yyval.vInt = yypvt[-1].vInt;
	}
	break;
	case 36:
	//# line 407 "lua.stx"
	{
		code_byte(AnonymousEnum.EQOP);
		yyval.vInt = 1;
		ntemp--;
	}
	break;
	case 37:
	//# line 408 "lua.stx"
	{
		code_byte(AnonymousEnum.LTOP);
		yyval.vInt = 1;
		ntemp--;
	}
	break;
	case 38:
	//# line 409 "lua.stx"
	{
		code_byte(AnonymousEnum.LEOP);
		code_byte(AnonymousEnum.NOTOP);
		yyval.vInt = 1;
		ntemp--;
	}
	break;
	case 39:
	//# line 410 "lua.stx"
	{
		code_byte(AnonymousEnum.EQOP);
		code_byte(AnonymousEnum.NOTOP);
		yyval.vInt = 1;
		ntemp--;
	}
	break;
	case 40:
	//# line 411 "lua.stx"
	{
		code_byte(AnonymousEnum.LEOP);
		yyval.vInt = 1;
		ntemp--;
	}
	break;
	case 41:
	//# line 412 "lua.stx"
	{
		code_byte(AnonymousEnum.LTOP);
		code_byte(AnonymousEnum.NOTOP);
		yyval.vInt = 1;
		ntemp--;
	}
	break;
	case 42:
	//# line 413 "lua.stx"
	{
		code_byte(AnonymousEnum.ADDOP);
		yyval.vInt = 1;
		ntemp--;
	}
	break;
	case 43:
	//# line 414 "lua.stx"
	{
		code_byte(AnonymousEnum.SUBOP);
		yyval.vInt = 1;
		ntemp--;
	}
	break;
	case 44:
	//# line 415 "lua.stx"
	{
		code_byte(AnonymousEnum.MULTOP);
		yyval.vInt = 1;
		ntemp--;
	}
	break;
	case 45:
	//# line 416 "lua.stx"
	{
		code_byte(AnonymousEnum.DIVOP);
		yyval.vInt = 1;
		ntemp--;
	}
	break;
	case 46:
	//# line 417 "lua.stx"
	{
		code_byte(AnonymousEnum.CONCOP);
		yyval.vInt = 1;
		ntemp--;
	}
	break;
	case 47:
	//# line 418 "lua.stx"
	{
		yyval.vInt = 1;
	}
	break;
	case 48:
	//# line 419 "lua.stx"
	{
		code_byte(AnonymousEnum.MINUSOP);
		yyval.vInt = 1;
	}
	break;
	case 49:
	//# line 420 "lua.stx"
	{
		yyval.vInt = yypvt[-0].vInt;
	}
	break;
	case 50:
	//# line 422 "lua.stx"
	{
		  code_byte(AnonymousEnum.CREATEARRAY);
		  yyval.vInt = 1;
		 }
		 break;
	case 51:
	//# line 426 "lua.stx"
	{
		lua_pushvar (yypvt[-0].vLong);
		yyval.vInt = 1;
	}
	break;
	case 52:
	//# line 427 "lua.stx"
	{
		code_number(yypvt[-0].vFloat);
		yyval.vInt = 1;
	}
	break;
	case 53:
	//# line 429 "lua.stx"
	{
		  code_byte(AnonymousEnum.PUSHSTRING);
		  code_word(yypvt[-0].vWord);
		  yyval.vInt = 1;
		  incr_ntemp();
		 }
		 break;
	case 54:
	//# line 435 "lua.stx"
	{
		code_byte(AnonymousEnum.PUSHNIL);
		yyval.vInt = 1;
		incr_ntemp();
	}
	break;
	case 55:
	//# line 437 "lua.stx"
	{
		  yyval.vInt = 0;
		  if (lua_debug != 0)
		  {
		   code_byte(AnonymousEnum.SETLINE);
		   code_word(lua_linenumber);
		  }
		 }
		 break;
	case 56:
	//# line 444 "lua.stx"
	{
		code_byte(AnonymousEnum.NOTOP);
		yyval.vInt = 1;
	}
	break;
	case 57:
	//# line 445 "lua.stx"
	{
		code_byte(AnonymousEnum.POP);
		ntemp--;
	}
	break;
	case 58:
	//# line 446 "lua.stx"
	{
		  basepc[yypvt[-2].vWord] = AnonymousEnum.ONFJMP;
	#if Word_AlternateDefinition1
		  code_word_at(ref basepc+yypvt[-2].vWord+1, pc - (yypvt[-2].vWord + sizeof(ushort)+1));
	#elif Word_AlternateDefinition2
		  code_word_at(ref basepc+yypvt[-2].vWord+1, pc - (yypvt[-2].vWord + sizeof(ushort)+1));
	#endif
		  yyval.vInt = 1;
		 }
		 break;
	case 59:
	//# line 451 "lua.stx"
	{
		code_byte(AnonymousEnum.POP);
		ntemp--;
	}
	break;
	case 60:
	//# line 452 "lua.stx"
	{
		  basepc[yypvt[-2].vWord] = AnonymousEnum.ONTJMP;
	#if Word_AlternateDefinition1
		  code_word_at(ref basepc+yypvt[-2].vWord+1, pc - (yypvt[-2].vWord + sizeof(ushort)+1));
	#elif Word_AlternateDefinition2
		  code_word_at(ref basepc+yypvt[-2].vWord+1, pc - (yypvt[-2].vWord + sizeof(ushort)+1));
	#endif
		  yyval.vInt = 1;
		 }
		 break;
	case 61:
	//# line 460 "lua.stx"
	{
		  code_byte(AnonymousEnum.PUSHBYTE);
		  yyval.vWord = pc;
		  code_byte(0);
		  incr_ntemp();
		  code_byte(AnonymousEnum.CREATEARRAY);
		 }
		 break;
	case 62:
	//# line 467 "lua.stx"
	{
		  basepc[yypvt[-2].vWord] = yypvt[-0].vInt;
		  if (yypvt[-1].vLong < 0) // there is no function to be called 
		  {
		   yyval.vInt = 1;
		  }
		  else
		  {
		   lua_pushvar (yypvt[-1].vLong+1);
		   code_byte(AnonymousEnum.PUSHMARK);
		   incr_ntemp();
		   code_byte(AnonymousEnum.PUSHOBJECT);
		   incr_ntemp();
		   code_byte(AnonymousEnum.CALLFUNC);
		   ntemp -= 4;
		   yyval.vInt = 0;
		   if (lua_debug != 0)
		   {
			code_byte(AnonymousEnum.SETLINE);
			code_word(lua_linenumber);
		   }
		  }
		 }
		 break;
	case 63:
	//# line 491 "lua.stx"
	{
		code_byte(AnonymousEnum.PUSHNIL);
		incr_ntemp();
	}
	break;
	case 65:
	//# line 495 "lua.stx"
	{
		code_byte(AnonymousEnum.PUSHMARK);
		yyval.vInt = ntemp;
		incr_ntemp();
	}
	break;
	case 66:
	//# line 496 "lua.stx"
	{
		code_byte(AnonymousEnum.CALLFUNC);
		ntemp = yypvt[-3].vInt-1;
	}
	break;
	case 67:
	//# line 498 "lua.stx"
	{
		lua_pushvar (yypvt[-0].vLong);
	}
	break;
	case 68:
	//# line 501 "lua.stx"
	{
		yyval.vInt = 1;
	}
	break;
	case 69:
	//# line 502 "lua.stx"
	{
		yyval.vInt = yypvt[-0].vInt;
	}
	break;
	case 70:
	//# line 505 "lua.stx"
	{
		yyval.vInt = yypvt[-0].vInt;
	}
	break;
	case 71:
	//# line 506 "lua.stx"
	{
		if (yypvt[-1].vInt == 0)
		{
			lua_codeadjust (ntemp+1);
			incr_ntemp();
		}
	}
	break;
	case 72:
	//# line 507 "lua.stx"
	{
		yyval.vInt = yypvt[-0].vInt;
	}
	break;
	case 75:
	//# line 515 "lua.stx"
	{
			 localvar[nlocalvar] =lua_findsymbol(ref yypvt[-0].pChar);
			 add_nlocalvar(1);
			}
			break;
	case 76:
	//# line 520 "lua.stx"
	{
			 localvar[nlocalvar] =lua_findsymbol(ref yypvt[-0].pChar);
			 add_nlocalvar(1);
			}
			break;
	case 77:
	//# line 526 "lua.stx"
	{
		yyval.vLong =-1;
	}
	break;
	case 78:
	//# line 527 "lua.stx"
	{
		yyval.vLong =lua_findsymbol(ref yypvt[-0].pChar);
	}
	break;
	case 79:
	//# line 531 "lua.stx"
	{
			   flush_record(yypvt[-1].vInt%DefineConstantsY_tab.FIELDS_PER_FLUSH);
			   yyval.vInt = yypvt[-1].vInt;
			  }
			  break;
	case 80:
	//# line 536 "lua.stx"
	{
			   flush_list(yypvt[-1].vInt/DefineConstantsY_tab.FIELDS_PER_FLUSH, yypvt[-1].vInt%DefineConstantsY_tab.FIELDS_PER_FLUSH);
			   yyval.vInt = yypvt[-1].vInt;
				   }
				   break;
	case 81:
	//# line 542 "lua.stx"
	{
		yyval.vInt = 0;
	}
	break;
	case 82:
	//# line 543 "lua.stx"
	{
		yyval.vInt = yypvt[-0].vInt;
	}
	break;
	case 83:
	//# line 546 "lua.stx"
	{
		yyval.vInt =1;
	}
	break;
	case 84:
	//# line 548 "lua.stx"
	{
			  yyval.vInt =yypvt[-2].vInt+1;
			  if (yyval.vInt%DefineConstantsY_tab.FIELDS_PER_FLUSH == 0)
				  flush_record(DefineConstantsY_tab.FIELDS_PER_FLUSH);
			}
			break;
	case 85:
	//# line 554 "lua.stx"
	{
		yyval.vWord = lua_findconstant(ref yypvt[-0].pChar);
	}
	break;
	case 86:
	//# line 555 "lua.stx"
	{
			   push_field(yypvt[-2].vWord);
			  }
			  break;
	case 87:
	//# line 560 "lua.stx"
	{
		yyval.vInt = 0;
	}
	break;
	case 88:
	//# line 561 "lua.stx"
	{
		yyval.vInt = yypvt[-0].vInt;
	}
	break;
	case 89:
	//# line 564 "lua.stx"
	{
		yyval.vInt =1;
	}
	break;
	case 90:
	//# line 566 "lua.stx"
	{
			  yyval.vInt =yypvt[-2].vInt+1;
			  if (yyval.vInt%DefineConstantsY_tab.FIELDS_PER_FLUSH == 0)
				flush_list(yyval.vInt/DefineConstantsY_tab.FIELDS_PER_FLUSH - 1, DefineConstantsY_tab.FIELDS_PER_FLUSH);
			}
			break;
	case 91:
	//# line 574 "lua.stx"
	{
		   nvarbuffer = 0;
			   varbuffer[nvarbuffer] = yypvt[-0].vLong;
			   incr_nvarbuffer();
		   yyval.vInt = (yypvt[-0].vLong == 0) ? 1 : 0;
		  }
		  break;
	case 92:
	//# line 580 "lua.stx"
	{
			   varbuffer[nvarbuffer] = yypvt[-0].vLong;
			   incr_nvarbuffer();
		   yyval.vInt = (yypvt[-0].vLong == 0) ? yypvt[-2].vInt + 1 : yypvt[-2].vInt;
		  }
		  break;
	case 93:
	//# line 587 "lua.stx"
	{
	#if Word_AlternateDefinition1
		   ushort s = lua_findsymbol(ref yypvt[-0].pChar);
	#elif Word_AlternateDefinition2
		   ushort s = lua_findsymbol(ref yypvt[-0].pChar);
	#endif
		   int local = lua_localname (s);
		   if (local == -1) // global var 
			yyval.vLong = s + 1; // return positive value 
			   else
			yyval.vLong = -(local+1); // return negative value 
		  }
		  break;
	case 94:
	//# line 596 "lua.stx"
	{
		lua_pushvar (yypvt[-0].vLong);
	}
	break;
	case 95:
	//# line 597 "lua.stx"
	{
		   yyval.vLong = 0; // indexed variable 
		  }
		  break;
	case 96:
	//# line 600 "lua.stx"
	{
		lua_pushvar (yypvt[-0].vLong);
	}
	break;
	case 97:
	//# line 601 "lua.stx"
	{
		   code_byte(AnonymousEnum.PUSHSTRING);
		   code_word(lua_findconstant(ref yypvt[-0].pChar));
		   incr_ntemp();
		   yyval.vLong = 0; // indexed variable 
		  }
		  break;
	case 98:
	//# line 608 "lua.stx"
	{
		localvar[nlocalvar] =lua_findsymbol(ref yypvt[-0].pChar);
		yyval.vInt = 1;
	}
	break;
	case 99:
	//# line 610 "lua.stx"
	{
			 localvar[nlocalvar+yypvt[-2].vInt] =lua_findsymbol(ref yypvt[-0].pChar);
			 yyval.vInt = yypvt[-2].vInt+1;
			}
			break;
	case 102:
	//# line 620 "lua.stx"
	{
		lua_debug = yypvt[-0].vInt;
	}
	break;
		}
		goto yystack; // reset registers in driver code 
	}
}


//# line 184 "lua.stx"
//C++ TO C# CONVERTER TODO TASK: Unions are not supported in C#, but the following union can be simulated with the StructLayout and FieldOffset attributes.
//ORIGINAL LINE: typedef union
[StructLayout(LayoutKind.Explicit)]
public struct YYSTYPE
{
 [FieldOffset(0)]
 public int vInt;
 [FieldOffset(0)]
 public int vLong;
 [FieldOffset(0)]
 public float vFloat;
 [FieldOffset(0)]
 public string pChar;
#if Word_AlternateDefinition1
 [FieldOffset(0)]
 public ushort vWord;
#elif Word_AlternateDefinition2
 [FieldOffset(0)]
 public ushort vWord;
#endif
#if Byte_AlternateDefinition1
 [FieldOffset(0)]
 public byte pByte;
#elif Byte_AlternateDefinition2
 [FieldOffset(0)]
 public byte pByte;
#endif
}
public class yytoktype
{
	public string t_name;
	public int t_val;
}
#if ! YYDEBUG
#define YYDEBUG_AlternateDefinition1
#define YYDEBUG
#endif
