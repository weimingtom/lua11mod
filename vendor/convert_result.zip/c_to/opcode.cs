using System;
public static class GlobalMembersOpcode
{
	//
	//** opcode.c
	//** TecCGraf - PUC-Rio
	//

	public static string rcs_opcode ="$Id: opcode.c,v 2.1 1994/04/20 22:07:57 celes Exp $";


	// stdlib.h does not have this in SunOS 
//C++ TO C# CONVERTER TODO TASK: The implementation of the following method could not be found:
	//extern double strtod(string NamelessParameter1, sbyte NamelessParameter2);


	//
	//** TeCGraf - PUC-Rio
	//** $Id: opcode.h,v 2.1 1994/04/20 22:07:57 celes Exp $
	//

	#if ! opcode_h
	#define opcode_h

	#if ! STACKGAP
	#define STACKGAP
	#endif

	#if ! real
	//C++ TO C# CONVERTER NOTE: The following #define macro was replaced in-line:
	//ORIGINAL LINE: #define real float
	#define real
	#endif

	public static delegate void Cfunction();
	public static delegate int Input();
	#define s_nvalue_AlternateDefinition1
	//C++ TO C# CONVERTER NOTE: The following #define macro was replaced in-line:
	//ORIGINAL LINE: #define s_nvalue(i) (((&(lua_table[i].object))->value.n))
	#define s_nvalue
	#define s_svalue_AlternateDefinition1
	//C++ TO C# CONVERTER NOTE: The following #define macro was replaced in-line:
	//ORIGINAL LINE: #define s_svalue(i) (((&(lua_table[i].object))->value.s))
	#define s_svalue
	#define s_bvalue_AlternateDefinition1
	//C++ TO C# CONVERTER NOTE: The following #define macro was replaced in-line:
	//ORIGINAL LINE: #define s_bvalue(i) (((&(lua_table[i].object))->value.b))
	#define s_bvalue
	#define s_avalue_AlternateDefinition1
	//C++ TO C# CONVERTER NOTE: The following #define macro was replaced in-line:
	//ORIGINAL LINE: #define s_avalue(i) (((&(lua_table[i].object))->value.a))
	#define s_avalue
	#define s_fvalue_AlternateDefinition1
	//C++ TO C# CONVERTER NOTE: The following #define macro was replaced in-line:
	//ORIGINAL LINE: #define s_fvalue(i) (((&(lua_table[i].object))->value.f))
	#define s_fvalue
	#define s_uvalue_AlternateDefinition1
	//C++ TO C# CONVERTER NOTE: The following #define macro was replaced in-line:
	//ORIGINAL LINE: #define s_uvalue(i) (((&(lua_table[i].object))->value.u))
	#define s_uvalue

	#define get_word_AlternateDefinition1
	//C++ TO C# CONVERTER NOTE: The following #define macro was replaced in-line:
	//ORIGINAL LINE: #define get_word(code,pc) {code.m.c1 = *pc++; code.m.c2 = *pc++;}
	#define get_word
	#define get_float_AlternateDefinition1
	//C++ TO C# CONVERTER NOTE: The following #define macro was replaced in-line:
	//ORIGINAL LINE: #define get_float(code,pc) {code.m.c1 = *pc++; code.m.c2 = *pc++; code.m.c3 = *pc++; code.m.c4 = *pc++;}
	#define get_float



	// Exported functions 
	public static int lua_execute(ref byte pc)
	#elif Byte_AlternateDefinition2
	int lua_execute (ref byte pc)
	#endif
	{
	 Object oldbase = @base;
	 @base = top;
	 while (1)
	 {
	  OpCode opcode = new OpCode();
	  switch (opcode = (OpCode) pc++)
	  {
	   case AnonymousEnum.PUSHNIL:
	#if tag_AlternateDefinition1
		   ((top++).tag) = AnonymousEnum.T_NIL;
	#elif tag_AlternateDefinition2
		   ((top++).tag) = AnonymousEnum.T_NIL;
	#endif
		   break;

	   case AnonymousEnum.PUSH0:
	#if tag_AlternateDefinition1
		   ((top).tag) = AnonymousEnum.T_NUMBER;
	#elif tag_AlternateDefinition2
		   ((top).tag) = AnonymousEnum.T_NUMBER;
	#endif
	#if nvalue_AlternateDefinition1
		   ((top++).value.n) = 0;
	#elif nvalue_AlternateDefinition2
		   ((top++).value.n) = 0;
	#endif
		   break;
	   case AnonymousEnum.PUSH1:
	#if tag_AlternateDefinition1
		   ((top).tag) = AnonymousEnum.T_NUMBER;
	#elif tag_AlternateDefinition2
		   ((top).tag) = AnonymousEnum.T_NUMBER;
	#endif
	#if nvalue_AlternateDefinition1
		   ((top++).value.n) = 1;
	#elif nvalue_AlternateDefinition2
		   ((top++).value.n) = 1;
	#endif
		   break;
	   case AnonymousEnum.PUSH2:
	#if tag_AlternateDefinition1
		   ((top).tag) = AnonymousEnum.T_NUMBER;
	#elif tag_AlternateDefinition2
		   ((top).tag) = AnonymousEnum.T_NUMBER;
	#endif
	#if nvalue_AlternateDefinition1
		   ((top++).value.n) = 2;
	#elif nvalue_AlternateDefinition2
		   ((top++).value.n) = 2;
	#endif
		   break;

	   case AnonymousEnum.PUSHBYTE:
	#if tag_AlternateDefinition1
		   ((top).tag) = AnonymousEnum.T_NUMBER;
	#elif tag_AlternateDefinition2
		   ((top).tag) = AnonymousEnum.T_NUMBER;
	#endif
	#if nvalue_AlternateDefinition1
		   ((top++).value.n) = pc++;
	#elif nvalue_AlternateDefinition2
		   ((top++).value.n) = pc++;
	#endif
		   break;

	   case AnonymousEnum.PUSHWORD:
	   {
		CodeWord code = new CodeWord();
	#if get_word_AlternateDefinition1
		{
			code.m.c1 = pc++;
			code.m.c2 = pc++;
		}
	#elif get_word_AlternateDefinition2
		{
			code.m.c1 = pc++;
			code.m.c2 = pc++;
		}
	#endif
	#if tag_AlternateDefinition1
		((top).tag) = AnonymousEnum.T_NUMBER;
	#elif tag_AlternateDefinition2
		((top).tag) = AnonymousEnum.T_NUMBER;
	#endif
	#if nvalue_AlternateDefinition1
		((top++).value.n) = code.w;
	#elif nvalue_AlternateDefinition2
		((top++).value.n) = code.w;
	#endif
	   }
	   break;

	   case AnonymousEnum.PUSHFLOAT:
	   {
		CodeFloat code = new CodeFloat();
	#if get_float_AlternateDefinition1
		{
			code.m.c1 = pc++;
			code.m.c2 = pc++;
			code.m.c3 = pc++;
			code.m.c4 = pc++;
		}
	#elif get_float_AlternateDefinition2
		{
			code.m.c1 = pc++;
			code.m.c2 = pc++;
			code.m.c3 = pc++;
			code.m.c4 = pc++;
		}
	#endif
	#if tag_AlternateDefinition1
		((top).tag) = AnonymousEnum.T_NUMBER;
	#elif tag_AlternateDefinition2
		((top).tag) = AnonymousEnum.T_NUMBER;
	#endif
	#if nvalue_AlternateDefinition1
		((top++).value.n) = code.f;
	#elif nvalue_AlternateDefinition2
		((top++).value.n) = code.f;
	#endif
	   }
	   break;

	   case AnonymousEnum.PUSHSTRING:
	   {
		CodeWord code = new CodeWord();
	#if get_word_AlternateDefinition1
		{
			code.m.c1 = pc++;
			code.m.c2 = pc++;
		}
	#elif get_word_AlternateDefinition2
		{
			code.m.c1 = pc++;
			code.m.c2 = pc++;
		}
	#endif
	#if tag_AlternateDefinition1
		((top).tag) = AnonymousEnum.T_STRING;
	#elif tag_AlternateDefinition2
		((top).tag) = AnonymousEnum.T_STRING;
	#endif
	#if svalue_AlternateDefinition1
		((top++).value.s) = lua_constant[code.w];
	#elif svalue_AlternateDefinition2
		((top++).value.s) = lua_constant[code.w];
	#endif
	   }
	   break;

	   case AnonymousEnum.PUSHLOCAL0:
		   case AnonymousEnum.PUSHLOCAL1:
			   case AnonymousEnum.PUSHLOCAL2:
	   case AnonymousEnum.PUSHLOCAL3:
		   case AnonymousEnum.PUSHLOCAL4:
			   case AnonymousEnum.PUSHLOCAL5:
	   case AnonymousEnum.PUSHLOCAL6:
		   case AnonymousEnum.PUSHLOCAL7:
			   case AnonymousEnum.PUSHLOCAL8:
	   case AnonymousEnum.PUSHLOCAL9:
		   top++= *(@base + (int)(opcode-AnonymousEnum.PUSHLOCAL0));
		   break;

	   case AnonymousEnum.PUSHLOCAL:
		   top++= *(@base + ( pc++));
		   break;

	   case AnonymousEnum.PUSHGLOBAL:
	   {
		CodeWord code = new CodeWord();
	#if get_word_AlternateDefinition1
		{
			code.m.c1 = pc++;
			code.m.c2 = pc++;
		}
	#elif get_word_AlternateDefinition2
		{
			code.m.c1 = pc++;
			code.m.c2 = pc++;
		}
	#endif
	#if s_object_AlternateDefinition1
		top++= (lua_table[code.w].object);
	#elif s_object_AlternateDefinition2
		top++= (lua_table[code.w].object);
	#endif
	   }
	   break;

	   case AnonymousEnum.PUSHINDEXED:
		--top;
	#if tag_AlternateDefinition1
		if (((top-1).tag) != AnonymousEnum.T_ARRAY)
	#elif tag_AlternateDefinition2
		if (((top-1).tag) != AnonymousEnum.T_ARRAY)
	#endif
		{
		 lua_reportbug ("indexed expression not a table");
		 return 1;
		}
		{
	#if avalue_AlternateDefinition1
		 Object h = lua_hashdefine (((top-1).value.a), top);
	#elif avalue_AlternateDefinition2
		 Object h = lua_hashdefine (((top-1).value.a), top);
	#endif
		 if (h == null)
			 return 1;
		 *(top-1) = h;
		}
	   break;

	   case AnonymousEnum.PUSHMARK:
	#if tag_AlternateDefinition1
		   ((top++).tag) = AnonymousEnum.T_MARK;
	#elif tag_AlternateDefinition2
		   ((top++).tag) = AnonymousEnum.T_MARK;
	#endif
		   break;

	   case AnonymousEnum.PUSHOBJECT:
		   top = *(top-3);
		   top++;
		   break;

	   case AnonymousEnum.STORELOCAL0:
		   case AnonymousEnum.STORELOCAL1:
			   case AnonymousEnum.STORELOCAL2:
	   case AnonymousEnum.STORELOCAL3:
		   case AnonymousEnum.STORELOCAL4:
			   case AnonymousEnum.STORELOCAL5:
	   case AnonymousEnum.STORELOCAL6:
		   case AnonymousEnum.STORELOCAL7:
			   case AnonymousEnum.STORELOCAL8:
	   case AnonymousEnum.STORELOCAL9:
		   *(@base + (int)(opcode-AnonymousEnum.STORELOCAL0)) = *(--top);
		   break;

	   case AnonymousEnum.STORELOCAL:
		   *(@base + ( pc++)) = *(--top);
		   break;

	   case AnonymousEnum.STOREGLOBAL:
	   {
		CodeWord code = new CodeWord();
	#if get_word_AlternateDefinition1
		{
			code.m.c1 = pc++;
			code.m.c2 = pc++;
		}
	#elif get_word_AlternateDefinition2
		{
			code.m.c1 = pc++;
			code.m.c2 = pc++;
		}
	#endif
	#if s_object_AlternateDefinition1
		(lua_table[code.w].object) = *(--top);
	#elif s_object_AlternateDefinition2
		(lua_table[code.w].object) = *(--top);
	#endif
	   }
	   break;

	   case AnonymousEnum.STOREINDEXED0:
	#if tag_AlternateDefinition1
		if (((top-3).tag) != AnonymousEnum.T_ARRAY)
	#elif tag_AlternateDefinition2
		if (((top-3).tag) != AnonymousEnum.T_ARRAY)
	#endif
		{
		 lua_reportbug ("indexed expression not a table");
		 return 1;
		}
		{
	#if avalue_AlternateDefinition1
		 Object h = lua_hashdefine (((top-3).value.a), top-2);
	#elif avalue_AlternateDefinition2
		 Object h = lua_hashdefine (((top-3).value.a), top-2);
	#endif
		 if (h == null)
			 return 1;
		 h = *(top-1);
		}
		top -= 3;
	   break;

	   case AnonymousEnum.STOREINDEXED:
	   {
		int n = pc++;
	#if tag_AlternateDefinition1
		if (((top-3-n).tag) != AnonymousEnum.T_ARRAY)
	#elif tag_AlternateDefinition2
		if (((top-3-n).tag) != AnonymousEnum.T_ARRAY)
	#endif
		{
		 lua_reportbug ("indexed expression not a table");
		 return 1;
		}
		{
	#if avalue_AlternateDefinition1
		 Object h = lua_hashdefine (((top-3-n).value.a), top-2-n);
	#elif avalue_AlternateDefinition2
		 Object h = lua_hashdefine (((top-3-n).value.a), top-2-n);
	#endif
		 if (h == null)
			 return 1;
		 h = *(top-1);
		}
		top--;
	   }
	   break;

	   case AnonymousEnum.STORELIST0:
	   case AnonymousEnum.STORELIST:
	   {
		int m;
		int n;
		Object arr;
		if (opcode == AnonymousEnum.STORELIST0)
			m = 0;
		else
			m = *(pc++) * DefineConstantsOpcode.FIELDS_PER_FLUSH;
		n = *(pc++);
		arr = top-n-1;
	#if tag_AlternateDefinition1
		if (((arr).tag) != AnonymousEnum.T_ARRAY)
	#elif tag_AlternateDefinition2
		if (((arr).tag) != AnonymousEnum.T_ARRAY)
	#endif
		{
		 lua_reportbug ("internal error - table expected");
		 return 1;
		}
		while (n != 0)
		{
	#if tag_AlternateDefinition1
		 ((top).tag) = AnonymousEnum.T_NUMBER;
	#elif tag_AlternateDefinition2
		 ((top).tag) = AnonymousEnum.T_NUMBER;
	#endif
	#if nvalue_AlternateDefinition1
		 ((top).value.n) = n+m;
	#elif nvalue_AlternateDefinition2
		 ((top).value.n) = n+m;
	#endif
	#if avalue_AlternateDefinition1
		 *(lua_hashdefine (((arr).value.a), top)) = *(top-1);
	#elif avalue_AlternateDefinition2
		 *(lua_hashdefine (((arr).value.a), top)) = *(top-1);
	#endif
		 top--;
		 n--;
		}
	   }
	   break;

	   case AnonymousEnum.STORERECORD:
	   {
		int n = *(pc++);
		Object arr = top-n-1;
	#if tag_AlternateDefinition1
		if (((arr).tag) != AnonymousEnum.T_ARRAY)
	#elif tag_AlternateDefinition2
		if (((arr).tag) != AnonymousEnum.T_ARRAY)
	#endif
		{
		 lua_reportbug ("internal error - table expected");
		 return 1;
		}
		while (n != 0)
		{
		 CodeWord code = new CodeWord();
	#if get_word_AlternateDefinition1
		 {
			 code.m.c1 = pc++;
			 code.m.c2 = pc++;
		 }
	#elif get_word_AlternateDefinition2
		 {
			 code.m.c1 = pc++;
			 code.m.c2 = pc++;
		 }
	#endif
	#if tag_AlternateDefinition1
		 ((top).tag) = AnonymousEnum.T_STRING;
	#elif tag_AlternateDefinition2
		 ((top).tag) = AnonymousEnum.T_STRING;
	#endif
	#if svalue_AlternateDefinition1
		 ((top).value.s) = lua_constant[code.w];
	#elif svalue_AlternateDefinition2
		 ((top).value.s) = lua_constant[code.w];
	#endif
	#if avalue_AlternateDefinition1
		 *(lua_hashdefine (((arr).value.a), top)) = *(top-1);
	#elif avalue_AlternateDefinition2
		 *(lua_hashdefine (((arr).value.a), top)) = *(top-1);
	#endif
		 top--;
		 n--;
		}
	   }
	   break;

	   case AnonymousEnum.ADJUST:
	   {
		Object newtop = @base + *(pc++);
		while (top < newtop)
	#if tag_AlternateDefinition1
			((top++).tag) = AnonymousEnum.T_NIL;
	#elif tag_AlternateDefinition2
			((top++).tag) = AnonymousEnum.T_NIL;
	#endif
		top = newtop; // top could be bigger than newtop
	   }
	   break;

	   case AnonymousEnum.CREATEARRAY:
	#if tag_AlternateDefinition1
		if (((top-1).tag) == AnonymousEnum.T_NIL)
	#elif tag_AlternateDefinition2
		if (((top-1).tag) == AnonymousEnum.T_NIL)
	#endif
	#if nvalue_AlternateDefinition1
		 ((top-1).value.n) = 101;
	#elif nvalue_AlternateDefinition2
		 ((top-1).value.n) = 101;
	#endif
		else
		{
	#if tonumber_AlternateDefinition1
		 if (((((top-1).tag) != AnonymousEnum.T_NUMBER) && (lua_tonumber(top-1) != 0)))
	#elif tonumber_AlternateDefinition2
		 if (((((top-1).tag) != AnonymousEnum.T_NUMBER) && (lua_tonumber(top-1) != 0)))
	#endif
			 return 1;
	#if nvalue_AlternateDefinition1
		 if (((top-1).value.n) <= 0)
	#elif nvalue_AlternateDefinition2
		 if (((top-1).value.n) <= 0)
	#endif
	#if nvalue_AlternateDefinition1
			 ((top-1).value.n) = 101;
	#elif nvalue_AlternateDefinition2
			 ((top-1).value.n) = 101;
	#endif
		}
	#if nvalue_AlternateDefinition1
	#if avalue_AlternateDefinition1
		((top-1).value.a) = lua_createarray(((top-1).value.n));
	#elif avalue_AlternateDefinition2
		((top-1).value.a) = lua_createarray(((top-1).value.n));
	#endif
	#elif nvalue_AlternateDefinition2
	#if avalue_AlternateDefinition1
		((top-1).value.a) = lua_createarray(((top-1).value.n));
	#elif avalue_AlternateDefinition2
		((top-1).value.a) = lua_createarray(((top-1).value.n));
	#endif
	#endif
	#if avalue_AlternateDefinition1
		if (((top-1).value.a) == null)
	#elif avalue_AlternateDefinition2
		if (((top-1).value.a) == null)
	#endif
		 return 1;
	#if tag_AlternateDefinition1
		((top-1).tag) = AnonymousEnum.T_ARRAY;
	#elif tag_AlternateDefinition2
		((top-1).tag) = AnonymousEnum.T_ARRAY;
	#endif
	   break;

	   case AnonymousEnum.EQOP:
	   {
		Object l = top-2;
		Object r = top-1;
		--top;
	#if tag_AlternateDefinition1
		if (((l).tag) != ((r).tag))
	#elif tag_AlternateDefinition2
		if (((l).tag) != ((r).tag))
	#endif
	#if tag_AlternateDefinition1
		 ((top-1).tag) = AnonymousEnum.T_NIL;
	#elif tag_AlternateDefinition2
		 ((top-1).tag) = AnonymousEnum.T_NIL;
	#endif
		else
		{
	#if tag_AlternateDefinition1
		 switch (((l).tag))
	#elif tag_AlternateDefinition2
		 switch (((l).tag))
	#endif
		 {
		  case AnonymousEnum.T_NIL:
	#if tag_AlternateDefinition1
			  ((top-1).tag) = AnonymousEnum.T_NUMBER;
	#elif tag_AlternateDefinition2
			  ((top-1).tag) = AnonymousEnum.T_NUMBER;
	#endif
			  break;
		  case AnonymousEnum.T_NUMBER:
	#if tag_AlternateDefinition1
	#if nvalue_AlternateDefinition1
			  ((top-1).tag) = (((l).value.n) == ((r).value.n)) ? AnonymousEnum.T_NUMBER : AnonymousEnum.T_NIL;
	#elif nvalue_AlternateDefinition2
			  ((top-1).tag) = (((l).value.n) == ((r).value.n)) ? AnonymousEnum.T_NUMBER : AnonymousEnum.T_NIL;
	#endif
	#elif tag_AlternateDefinition2
	#if nvalue_AlternateDefinition1
			  ((top-1).tag) = (((l).value.n) == ((r).value.n)) ? AnonymousEnum.T_NUMBER : AnonymousEnum.T_NIL;
	#elif nvalue_AlternateDefinition2
			  ((top-1).tag) = (((l).value.n) == ((r).value.n)) ? AnonymousEnum.T_NUMBER : AnonymousEnum.T_NIL;
	#endif
	#endif
			  break;
		  case AnonymousEnum.T_ARRAY:
	#if tag_AlternateDefinition1
	#if avalue_AlternateDefinition1
			  ((top-1).tag) = (((l).value.a) == ((r).value.a)) ? AnonymousEnum.T_NUMBER : AnonymousEnum.T_NIL;
	#elif avalue_AlternateDefinition2
			  ((top-1).tag) = (((l).value.a) == ((r).value.a)) ? AnonymousEnum.T_NUMBER : AnonymousEnum.T_NIL;
	#endif
	#elif tag_AlternateDefinition2
	#if avalue_AlternateDefinition1
			  ((top-1).tag) = (((l).value.a) == ((r).value.a)) ? AnonymousEnum.T_NUMBER : AnonymousEnum.T_NIL;
	#elif avalue_AlternateDefinition2
			  ((top-1).tag) = (((l).value.a) == ((r).value.a)) ? AnonymousEnum.T_NUMBER : AnonymousEnum.T_NIL;
	#endif
	#endif
			  break;
		  case AnonymousEnum.T_FUNCTION:
	#if tag_AlternateDefinition1
	#if bvalue_AlternateDefinition1
			  ((top-1).tag) = (((l).value.b) == ((r).value.b)) ? AnonymousEnum.T_NUMBER : AnonymousEnum.T_NIL;
	#elif bvalue_AlternateDefinition2
			  ((top-1).tag) = (((l).value.b) == ((r).value.b)) ? AnonymousEnum.T_NUMBER : AnonymousEnum.T_NIL;
	#endif
	#elif tag_AlternateDefinition2
	#if bvalue_AlternateDefinition1
			  ((top-1).tag) = (((l).value.b) == ((r).value.b)) ? AnonymousEnum.T_NUMBER : AnonymousEnum.T_NIL;
	#elif bvalue_AlternateDefinition2
			  ((top-1).tag) = (((l).value.b) == ((r).value.b)) ? AnonymousEnum.T_NUMBER : AnonymousEnum.T_NIL;
	#endif
	#endif
			  break;
		  case AnonymousEnum.T_CFUNCTION:
	#if tag_AlternateDefinition1
	#if fvalue_AlternateDefinition1
			  ((top-1).tag) = (((l).value.f) == ((r).value.f)) ? AnonymousEnum.T_NUMBER : AnonymousEnum.T_NIL;
	#elif fvalue_AlternateDefinition2
			  ((top-1).tag) = (((l).value.f) == ((r).value.f)) ? AnonymousEnum.T_NUMBER : AnonymousEnum.T_NIL;
	#endif
	#elif tag_AlternateDefinition2
	#if fvalue_AlternateDefinition1
			  ((top-1).tag) = (((l).value.f) == ((r).value.f)) ? AnonymousEnum.T_NUMBER : AnonymousEnum.T_NIL;
	#elif fvalue_AlternateDefinition2
			  ((top-1).tag) = (((l).value.f) == ((r).value.f)) ? AnonymousEnum.T_NUMBER : AnonymousEnum.T_NIL;
	#endif
	#endif
			  break;
		  case AnonymousEnum.T_USERDATA:
	#if tag_AlternateDefinition1
	#if uvalue_AlternateDefinition1
			  ((top-1).tag) = (((l).value.u) == ((r).value.u)) ? AnonymousEnum.T_NUMBER : AnonymousEnum.T_NIL;
	#elif uvalue_AlternateDefinition2
			  ((top-1).tag) = (((l).value.u) == ((r).value.u)) ? AnonymousEnum.T_NUMBER : AnonymousEnum.T_NIL;
	#endif
	#elif tag_AlternateDefinition2
	#if uvalue_AlternateDefinition1
			  ((top-1).tag) = (((l).value.u) == ((r).value.u)) ? AnonymousEnum.T_NUMBER : AnonymousEnum.T_NIL;
	#elif uvalue_AlternateDefinition2
			  ((top-1).tag) = (((l).value.u) == ((r).value.u)) ? AnonymousEnum.T_NUMBER : AnonymousEnum.T_NIL;
	#endif
	#endif
			  break;
		  case AnonymousEnum.T_STRING:
	#if tag_AlternateDefinition1
	#if svalue_AlternateDefinition1
			  ((top-1).tag) = (string.Compare (((l).value.s), ((r).value.s)) == 0) ? AnonymousEnum.T_NUMBER : AnonymousEnum.T_NIL;
	#elif svalue_AlternateDefinition2
			  ((top-1).tag) = (string.Compare (((l).value.s), ((r).value.s)) == 0) ? AnonymousEnum.T_NUMBER : AnonymousEnum.T_NIL;
	#endif
	#elif tag_AlternateDefinition2
	#if svalue_AlternateDefinition1
			  ((top-1).tag) = (string.Compare (((l).value.s), ((r).value.s)) == 0) ? AnonymousEnum.T_NUMBER : AnonymousEnum.T_NIL;
	#elif svalue_AlternateDefinition2
			  ((top-1).tag) = (string.Compare (((l).value.s), ((r).value.s)) == 0) ? AnonymousEnum.T_NUMBER : AnonymousEnum.T_NIL;
	#endif
	#endif
			  break;
		  case AnonymousEnum.T_MARK:
			  return 1;
		 }
		}
	#if nvalue_AlternateDefinition1
		((top-1).value.n) = 1;
	#elif nvalue_AlternateDefinition2
		((top-1).value.n) = 1;
	#endif
	   }
	   break;

	   case AnonymousEnum.LTOP:
	   {
		Object l = top-2;
		Object r = top-1;
		--top;
	#if tag_AlternateDefinition1
		if (((l).tag) == AnonymousEnum.T_NUMBER && ((r).tag) == AnonymousEnum.T_NUMBER)
	#elif tag_AlternateDefinition2
		if (((l).tag) == AnonymousEnum.T_NUMBER && ((r).tag) == AnonymousEnum.T_NUMBER)
	#endif
	#if tag_AlternateDefinition1
	#if nvalue_AlternateDefinition1
		 ((top-1).tag) = (((l).value.n) < ((r).value.n)) ? AnonymousEnum.T_NUMBER : AnonymousEnum.T_NIL;
	#elif nvalue_AlternateDefinition2
		 ((top-1).tag) = (((l).value.n) < ((r).value.n)) ? AnonymousEnum.T_NUMBER : AnonymousEnum.T_NIL;
	#endif
	#elif tag_AlternateDefinition2
	#if nvalue_AlternateDefinition1
		 ((top-1).tag) = (((l).value.n) < ((r).value.n)) ? AnonymousEnum.T_NUMBER : AnonymousEnum.T_NIL;
	#elif nvalue_AlternateDefinition2
		 ((top-1).tag) = (((l).value.n) < ((r).value.n)) ? AnonymousEnum.T_NUMBER : AnonymousEnum.T_NIL;
	#endif
	#endif
		else
		{
	#if tostring_AlternateDefinition1
		 if (((((l).tag) != AnonymousEnum.T_STRING) && (lua_tostring(l) != 0)) || ((((r).tag) != AnonymousEnum.T_STRING) && (lua_tostring(r) != 0)))
	#elif tostring_AlternateDefinition2
		 if (((((l).tag) != AnonymousEnum.T_STRING) && (lua_tostring(l) != 0)) || ((((r).tag) != AnonymousEnum.T_STRING) && (lua_tostring(r) != 0)))
	#endif
		  return 1;
	#if tag_AlternateDefinition1
	#if svalue_AlternateDefinition1
		 ((top-1).tag) = (string.Compare (((l).value.s), ((r).value.s)) < 0) ? AnonymousEnum.T_NUMBER : AnonymousEnum.T_NIL;
	#elif svalue_AlternateDefinition2
		 ((top-1).tag) = (string.Compare (((l).value.s), ((r).value.s)) < 0) ? AnonymousEnum.T_NUMBER : AnonymousEnum.T_NIL;
	#endif
	#elif tag_AlternateDefinition2
	#if svalue_AlternateDefinition1
		 ((top-1).tag) = (string.Compare (((l).value.s), ((r).value.s)) < 0) ? AnonymousEnum.T_NUMBER : AnonymousEnum.T_NIL;
	#elif svalue_AlternateDefinition2
		 ((top-1).tag) = (string.Compare (((l).value.s), ((r).value.s)) < 0) ? AnonymousEnum.T_NUMBER : AnonymousEnum.T_NIL;
	#endif
	#endif
		}
	#if nvalue_AlternateDefinition1
		((top-1).value.n) = 1;
	#elif nvalue_AlternateDefinition2
		((top-1).value.n) = 1;
	#endif
	   }
	   break;

	   case AnonymousEnum.LEOP:
	   {
		Object l = top-2;
		Object r = top-1;
		--top;
	#if tag_AlternateDefinition1
		if (((l).tag) == AnonymousEnum.T_NUMBER && ((r).tag) == AnonymousEnum.T_NUMBER)
	#elif tag_AlternateDefinition2
		if (((l).tag) == AnonymousEnum.T_NUMBER && ((r).tag) == AnonymousEnum.T_NUMBER)
	#endif
	#if tag_AlternateDefinition1
	#if nvalue_AlternateDefinition1
		 ((top-1).tag) = (((l).value.n) <= ((r).value.n)) ? AnonymousEnum.T_NUMBER : AnonymousEnum.T_NIL;
	#elif nvalue_AlternateDefinition2
		 ((top-1).tag) = (((l).value.n) <= ((r).value.n)) ? AnonymousEnum.T_NUMBER : AnonymousEnum.T_NIL;
	#endif
	#elif tag_AlternateDefinition2
	#if nvalue_AlternateDefinition1
		 ((top-1).tag) = (((l).value.n) <= ((r).value.n)) ? AnonymousEnum.T_NUMBER : AnonymousEnum.T_NIL;
	#elif nvalue_AlternateDefinition2
		 ((top-1).tag) = (((l).value.n) <= ((r).value.n)) ? AnonymousEnum.T_NUMBER : AnonymousEnum.T_NIL;
	#endif
	#endif
		else
		{
	#if tostring_AlternateDefinition1
		 if (((((l).tag) != AnonymousEnum.T_STRING) && (lua_tostring(l) != 0)) || ((((r).tag) != AnonymousEnum.T_STRING) && (lua_tostring(r) != 0)))
	#elif tostring_AlternateDefinition2
		 if (((((l).tag) != AnonymousEnum.T_STRING) && (lua_tostring(l) != 0)) || ((((r).tag) != AnonymousEnum.T_STRING) && (lua_tostring(r) != 0)))
	#endif
		  return 1;
	#if tag_AlternateDefinition1
	#if svalue_AlternateDefinition1
		 ((top-1).tag) = (string.Compare (((l).value.s), ((r).value.s)) <= 0) ? AnonymousEnum.T_NUMBER : AnonymousEnum.T_NIL;
	#elif svalue_AlternateDefinition2
		 ((top-1).tag) = (string.Compare (((l).value.s), ((r).value.s)) <= 0) ? AnonymousEnum.T_NUMBER : AnonymousEnum.T_NIL;
	#endif
	#elif tag_AlternateDefinition2
	#if svalue_AlternateDefinition1
		 ((top-1).tag) = (string.Compare (((l).value.s), ((r).value.s)) <= 0) ? AnonymousEnum.T_NUMBER : AnonymousEnum.T_NIL;
	#elif svalue_AlternateDefinition2
		 ((top-1).tag) = (string.Compare (((l).value.s), ((r).value.s)) <= 0) ? AnonymousEnum.T_NUMBER : AnonymousEnum.T_NIL;
	#endif
	#endif
		}
	#if nvalue_AlternateDefinition1
		((top-1).value.n) = 1;
	#elif nvalue_AlternateDefinition2
		((top-1).value.n) = 1;
	#endif
	   }
	   break;

	   case AnonymousEnum.ADDOP:
	   {
		Object l = top-2;
		Object r = top-1;
	#if tonumber_AlternateDefinition1
		if (((((r).tag) != AnonymousEnum.T_NUMBER) && (lua_tonumber(r) != 0)) || ((((l).tag) != AnonymousEnum.T_NUMBER) && (lua_tonumber(l) != 0)))
	#elif tonumber_AlternateDefinition2
		if (((((r).tag) != AnonymousEnum.T_NUMBER) && (lua_tonumber(r) != 0)) || ((((l).tag) != AnonymousEnum.T_NUMBER) && (lua_tonumber(l) != 0)))
	#endif
		 return 1;
	#if nvalue_AlternateDefinition1
		((l).value.n) += ((r).value.n);
	#elif nvalue_AlternateDefinition2
		((l).value.n) += ((r).value.n);
	#endif
		--top;
	   }
	   break;

	   case AnonymousEnum.SUBOP:
	   {
		Object l = top-2;
		Object r = top-1;
	#if tonumber_AlternateDefinition1
		if (((((r).tag) != AnonymousEnum.T_NUMBER) && (lua_tonumber(r) != 0)) || ((((l).tag) != AnonymousEnum.T_NUMBER) && (lua_tonumber(l) != 0)))
	#elif tonumber_AlternateDefinition2
		if (((((r).tag) != AnonymousEnum.T_NUMBER) && (lua_tonumber(r) != 0)) || ((((l).tag) != AnonymousEnum.T_NUMBER) && (lua_tonumber(l) != 0)))
	#endif
		 return 1;
	#if nvalue_AlternateDefinition1
		((l).value.n) -= ((r).value.n);
	#elif nvalue_AlternateDefinition2
		((l).value.n) -= ((r).value.n);
	#endif
		--top;
	   }
	   break;

	   case AnonymousEnum.MULTOP:
	   {
		Object l = top-2;
		Object r = top-1;
	#if tonumber_AlternateDefinition1
		if (((((r).tag) != AnonymousEnum.T_NUMBER) && (lua_tonumber(r) != 0)) || ((((l).tag) != AnonymousEnum.T_NUMBER) && (lua_tonumber(l) != 0)))
	#elif tonumber_AlternateDefinition2
		if (((((r).tag) != AnonymousEnum.T_NUMBER) && (lua_tonumber(r) != 0)) || ((((l).tag) != AnonymousEnum.T_NUMBER) && (lua_tonumber(l) != 0)))
	#endif
		 return 1;
	#if nvalue_AlternateDefinition1
		((l).value.n) *= ((r).value.n);
	#elif nvalue_AlternateDefinition2
		((l).value.n) *= ((r).value.n);
	#endif
		--top;
	   }
	   break;

	   case AnonymousEnum.DIVOP:
	   {
		Object l = top-2;
		Object r = top-1;
	#if tonumber_AlternateDefinition1
		if (((((r).tag) != AnonymousEnum.T_NUMBER) && (lua_tonumber(r) != 0)) || ((((l).tag) != AnonymousEnum.T_NUMBER) && (lua_tonumber(l) != 0)))
	#elif tonumber_AlternateDefinition2
		if (((((r).tag) != AnonymousEnum.T_NUMBER) && (lua_tonumber(r) != 0)) || ((((l).tag) != AnonymousEnum.T_NUMBER) && (lua_tonumber(l) != 0)))
	#endif
		 return 1;
	#if nvalue_AlternateDefinition1
		((l).value.n) /= ((r).value.n);
	#elif nvalue_AlternateDefinition2
		((l).value.n) /= ((r).value.n);
	#endif
		--top;
	   }
	   break;

	   case AnonymousEnum.CONCOP:
	   {
		Object l = top-2;
		Object r = top-1;
	#if tostring_AlternateDefinition1
		if (((((r).tag) != AnonymousEnum.T_STRING) && (lua_tostring(r) != 0)) || ((((l).tag) != AnonymousEnum.T_STRING) && (lua_tostring(l) != 0)))
	#elif tostring_AlternateDefinition2
		if (((((r).tag) != AnonymousEnum.T_STRING) && (lua_tostring(r) != 0)) || ((((l).tag) != AnonymousEnum.T_STRING) && (lua_tostring(l) != 0)))
	#endif
		 return 1;
	#if svalue_AlternateDefinition1
		((l).value.s) = lua_createstring (ref lua_strconc(ref ((l).value.s), ref ((r).value.s)));
	#elif svalue_AlternateDefinition2
		((l).value.s) = lua_createstring (ref lua_strconc(ref ((l).value.s), ref ((r).value.s)));
	#endif
	#if svalue_AlternateDefinition1
		if (((l).value.s) == null)
	#elif svalue_AlternateDefinition2
		if (((l).value.s) == null)
	#endif
		 return 1;
		--top;
	   }
	   break;

	   case AnonymousEnum.MINUSOP:
	#if tonumber_AlternateDefinition1
		if (((((top-1).tag) != AnonymousEnum.T_NUMBER) && (lua_tonumber(top-1) != 0)))
	#elif tonumber_AlternateDefinition2
		if (((((top-1).tag) != AnonymousEnum.T_NUMBER) && (lua_tonumber(top-1) != 0)))
	#endif
		 return 1;
	#if nvalue_AlternateDefinition1
		((top-1).value.n) = - ((top-1).value.n);
	#elif nvalue_AlternateDefinition2
		((top-1).value.n) = - ((top-1).value.n);
	#endif
	   break;

	   case AnonymousEnum.NOTOP:
	#if tag_AlternateDefinition1
		((top-1).tag) = ((top-1).tag) == ((int)AnonymousEnum.T_NIL) != 0 ? AnonymousEnum.T_NUMBER : AnonymousEnum.T_NIL;
	#elif tag_AlternateDefinition2
		((top-1).tag) = ((top-1).tag) == ((int)AnonymousEnum.T_NIL) != 0 ? AnonymousEnum.T_NUMBER : AnonymousEnum.T_NIL;
	#endif
	   break;

	   case AnonymousEnum.ONTJMP:
	   {
		CodeWord code = new CodeWord();
	#if get_word_AlternateDefinition1
		{
			code.m.c1 = pc++;
			code.m.c2 = pc++;
		}
	#elif get_word_AlternateDefinition2
		{
			code.m.c1 = pc++;
			code.m.c2 = pc++;
		}
	#endif
	#if tag_AlternateDefinition1
		if (((top-1).tag) != AnonymousEnum.T_NIL)
	#elif tag_AlternateDefinition2
		if (((top-1).tag) != AnonymousEnum.T_NIL)
	#endif
			pc += code.w;
	   }
	   break;

	   case AnonymousEnum.ONFJMP:
	   {
		CodeWord code = new CodeWord();
	#if get_word_AlternateDefinition1
		{
			code.m.c1 = pc++;
			code.m.c2 = pc++;
		}
	#elif get_word_AlternateDefinition2
		{
			code.m.c1 = pc++;
			code.m.c2 = pc++;
		}
	#endif
	#if tag_AlternateDefinition1
		if (((top-1).tag) == AnonymousEnum.T_NIL)
	#elif tag_AlternateDefinition2
		if (((top-1).tag) == AnonymousEnum.T_NIL)
	#endif
			pc += code.w;
	   }
	   break;

	   case AnonymousEnum.JMP:
	   {
		CodeWord code = new CodeWord();
	#if get_word_AlternateDefinition1
		{
			code.m.c1 = pc++;
			code.m.c2 = pc++;
		}
	#elif get_word_AlternateDefinition2
		{
			code.m.c1 = pc++;
			code.m.c2 = pc++;
		}
	#endif
		pc += code.w;
	   }
	   break;

	   case AnonymousEnum.UPJMP:
	   {
		CodeWord code = new CodeWord();
	#if get_word_AlternateDefinition1
		{
			code.m.c1 = pc++;
			code.m.c2 = pc++;
		}
	#elif get_word_AlternateDefinition2
		{
			code.m.c1 = pc++;
			code.m.c2 = pc++;
		}
	#endif
		pc -= code.w;
	   }
	   break;

	   case AnonymousEnum.IFFJMP:
	   {
		CodeWord code = new CodeWord();
	#if get_word_AlternateDefinition1
		{
			code.m.c1 = pc++;
			code.m.c2 = pc++;
		}
	#elif get_word_AlternateDefinition2
		{
			code.m.c1 = pc++;
			code.m.c2 = pc++;
		}
	#endif
		top--;
	#if tag_AlternateDefinition1
		if (((top).tag) == AnonymousEnum.T_NIL)
	#elif tag_AlternateDefinition2
		if (((top).tag) == AnonymousEnum.T_NIL)
	#endif
			pc += code.w;
	   }
	   break;

	   case AnonymousEnum.IFFUPJMP:
	   {
		CodeWord code = new CodeWord();
	#if get_word_AlternateDefinition1
		{
			code.m.c1 = pc++;
			code.m.c2 = pc++;
		}
	#elif get_word_AlternateDefinition2
		{
			code.m.c1 = pc++;
			code.m.c2 = pc++;
		}
	#endif
		top--;
	#if tag_AlternateDefinition1
		if (((top).tag) == AnonymousEnum.T_NIL)
	#elif tag_AlternateDefinition2
		if (((top).tag) == AnonymousEnum.T_NIL)
	#endif
			pc -= code.w;
	   }
	   break;

	   case AnonymousEnum.POP:
		   --top;
		   break;

	   case AnonymousEnum.CALLFUNC:
	   {
	#if Byte_AlternateDefinition1
		byte newpc;
	#elif Byte_AlternateDefinition2
		byte newpc;
	#endif
//C++ TO C# CONVERTER TODO TASK: Pointer arithmetic is detected on this variable, so pointers on this variable are left unchanged.
		Object *b = top-1;
	#if tag_AlternateDefinition1
		while (((b).tag) != AnonymousEnum.T_MARK)
	#elif tag_AlternateDefinition2
		while (((b).tag) != AnonymousEnum.T_MARK)
	#endif
			b--;
	#if tag_AlternateDefinition1
		if (((b-1).tag) == AnonymousEnum.T_FUNCTION)
	#elif tag_AlternateDefinition2
		if (((b-1).tag) == AnonymousEnum.T_FUNCTION)
	#endif
		{
		 lua_debugline = 0; // always reset debug flag
	#if bvalue_AlternateDefinition1
		 newpc = ((b-1).value.b);
	#elif bvalue_AlternateDefinition2
		 newpc = ((b-1).value.b);
	#endif
	#if bvalue_AlternateDefinition1
		 ((b-1).value.b) = pc;
	#elif bvalue_AlternateDefinition2
		 ((b-1).value.b) = pc;
	#endif
	#if nvalue_AlternateDefinition1
		 ((b).value.n) = (@base-stack);
	#elif nvalue_AlternateDefinition2
		 ((b).value.n) = (@base-stack);
	#endif
		 @base = b+1;
		 pc = newpc;
		 if (DefineConstantsOpcode.MAXSTACK-(@base-stack) < DefineConstantsOpcode.STACKGAP)
		 {
		  lua_error ("stack overflow");
		  return 1;
		 }
		}
	#if tag_AlternateDefinition1
		else if (((b-1).tag) == AnonymousEnum.T_CFUNCTION)
	#elif tag_AlternateDefinition2
		else if (((b-1).tag) == AnonymousEnum.T_CFUNCTION)
	#endif
		{
		 int nparam;
		 lua_debugline = 0; // always reset debug flag
	#if nvalue_AlternateDefinition1
		 ((b).value.n) = (@base-stack);
	#elif nvalue_AlternateDefinition2
		 ((b).value.n) = (@base-stack);
	#endif
		 @base = b+1;
		 nparam = top-@base; // number of parameters
	#if fvalue_AlternateDefinition1
		 (((b-1).value.f))();
	#elif fvalue_AlternateDefinition2
		 (((b-1).value.f))();
	#endif

		 // shift returned values
		 {
		  int i;
		  int nretval = top - @base - nparam;
		  top = @base - 2;
	#if nvalue_AlternateDefinition1
		  @base = stack + (int)((@base-1).value.n);
	#elif nvalue_AlternateDefinition2
		  @base = stack + (int)((@base-1).value.n);
	#endif
		  for (i =0; i<nretval; i++)
		  {
		   top = *(top+nparam+2);
		   ++top;
		  }
		 }
		}
		else
		{
		 lua_reportbug ("call expression not a function");
		 return 1;
		}
	   }
	   break;

	   case AnonymousEnum.RETCODE:
	   {
		int i;
		int shift = pc++;
		int nretval = top - @base - shift;
		top = @base - 2;
	#if bvalue_AlternateDefinition1
		pc = ((@base-2).value.b);
	#elif bvalue_AlternateDefinition2
		pc = ((@base-2).value.b);
	#endif
	#if nvalue_AlternateDefinition1
		@base = stack + (int)((@base-1).value.n);
	#elif nvalue_AlternateDefinition2
		@base = stack + (int)((@base-1).value.n);
	#endif
		for (i =0; i<nretval; i++)
		{
		 top = *(top+shift+2);
		 ++top;
		}
	   }
	   break;

	   case AnonymousEnum.HALT:
		@base = oldbase;
	   return 0; // success

	   case AnonymousEnum.SETFUNCTION:
	   {
		CodeWord file = new CodeWord();
		CodeWord func = new CodeWord();
	#if get_word_AlternateDefinition1
		{
			file.m.c1 = pc++;
			file.m.c2 = pc++;
		}
	#elif get_word_AlternateDefinition2
		{
			file.m.c1 = pc++;
			file.m.c2 = pc++;
		}
	#endif
	#if get_word_AlternateDefinition1
		{
			func.m.c1 = pc++;
			func.m.c2 = pc++;
		}
	#elif get_word_AlternateDefinition2
		{
			func.m.c1 = pc++;
			func.m.c2 = pc++;
		}
	#endif
		if (lua_pushfunction (file.w, func.w) != 0)
		 return 1;
	   }
	   break;

	   case AnonymousEnum.SETLINE:
	   {
		CodeWord code = new CodeWord();
	#if get_word_AlternateDefinition1
		{
			code.m.c1 = pc++;
			code.m.c2 = pc++;
		}
	#elif get_word_AlternateDefinition2
		{
			code.m.c1 = pc++;
			code.m.c2 = pc++;
		}
	#endif
		lua_debugline = code.w;
	   }
	   break;

	   case AnonymousEnum.RESET:
		lua_popfunction ();
	   break;

	   default:
		lua_error ("internal error - opcode didn't match");
	   return 1;
	  }
	 }
	}
//C++ TO C# CONVERTER TODO TASK: The implementation of the following method could not be found:
	//void lua_markstack();

//
//** Duplicate a string,  creating a mark space at the beginning.
//** Return the new string pointer.
//
	public static string lua_strdup(ref string l)
	{
//C++ TO C# CONVERTER TODO TASK: The memory management function 'calloc' has no equivalent in C#:
	 sbyte s = calloc (l.Length+2, sizeof(sbyte));
	 if (s == null)
	 {
	  lua_error ("not enough memory");
	  return null;
	 }
	 s++= 0; // create mark space
	 return strcpy(s,l);
	}

//C++ TO C# CONVERTER TODO TASK: The implementation of the following method could not be found:
	//void lua_setinput(Input fn); // from "lex.c" module 
//C++ TO C# CONVERTER TODO TASK: The implementation of the following method could not be found:
	//string lua_lasttext(); // from "lex.c" module 
//C++ TO C# CONVERTER TODO TASK: The implementation of the following method could not be found:
	//int lua_parse(); // from "lua.stx" module 

//
//** Internal function: return an object type. 
//
	public static void lua_type()
	{
	 Object o = lua_getparam(1);
	#if tag_AlternateDefinition1
	 lua_pushstring (ref lua_constant[((o).tag)]);
	#elif tag_AlternateDefinition2
	 lua_pushstring (ref lua_constant[((o).tag)]);
	#endif
	}

//
//** Internal function: convert an object to a number
//
	public static void lua_obj2number()
	{
	 Object o = lua_getparam(1);
	 lua_pushobject (lua_convtonumber(o));
	}

//
//** Internal function: print object values
//
	public static void lua_print()
	{
	 int i =1;
	 IntPtr obj;
	 while ((obj =lua_getparam (i++)) != null)
	 {
	  if (lua_isnumber(obj) != 0)
		  Console.Write("{0:g}\n",lua_getnumber (obj));
	  else if (lua_isstring(obj) != 0)
		  Console.Write("{0}\n",lua_getstring (obj));
	  else if (lua_iscfunction(obj) != 0)
//C++ TO C# CONVERTER TODO TASK: The following line has a C++ format specifier which cannot be directly translated to C#:
//ORIGINAL LINE: printf("cfunction: %p\n",lua_getcfunction (obj));
		  Console.Write("cfunction: %p\n",lua_getcfunction (obj));
	  else if (lua_isuserdata(obj) != 0)
//C++ TO C# CONVERTER TODO TASK: The following line has a C++ format specifier which cannot be directly translated to C#:
//ORIGINAL LINE: printf("userdata: %p\n",lua_getuserdata (obj));
		  Console.Write("userdata: %p\n",lua_getuserdata (obj));
	  else if (lua_istable(obj) != 0)
//C++ TO C# CONVERTER TODO TASK: The following line has a C++ format specifier which cannot be directly translated to C#:
//ORIGINAL LINE: printf("table: %p\n",obj);
		  Console.Write("table: %p\n",obj);
	  else if (lua_isnil(obj) != 0)
		  Console.Write("nil\n");
	  else
		  Console.Write("invalid value to print\n");
	 }
	}

//
//** Internal function: do a file
//
	public static void lua_internaldofile()
	{
	#if lua_Object_AlternateDefinition1
	 Object obj = lua_getparam (1);
	#elif lua_Object_AlternateDefinition2
	 Object obj = lua_getparam (1);
	#endif
	 if (lua_isstring(obj) != 0 && lua_dofile(ref lua_getstring(obj)) == 0)
	  lua_pushnumber(1);
	 else
	  lua_pushnil();
	}

//
//** Internal function: do a string
//
	public static void lua_internaldostring()
	{
	#if lua_Object_AlternateDefinition1
	 Object obj = lua_getparam (1);
	#elif lua_Object_AlternateDefinition2
	 Object obj = lua_getparam (1);
	#endif
	 if (lua_isstring(obj) != 0 && lua_dostring(ref lua_getstring(obj)) == 0)
	  lua_pushnumber(1);
	 else
	  lua_pushnil();
	}

//
//** Traverse all objects on stack
//
private delegate void fnDelegate(Object NamelessParameter);
	public static void lua_travstack(fnDelegate fn)
	{
//C++ TO C# CONVERTER TODO TASK: Pointer arithmetic is detected on this variable, so pointers on this variable are left unchanged.
	 Object *o = new Object();
	 for (o = top-1; o >= stack; o--)
	  fn (ref o);
	}

	#endif


	#if tag_AlternateDefinition1
	#define tonumber_AlternateDefinition1
	//C++ TO C# CONVERTER NOTE: The following #define macro was replaced in-line:
	//ORIGINAL LINE: #define tonumber(o) ((((o)->tag) != T_NUMBER) && (lua_tonumber(o) != 0))
	#define tonumber
	#elif tag_AlternateDefinition2
	#define tonumber_AlternateDefinition2
	//C++ TO C# CONVERTER NOTE: The following #define macro was replaced in-line:
	//ORIGINAL LINE: #define tonumber(o) ((((o)->tag) != T_NUMBER) && (lua_tonumber(o) != 0))
	#define tonumber
	#endif
	#if tag_AlternateDefinition1
	#define tostring_AlternateDefinition1
	//C++ TO C# CONVERTER NOTE: The following #define macro was replaced in-line:
	//ORIGINAL LINE: #define tostring(o) ((((o)->tag) != T_STRING) && (lua_tostring(o) != 0))
	#define tostring
	#elif tag_AlternateDefinition2
	#define tostring_AlternateDefinition2
	//C++ TO C# CONVERTER NOTE: The following #define macro was replaced in-line:
	//ORIGINAL LINE: #define tostring(o) ((((o)->tag) != T_STRING) && (lua_tostring(o) != 0))
	#define tostring
	#endif

	#if ! MAXSTACK
	#define MAXSTACK
	#endif
	internal static Object[] stack = { new Object(AnonymousEnum.T_MARK, {null) };
	internal static Object top =stack+1;
	internal static Object @base =stack+1;


	//
	//** Concatenate two given string, creating a mark space at the beginning.
	//** Return the new string pointer.
	//
	internal static string lua_strconc(ref string l, ref string r)
	{
//C++ TO C# CONVERTER TODO TASK: The memory management function 'calloc' has no equivalent in C#:
	 sbyte s = calloc (l.Length+r.Length+2, sizeof(sbyte));
	 if (s == null)
	 {
	  lua_error ("not enough memory");
	  return null;
	 }
	 s++= 0; // create mark space 
	 return strcat(strcpy(s,l),r);
	}

	//
	//** Convert, if possible, to a number tag.
	//** Return 0 in success or not 0 on error.
	// 
	internal static int lua_tonumber(Object obj)
	{
	 string ptr;
	#if tag_AlternateDefinition1
	 if (((obj).tag) != AnonymousEnum.T_STRING)
	#elif tag_AlternateDefinition2
	 if (((obj).tag) != AnonymousEnum.T_STRING)
	#endif
	 {
	  lua_reportbug ("unexpected type at conversion to number");
	  return 1;
	 }
	#if nvalue_AlternateDefinition1
	#if svalue_AlternateDefinition1
	 ((obj).value.n) = strtod(((obj).value.s), ref ptr);
	#elif svalue_AlternateDefinition2
	 ((obj).value.n) = strtod(((obj).value.s), ref ptr);
	#endif
	#elif nvalue_AlternateDefinition2
	#if svalue_AlternateDefinition1
	 ((obj).value.n) = strtod(((obj).value.s), ref ptr);
	#elif svalue_AlternateDefinition2
	 ((obj).value.n) = strtod(((obj).value.s), ref ptr);
	#endif
	#endif
	 if (ptr != null)
	 {
	  lua_reportbug ("string to number convertion failed");
	  return 2;
	 }
	#if tag_AlternateDefinition1
	 ((obj).tag) = AnonymousEnum.T_NUMBER;
	#elif tag_AlternateDefinition2
	 ((obj).tag) = AnonymousEnum.T_NUMBER;
	#endif
	 return 0;
	}
//C++ TO C# CONVERTER NOTE: This was formerly a static local variable declaration (not allowed in C#):
private static Object cvt = new Object();

	//
	//** Test if is possible to convert an object to a number one.
	//** If possible, return the converted object, otherwise return nil object.
	// 
	internal static Object lua_convtonumber(Object obj)
	{
	//C++ TO C# CONVERTER NOTE: This static local variable declaration (not allowed in C#) has been moved just prior to the method:
	// static Object cvt;

	#if tag_AlternateDefinition1
	 if (((obj).tag) == AnonymousEnum.T_NUMBER)
	#elif tag_AlternateDefinition2
	 if (((obj).tag) == AnonymousEnum.T_NUMBER)
	#endif
	 {
//C++ TO C# CONVERTER WARNING: The following line was determined to be a copy assignment (rather than a reference assignment) - this should be verified and a 'CopyFrom' method should be created if it does not yet exist:
//ORIGINAL LINE: cvt = *obj;
	  cvt.CopyFrom(obj);
	  return cvt;
	 }

	#if tag_AlternateDefinition1
	 ((cvt).tag) = AnonymousEnum.T_NIL;
	#elif tag_AlternateDefinition2
	 ((cvt).tag) = AnonymousEnum.T_NIL;
	#endif
	#if tag_AlternateDefinition1
	 if (((obj).tag) == AnonymousEnum.T_STRING)
	#elif tag_AlternateDefinition2
	 if (((obj).tag) == AnonymousEnum.T_STRING)
	#endif
	 {
	  string ptr;
	#if nvalue_AlternateDefinition1
	#if svalue_AlternateDefinition1
	  ((cvt).value.n) = strtod(((obj).value.s), ref ptr);
	#elif svalue_AlternateDefinition2
	  ((cvt).value.n) = strtod(((obj).value.s), ref ptr);
	#endif
	#elif nvalue_AlternateDefinition2
	#if svalue_AlternateDefinition1
	  ((cvt).value.n) = strtod(((obj).value.s), ref ptr);
	#elif svalue_AlternateDefinition2
	  ((cvt).value.n) = strtod(((obj).value.s), ref ptr);
	#endif
	#endif
	  if ( ptr == 0)
	#if tag_AlternateDefinition1
	   ((cvt).tag) = AnonymousEnum.T_NUMBER;
	#elif tag_AlternateDefinition2
	   ((cvt).tag) = AnonymousEnum.T_NUMBER;
	#endif
	 }
	 return cvt;
	}
//C++ TO C# CONVERTER NOTE: This was formerly a static local variable declaration (not allowed in C#):
private static string s = new string(new char[256]);



	//
	//** Convert, if possible, to a string tag
	//** Return 0 in success or not 0 on error.
	// 
	internal static int lua_tostring(Object obj)
	{
	//C++ TO C# CONVERTER NOTE: This static local variable declaration (not allowed in C#) has been moved just prior to the method:
	// static sbyte s[256];
	#if tag_AlternateDefinition1
	 if (((obj).tag) != AnonymousEnum.T_NUMBER)
	#elif tag_AlternateDefinition2
	 if (((obj).tag) != AnonymousEnum.T_NUMBER)
	#endif
	 {
	  lua_reportbug ("unexpected type at conversion to string");
	  return 1;
	 }
	#if nvalue_AlternateDefinition1
	 if ((int)((obj).value.n) == ((obj).value.n))
	#elif nvalue_AlternateDefinition2
	 if ((int)((obj).value.n) == ((obj).value.n))
	#endif
	#if nvalue_AlternateDefinition1
	  s = string.Format ("{0:D}", (int)((obj).value.n));
	#elif nvalue_AlternateDefinition2
	  s = string.Format ("{0:D}", (int)((obj).value.n));
	#endif
	 else
	#if nvalue_AlternateDefinition1
	  s = string.Format ("{0:g}", ((obj).value.n));
	#elif nvalue_AlternateDefinition2
	  s = string.Format ("{0:g}", ((obj).value.n));
	#endif
	#if svalue_AlternateDefinition1
	 ((obj).value.s) = lua_createstring(ref lua_strdup(ref s));
	#elif svalue_AlternateDefinition2
	 ((obj).value.s) = lua_createstring(ref lua_strdup(ref s));
	#endif
	#if svalue_AlternateDefinition1
	 if (((obj).value.s) == null)
	#elif svalue_AlternateDefinition2
	 if (((obj).value.s) == null)
	#endif
	  return 1;
	#if tag_AlternateDefinition1
	 ((obj).tag) = AnonymousEnum.T_STRING;
	#elif tag_AlternateDefinition2
	 ((obj).tag) = AnonymousEnum.T_STRING;
	#endif
	 return 0;
	}


	//
	//** Execute the given opcode. Return 0 in success or 1 on error.
	//
	#if Byte_AlternateDefinition1

	//
	//** Open file, generate opcode and execute global statement. Return 0 on
	//** success or 1 on error.
	//
	public static int lua_dofile(ref string filename)
	{
	 if (lua_openfile (ref filename) != 0)
		 return 1;
	 if (lua_parse () != 0)
	 {
		 lua_closefile ();
		 return 1;
	 }
	 lua_closefile ();
	 return 0;
	}

	//
	//** Generate opcode stored on string and execute global statement. Return 0 on
	//** success or 1 on error.
	//
	public static int lua_dostring(ref string @string)
	{
	 if (lua_openstring (ref @string) != 0)
		 return 1;
	 if (lua_parse () != 0)
		 return 1;
	 lua_closestring();
	 return 0;
	}
//C++ TO C# CONVERTER NOTE: This was formerly a static local variable declaration (not allowed in C#):
private byte[] startcode = {AnonymousEnum.CALLFUNC, AnonymousEnum.HALT};
//C++ TO C# CONVERTER NOTE: This was formerly a static local variable declaration (not allowed in C#):
private byte[] startcode = {AnonymousEnum.CALLFUNC, AnonymousEnum.HALT};

	//
	//** Execute the given function. Return 0 on success or 1 on error.
	//
	public static int lua_call(ref string functionname, int nparam)
	{
	#if Byte_AlternateDefinition1
	//C++ TO C# CONVERTER NOTE: This static local variable declaration (not allowed in C#) has been moved just prior to the method:
	// static byte startcode[] = {CALLFUNC, HALT};
	#elif Byte_AlternateDefinition2
	//C++ TO C# CONVERTER NOTE: This static local variable declaration (not allowed in C#) has been moved just prior to the method:
	// static byte startcode[] = {CALLFUNC, HALT};
	#endif
	 int i;
	#if s_object_AlternateDefinition1
	 Object func = (lua_table[lua_findsymbol(ref functionname)].object);
	#elif s_object_AlternateDefinition2
	 Object func = (lua_table[lua_findsymbol(ref functionname)].object);
	#endif
	#if tag_AlternateDefinition1
	 if (((func).tag) != AnonymousEnum.T_FUNCTION)
	#elif tag_AlternateDefinition2
	 if (((func).tag) != AnonymousEnum.T_FUNCTION)
	#endif
		 return 1;
	 for (i =1; i<=nparam; i++)
	  *(top-i+2) = *(top-i);
	 top += 2;
	#if tag_AlternateDefinition1
	 ((top-nparam-1).tag) = AnonymousEnum.T_MARK;
	#elif tag_AlternateDefinition2
	 ((top-nparam-1).tag) = AnonymousEnum.T_MARK;
	#endif
	 *(top-nparam-2) = func;
	 return (lua_execute (ref startcode));
	}

	//
	//** Get a parameter, returning the object handle or NULL on error.
	//** 'number' must be 1 to get the first parameter.
	//
	public static Object lua_getparam(int number)
	{
	 if (number <= 0 || number > top-@base)
		 return null;
	 return (@base+number-1);
	}

	//
	//** Given an object handle, return its number value. On error, return 0.0.
	//
	public static float lua_getnumber(Object @object)
	{
	#if tag_AlternateDefinition1
	 if (@object == null || ((@object).tag) == AnonymousEnum.T_NIL)
	#elif tag_AlternateDefinition2
	 if (@object == null || ((@object).tag) == AnonymousEnum.T_NIL)
	#endif
		 return 0.0;
	#if tonumber_AlternateDefinition1
	 if (((((@object).tag) != AnonymousEnum.T_NUMBER) && (lua_tonumber(@object) != 0)))
	#elif tonumber_AlternateDefinition2
	 if (((((@object).tag) != AnonymousEnum.T_NUMBER) && (lua_tonumber(@object) != 0)))
	#endif
		 return 0.0;
	 else
	#if nvalue_AlternateDefinition1
		 return (((@object).value.n));
	#elif nvalue_AlternateDefinition2
		 return (((@object).value.n));
	#endif
	}

	//
	//** Given an object handle, return its string pointer. On error, return NULL.
	//
	public static string lua_getstring(Object @object)
	{
	#if tag_AlternateDefinition1
	 if (@object == null || ((@object).tag) == AnonymousEnum.T_NIL)
	#elif tag_AlternateDefinition2
	 if (@object == null || ((@object).tag) == AnonymousEnum.T_NIL)
	#endif
		 return null;
	#if tostring_AlternateDefinition1
	 if (((((@object).tag) != AnonymousEnum.T_STRING) && (lua_tostring(@object) != 0)))
	#elif tostring_AlternateDefinition2
	 if (((((@object).tag) != AnonymousEnum.T_STRING) && (lua_tostring(@object) != 0)))
	#endif
		 return null;
	 else
	#if svalue_AlternateDefinition1
		 return (((@object).value.s));
	#elif svalue_AlternateDefinition2
		 return (((@object).value.s));
	#endif
	}

	//
	//** Given an object handle, return a copy of its string. On error, return NULL.
	//
	public static string lua_copystring(Object @object)
	{
	#if tag_AlternateDefinition1
	 if (@object == null || ((@object).tag) == AnonymousEnum.T_NIL)
	#elif tag_AlternateDefinition2
	 if (@object == null || ((@object).tag) == AnonymousEnum.T_NIL)
	#endif
		 return null;
	#if tostring_AlternateDefinition1
	 if (((((@object).tag) != AnonymousEnum.T_STRING) && (lua_tostring(@object) != 0)))
	#elif tostring_AlternateDefinition2
	 if (((((@object).tag) != AnonymousEnum.T_STRING) && (lua_tostring(@object) != 0)))
	#endif
		 return null;
	 else
	#if svalue_AlternateDefinition1
		 return (((@object).value.s));
	#elif svalue_AlternateDefinition2
		 return (((@object).value.s));
	#endif
	}

	//
	//** Given an object handle, return its cfuntion pointer. On error, return NULL.
	//
	public static lua_CFunction lua_getcfunction(Object @object)
	{
	 if (@object == null)
		 return null;
	#if tag_AlternateDefinition1
	 if (((@object).tag) != AnonymousEnum.T_CFUNCTION)
	#elif tag_AlternateDefinition2
	 if (((@object).tag) != AnonymousEnum.T_CFUNCTION)
	#endif
		 return null;
	 else
	#if fvalue_AlternateDefinition1
		 return (((@object).value.f));
	#elif fvalue_AlternateDefinition2
		 return (((@object).value.f));
	#endif
	}

	//
	//** Given an object handle, return its user data. On error, return NULL.
	//
	public static IntPtr lua_getuserdata(Object @object)
	{
	 if (@object == null)
		 return null;
	#if tag_AlternateDefinition1
	 if (((@object).tag) != AnonymousEnum.T_USERDATA)
	#elif tag_AlternateDefinition2
	 if (((@object).tag) != AnonymousEnum.T_USERDATA)
	#endif
		 return null;
	 else
	#if uvalue_AlternateDefinition1
		 return (((@object).value.u));
	#elif uvalue_AlternateDefinition2
		 return (((@object).value.u));
	#endif
	}

	//
	//** Given an object handle and a field name, return its field object.
	//** On error, return NULL.
	//
	public static Object lua_getfield(Object @object, ref string field)
	{
	 if (@object == null)
		 return null;
	#if tag_AlternateDefinition1
	 if (((@object).tag) != AnonymousEnum.T_ARRAY)
	#elif tag_AlternateDefinition2
	 if (((@object).tag) != AnonymousEnum.T_ARRAY)
	#endif
	  return null;
	 else
	 {
	  Object @ref = new Object();
	#if tag_AlternateDefinition1
	  ((@ref).tag) = AnonymousEnum.T_STRING;
	#elif tag_AlternateDefinition2
	  ((@ref).tag) = AnonymousEnum.T_STRING;
	#endif
	#if svalue_AlternateDefinition1
	  ((@ref).value.s) = lua_createstring(ref lua_strdup(ref field));
	#elif svalue_AlternateDefinition2
	  ((@ref).value.s) = lua_createstring(ref lua_strdup(ref field));
	#endif
	#if avalue_AlternateDefinition1
	  return (lua_hashdefine(((@object).value.a), @ref));
	#elif avalue_AlternateDefinition2
	  return (lua_hashdefine(((@object).value.a), @ref));
	#endif
	 }
	}

	//
	//** Given an object handle and an index, return its indexed object.
	//** On error, return NULL.
	//
	public static Object lua_getindexed(Object @object, float index)
	{
	 if (@object == null)
		 return null;
	#if tag_AlternateDefinition1
	 if (((@object).tag) != AnonymousEnum.T_ARRAY)
	#elif tag_AlternateDefinition2
	 if (((@object).tag) != AnonymousEnum.T_ARRAY)
	#endif
	  return null;
	 else
	 {
	  Object @ref = new Object();
	#if tag_AlternateDefinition1
	  ((@ref).tag) = AnonymousEnum.T_NUMBER;
	#elif tag_AlternateDefinition2
	  ((@ref).tag) = AnonymousEnum.T_NUMBER;
	#endif
	#if nvalue_AlternateDefinition1
	  ((@ref).value.n) = index;
	#elif nvalue_AlternateDefinition2
	  ((@ref).value.n) = index;
	#endif
	#if avalue_AlternateDefinition1
	  return (lua_hashdefine(((@object).value.a), @ref));
	#elif avalue_AlternateDefinition2
	  return (lua_hashdefine(((@object).value.a), @ref));
	#endif
	 }
	}

	//
	//** Get a global object. Return the object handle or NULL on error.
	//
	public static Object lua_getglobal(ref string name)
	{
	 int n = lua_findsymbol(ref name);
	 if (n < 0)
		 return null;
	#if s_object_AlternateDefinition1
	 return (lua_table[n].object);
	#elif s_object_AlternateDefinition2
	 return (lua_table[n].object);
	#endif
	}

	//
	//** Pop and return an object
	//
	public static Object lua_pop()
	{
	 if (top <= @base)
		 return null;
	 top--;
	 return top;
	}

	//
	//** Push a nil object
	//
	public static int lua_pushnil()
	{
	 if ((top-stack) >= DefineConstantsOpcode.MAXSTACK-1)
	 {
	  lua_error ("stack overflow");
	  return 1;
	 }
	#if tag_AlternateDefinition1
	 ((top).tag) = AnonymousEnum.T_NIL;
	#elif tag_AlternateDefinition2
	 ((top).tag) = AnonymousEnum.T_NIL;
	#endif
	 return 0;
	}

	//
	//** Push an object (tag=number) to stack. Return 0 on success or 1 on error.
	//
	public static int lua_pushnumber(float n)
	{
	 if ((top-stack) >= DefineConstantsOpcode.MAXSTACK-1)
	 {
	  lua_error ("stack overflow");
	  return 1;
	 }
	#if tag_AlternateDefinition1
	 ((top).tag) = AnonymousEnum.T_NUMBER;
	#elif tag_AlternateDefinition2
	 ((top).tag) = AnonymousEnum.T_NUMBER;
	#endif
	#if nvalue_AlternateDefinition1
	 ((top++).value.n) = n;
	#elif nvalue_AlternateDefinition2
	 ((top++).value.n) = n;
	#endif
	 return 0;
	}

	//
	//** Push an object (tag=string) to stack. Return 0 on success or 1 on error.
	//
	public static int lua_pushstring(ref string s)
	{
	 if ((top-stack) >= DefineConstantsOpcode.MAXSTACK-1)
	 {
	  lua_error ("stack overflow");
	  return 1;
	 }
	#if tag_AlternateDefinition1
	 ((top).tag) = AnonymousEnum.T_STRING;
	#elif tag_AlternateDefinition2
	 ((top).tag) = AnonymousEnum.T_STRING;
	#endif
	#if svalue_AlternateDefinition1
	 ((top++).value.s) = lua_createstring(ref lua_strdup(ref s));
	#elif svalue_AlternateDefinition2
	 ((top++).value.s) = lua_createstring(ref lua_strdup(ref s));
	#endif
	 return 0;
	}

	//
	//** Push an object (tag=cfunction) to stack. Return 0 on success or 1 on error.
	//
	public static int lua_pushcfunction(lua_CFunction fn)
	{
	 if ((top-stack) >= DefineConstantsOpcode.MAXSTACK-1)
	 {
	  lua_error ("stack overflow");
	  return 1;
	 }
	#if tag_AlternateDefinition1
	 ((top).tag) = AnonymousEnum.T_CFUNCTION;
	#elif tag_AlternateDefinition2
	 ((top).tag) = AnonymousEnum.T_CFUNCTION;
	#endif
	#if fvalue_AlternateDefinition1
	 ((top++).value.f) = fn;
	#elif fvalue_AlternateDefinition2
	 ((top++).value.f) = fn;
	#endif
	 return 0;
	}

	//
	//** Push an object (tag=userdata) to stack. Return 0 on success or 1 on error.
	//
	public static int lua_pushuserdata(IntPtr u)
	{
	 if ((top-stack) >= DefineConstantsOpcode.MAXSTACK-1)
	 {
	  lua_error ("stack overflow");
	  return 1;
	 }
	#if tag_AlternateDefinition1
	 ((top).tag) = AnonymousEnum.T_USERDATA;
	#elif tag_AlternateDefinition2
	 ((top).tag) = AnonymousEnum.T_USERDATA;
	#endif
	#if uvalue_AlternateDefinition1
	 ((top++).value.u) = u;
	#elif uvalue_AlternateDefinition2
	 ((top++).value.u) = u;
	#endif
	 return 0;
	}

	//
	//** Push an object to stack.
	//
	public static int lua_pushobject(Object o)
	{
	 if ((top-stack) >= DefineConstantsOpcode.MAXSTACK-1)
	 {
	  lua_error ("stack overflow");
	  return 1;
	 }
	 top++= o;
	 return 0;
	}

	//
	//** Store top of the stack at a global variable array field. 
	//** Return 1 on error, 0 on success.
	//
	public static int lua_storeglobal(ref string name)
	{
	 int n = lua_findsymbol (ref name);
	 if (n < 0)
		 return 1;
	#if tag_AlternateDefinition1
	 if (((top-1).tag) == AnonymousEnum.T_MARK)
	#elif tag_AlternateDefinition2
	 if (((top-1).tag) == AnonymousEnum.T_MARK)
	#endif
		 return 1;
	#if s_object_AlternateDefinition1
	 (lua_table[n].object) = *(--top);
	#elif s_object_AlternateDefinition2
	 (lua_table[n].object) = *(--top);
	#endif
	 return 0;
	}

	//
	//** Store top of the stack at an array field. Return 1 on error, 0 on success.
	//
	#if lua_Object_AlternateDefinition1
	public static int lua_storefield(Object @object, ref string field)
	#elif lua_Object_AlternateDefinition2
	public static int lua_storefield(Object @object, ref string field)
	#endif
	{
	#if tag_AlternateDefinition1
	 if (((@object).tag) != AnonymousEnum.T_ARRAY)
	#elif tag_AlternateDefinition2
	 if (((@object).tag) != AnonymousEnum.T_ARRAY)
	#endif
	  return 1;
	 else
	 {
	  Object @ref = new Object();
	  Object h;
	#if tag_AlternateDefinition1
	  ((@ref).tag) = AnonymousEnum.T_STRING;
	#elif tag_AlternateDefinition2
	  ((@ref).tag) = AnonymousEnum.T_STRING;
	#endif
	#if svalue_AlternateDefinition1
	  ((@ref).value.s) = lua_createstring(ref lua_strdup(ref field));
	#elif svalue_AlternateDefinition2
	  ((@ref).value.s) = lua_createstring(ref lua_strdup(ref field));
	#endif
	#if avalue_AlternateDefinition1
	  h = lua_hashdefine(((@object).value.a), @ref);
	#elif avalue_AlternateDefinition2
	  h = lua_hashdefine(((@object).value.a), @ref);
	#endif
	  if (h == null)
		  return 1;
	#if tag_AlternateDefinition1
	  if (((top-1).tag) == AnonymousEnum.T_MARK)
	#elif tag_AlternateDefinition2
	  if (((top-1).tag) == AnonymousEnum.T_MARK)
	#endif
		  return 1;
	  h = *(--top);
	 }
	 return 0;
	}


	//
	//** Store top of the stack at an array index. Return 1 on error, 0 on success.
	//
	#if lua_Object_AlternateDefinition1
	public static int lua_storeindexed(Object @object, float index)
	#elif lua_Object_AlternateDefinition2
	public static int lua_storeindexed(Object @object, float index)
	#endif
	{
	#if tag_AlternateDefinition1
	 if (((@object).tag) != AnonymousEnum.T_ARRAY)
	#elif tag_AlternateDefinition2
	 if (((@object).tag) != AnonymousEnum.T_ARRAY)
	#endif
	  return 1;
	 else
	 {
	  Object @ref = new Object();
	  Object h;
	#if tag_AlternateDefinition1
	  ((@ref).tag) = AnonymousEnum.T_NUMBER;
	#elif tag_AlternateDefinition2
	  ((@ref).tag) = AnonymousEnum.T_NUMBER;
	#endif
	#if nvalue_AlternateDefinition1
	  ((@ref).value.n) = index;
	#elif nvalue_AlternateDefinition2
	  ((@ref).value.n) = index;
	#endif
	#if avalue_AlternateDefinition1
	  h = lua_hashdefine(((@object).value.a), @ref);
	#elif avalue_AlternateDefinition2
	  h = lua_hashdefine(((@object).value.a), @ref);
	#endif
	  if (h == null)
		  return 1;
	#if tag_AlternateDefinition1
	  if (((top-1).tag) == AnonymousEnum.T_MARK)
	#elif tag_AlternateDefinition2
	  if (((top-1).tag) == AnonymousEnum.T_MARK)
	#endif
		  return 1;
	  h = *(--top);
	 }
	 return 0;
	}


	//
	//** Given an object handle, return if it is nil.
	//
	public static int lua_isnil(Object @object)
	{
	#if tag_AlternateDefinition1
	 return (@object != null && ((@object).tag) == AnonymousEnum.T_NIL);
	#elif tag_AlternateDefinition2
	 return (@object != null && ((@object).tag) == AnonymousEnum.T_NIL);
	#endif
	}

	//
	//** Given an object handle, return if it is a number one.
	//
	public static int lua_isnumber(Object @object)
	{
	#if tag_AlternateDefinition1
	 return (@object != null && ((@object).tag) == AnonymousEnum.T_NUMBER);
	#elif tag_AlternateDefinition2
	 return (@object != null && ((@object).tag) == AnonymousEnum.T_NUMBER);
	#endif
	}

	//
	//** Given an object handle, return if it is a string one.
	//
	public static int lua_isstring(Object @object)
	{
	#if tag_AlternateDefinition1
	 return (@object != null && ((@object).tag) == AnonymousEnum.T_STRING);
	#elif tag_AlternateDefinition2
	 return (@object != null && ((@object).tag) == AnonymousEnum.T_STRING);
	#endif
	}

	//
	//** Given an object handle, return if it is an array one.
	//
	public static int lua_istable(Object @object)
	{
	#if tag_AlternateDefinition1
	 return (@object != null && ((@object).tag) == AnonymousEnum.T_ARRAY);
	#elif tag_AlternateDefinition2
	 return (@object != null && ((@object).tag) == AnonymousEnum.T_ARRAY);
	#endif
	}

	//
	//** Given an object handle, return if it is a cfunction one.
	//
	public static int lua_iscfunction(Object @object)
	{
	#if tag_AlternateDefinition1
	 return (@object != null && ((@object).tag) == AnonymousEnum.T_CFUNCTION);
	#elif tag_AlternateDefinition2
	 return (@object != null && ((@object).tag) == AnonymousEnum.T_CFUNCTION);
	#endif
	}

	//
	//** Given an object handle, return if it is an user data one.
	//
	public static int lua_isuserdata(Object @object)
	{
	#if tag_AlternateDefinition1
	 return (@object != null && ((@object).tag) == AnonymousEnum.T_USERDATA);
	#elif tag_AlternateDefinition2
	 return (@object != null && ((@object).tag) == AnonymousEnum.T_USERDATA);
	#endif
	}
}

#define FIELDS_PER_FLUSH

#define Byte_AlternateDefinition1

#define Word_AlternateDefinition1

//C++ TO C# CONVERTER TODO TASK: Unions are not supported in C#.
//ORIGINAL LINE: typedef union
public struct CodeWord
{
//C++ TO C# CONVERTER NOTE: Classes must be named in C#, so the following class has been named AnonymousClass:
 public class AnonymousClass
 {
	 public sbyte c1;
	 public sbyte c2;
 }
 public AnonymousClass m = new AnonymousClass();
 public ushort w;
}

//C++ TO C# CONVERTER TODO TASK: Unions are not supported in C#.
//ORIGINAL LINE: typedef union
public struct CodeFloat
{
//C++ TO C# CONVERTER NOTE: Classes must be named in C#, so the following class has been named AnonymousClass2:
 public class AnonymousClass2
 {
	 public sbyte c1;
	 public sbyte c2;
	 public sbyte c3;
	 public sbyte c4;
 }
 public AnonymousClass2 m = new AnonymousClass2();
 public float f;
}

public enum OpCode: int
{
 PUSHNIL,
 PUSH0,
 PUSH1,
 PUSH2,
 PUSHBYTE,
 PUSHWORD,
 PUSHFLOAT,
 PUSHSTRING,
 PUSHLOCAL0,
 PUSHLOCAL1,
 PUSHLOCAL2,
 PUSHLOCAL3,
 PUSHLOCAL4,
 PUSHLOCAL5,
 PUSHLOCAL6,
 PUSHLOCAL7,
 PUSHLOCAL8,
 PUSHLOCAL9,
 PUSHLOCAL,
 PUSHGLOBAL,
 PUSHINDEXED,
 PUSHMARK,
 PUSHOBJECT,
 STORELOCAL0,
 STORELOCAL1,
 STORELOCAL2,
 STORELOCAL3,
 STORELOCAL4,
 STORELOCAL5,
 STORELOCAL6,
 STORELOCAL7,
 STORELOCAL8,
 STORELOCAL9,
 STORELOCAL,
 STOREGLOBAL,
 STOREINDEXED0,
 STOREINDEXED,
 STORELIST0,
 STORELIST,
 STORERECORD,
 ADJUST,
 CREATEARRAY,
 EQOP,
 LTOP,
 LEOP,
 ADDOP,
 SUBOP,
 MULTOP,
 DIVOP,
 CONCOP,
 MINUSOP,
 NOTOP,
 ONTJMP,
 ONFJMP,
 JMP,
 UPJMP,
 IFFJMP,
 IFFUPJMP,
 POP,
 CALLFUNC,
 RETCODE,
 HALT,
 SETFUNCTION,
 SETLINE,
 RESET
}

public enum Type: int
{
 T_MARK,
 T_NIL,
 T_NUMBER,
 T_STRING,
 T_ARRAY,
 T_FUNCTION,
 T_CFUNCTION,
 T_USERDATA
}

//C++ TO C# CONVERTER TODO TASK: Unions are not supported in C#.
//ORIGINAL LINE: typedef union
public struct Value
{
 public Cfunction f;
 public float n;
 public string s;
 public byte b;
 public Hash a;
 public IntPtr u;
}

public class Object
{
 public Type tag = new Type();
 public Value @value = new Value();
}

public class Symbol
{
 public string name;
 public Object @object = new Object();
}

// Macros to access structure members 
#define tag_AlternateDefinition1
//C++ TO C# CONVERTER NOTE: The following #define macro was replaced in-line:
//ORIGINAL LINE: #define tag(o) ((o)->tag)
#define tag
#define nvalue_AlternateDefinition1
//C++ TO C# CONVERTER NOTE: The following #define macro was replaced in-line:
//ORIGINAL LINE: #define nvalue(o) ((o)->value.n)
#define nvalue
#define svalue_AlternateDefinition1
//C++ TO C# CONVERTER NOTE: The following #define macro was replaced in-line:
//ORIGINAL LINE: #define svalue(o) ((o)->value.s)
#define svalue
#define bvalue_AlternateDefinition1
//C++ TO C# CONVERTER NOTE: The following #define macro was replaced in-line:
//ORIGINAL LINE: #define bvalue(o) ((o)->value.b)
#define bvalue
#define avalue_AlternateDefinition1
//C++ TO C# CONVERTER NOTE: The following #define macro was replaced in-line:
//ORIGINAL LINE: #define avalue(o) ((o)->value.a)
#define avalue
#define fvalue_AlternateDefinition1
//C++ TO C# CONVERTER NOTE: The following #define macro was replaced in-line:
//ORIGINAL LINE: #define fvalue(o) ((o)->value.f)
#define fvalue
#define uvalue_AlternateDefinition1
//C++ TO C# CONVERTER NOTE: The following #define macro was replaced in-line:
//ORIGINAL LINE: #define uvalue(o) ((o)->value.u)
#define uvalue

// Macros to access symbol table 
#define s_name_AlternateDefinition1
//C++ TO C# CONVERTER NOTE: The following #define macro was replaced in-line:
//ORIGINAL LINE: #define s_name(i) (lua_table[i].name)
#define s_name
#define s_object_AlternateDefinition1
//C++ TO C# CONVERTER NOTE: The following #define macro was replaced in-line:
//ORIGINAL LINE: #define s_object(i) (lua_table[i].object)
#define s_object
#if tag_AlternateDefinition1
#define s_tag_AlternateDefinition1
//C++ TO C# CONVERTER NOTE: The following #define macro was replaced in-line:
//ORIGINAL LINE: #define s_tag(i) (((&(lua_table[i].object))->tag))
#define s_tag
#elif tag_AlternateDefinition2
#define s_tag_AlternateDefinition2
//C++ TO C# CONVERTER NOTE: The following #define macro was replaced in-line:
//ORIGINAL LINE: #define s_tag(i) (((&(lua_table[i].object))->tag))
#define s_tag
#endif


