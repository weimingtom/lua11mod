public static class GlobalMembersIolib
{
	//
	//** iolib.c
	//** Input/output library to LUA
	//

	public static string rcs_iolib ="$Id: iolib.c,v 1.4 1994/04/25 20:11:23 celes Exp $";

	//C++ TO C# CONVERTER WARNING: The following #include directive was ignored:
	//#include <sys/stat.h>
	#if __GNUC__ && !__MINGW32__
	//C++ TO C# CONVERTER WARNING: The following #include directive was ignored:
	//#include <floatingpoint.h>
	#endif



	internal static FILE @in =null;
	internal static FILE @out =null;

	#if false
	///*http://stackoverflow.com/questions/7623735/error-initializer-element-is-not-constant/7623769*/
	//static void init_streams(void) __attribute__((constructor)); 
	//static void init_streams(void)
	//{
	//  in = stdin;
	//  out  = stdout;
	//}
	#endif

	//
	//** Open a file to read.
	//** LUA interface:
	//**			status = readfrom (filename)
	//** where:
	//**			status = 1 -> success
	//**			status = 0 -> error
	//
	internal static void io_readfrom()
	{
	 Object o = lua_getparam (1);
	 if (o == null) // restore standart input 
	 {
	  if (@in != stdin)
	  {
	   fclose (@in);
	   @in = stdin;
	  }
	  lua_pushnumber (1);
	 }
	 else
	 {
	  if (lua_isstring (o) == 0)
	  {
	   lua_error ("incorrect argument to function 'readfrom`");
	   lua_pushnumber (0);
	  }
	  else
	  {
	   FILE fp = fopen (lua_getstring(o),"r");
	   if (fp == null)
	   {
		lua_pushnumber (0);
	   }
	   else
	   {
		if (@in != stdin)
			fclose (@in);
		@in = fp;
		lua_pushnumber (1);
	   }
	  }
	 }
	}


	//
	//** Open a file to write.
	//** LUA interface:
	//**			status = writeto (filename)
	//** where:
	//**			status = 1 -> success
	//**			status = 0 -> error
	//
	internal static void io_writeto()
	{
	 Object o = lua_getparam (1);
	 if (o == null) // restore standart output 
	 {
	  if (@out != stdout)
	  {
	   fclose (@out);
	   @out = stdout;
	  }
	  lua_pushnumber (1);
	 }
	 else
	 {
	  if (lua_isstring (o) == 0)
	  {
	   lua_error ("incorrect argument to function 'writeto`");
	   lua_pushnumber (0);
	  }
	  else
	  {
	   FILE fp = fopen (lua_getstring(o),"w");
	   if (fp == null)
	   {
		lua_pushnumber (0);
	   }
	   else
	   {
		if (@out != stdout)
			fclose (@out);
		@out = fp;
		lua_pushnumber (1);
	   }
	  }
	 }
	}


	//
	//** Open a file to write appended.
	//** LUA interface:
	//**			status = appendto (filename)
	//** where:
	//**			status = 2 -> success (already exist)
	//**			status = 1 -> success (new file)
	//**			status = 0 -> error
	//
	internal static void io_appendto()
	{
	 Object o = lua_getparam (1);
	 if (o == null) // restore standart output 
	 {
	  if (@out != stdout)
	  {
	   fclose (@out);
	   @out = stdout;
	  }
	  lua_pushnumber (1);
	 }
	 else
	 {
	  if (lua_isstring (o) == 0)
	  {
	   lua_error ("incorrect argument to function 'appendto`");
	   lua_pushnumber (0);
	  }
	  else
	  {
	   int r;
	   FILE fp;
	   stat st = new stat();
	   if (stat(lua_getstring(o), st) == -1)
		   r = 1;
	   else
		   r = 2;
	   fp = fopen (lua_getstring(o),"a");
	   if (fp == null)
	   {
		lua_pushnumber (0);
	   }
	   else
	   {
		if (@out != stdout)
			fclose (@out);
		@out = fp;
		lua_pushnumber (r);
	   }
	  }
	 }
	}



	//
	//** Read a variable. On error put nil on stack.
	//** LUA interface:
	//**			variable = read ([format])
	//**
	//** O formato pode ter um dos seguintes especificadores:
	//**
	//**	s ou S -> para string
	//**	f ou F, g ou G, e ou E -> para reais
	//**	i ou I -> para inteiros
	//**
	//**	Estes especificadores podem vir seguidos de numero que representa
	//**	o numero de campos a serem lidos.
	//
	internal static void io_read()
	{
	 Object o = lua_getparam (1);
	 if (o == null || lua_isstring(o) == 0) // free format 
	 {
	  int c;
	  string s = new string(new char[256]);
	  while (char.IsWhiteSpace(c =fgetc(@in)))
	   ;
	  if (c == '\"')
	  {
	   int c;
	   int n =0;
	   while((c = fgetc(@in)) != '\"')
	   {
		if (c == EOF)
		{
		 lua_pushnil ();
		 return;
		}
		s = StringHelper.ChangeCharacter(s, n++, c);
	   }
	   s = s.Substring(0, n);
	  }
	  else if (c == '\'')
	  {
	   int c;
	   int n =0;
	   while((c = fgetc(@in)) != '\'')
	   {
		if (c == EOF)
		{
		 lua_pushnil ();
		 return;
		}
		s = StringHelper.ChangeCharacter(s, n++, c);
	   }
	   s = s.Substring(0, n);
	  }
	  else
	  {
	   string ptr;
	   double d;
	   ungetc (c, @in);
	   if (fscanf (@in, "%s", s) != 1)
	   {
		lua_pushnil ();
		return;
	   }
	   d = strtod (s, ref ptr);
	   if (!( ptr))
	   {
		lua_pushnumber (d);
		return;
	   }
	  }
	  lua_pushstring (ref s);
	  return;
	 }
	 else // formatted 
	 {
//C++ TO C# CONVERTER TODO TASK: Pointer arithmetic is detected on this variable, so pointers on this variable are left unchanged.
	  sbyte *e = lua_getstring(o);
	  sbyte t;
	  int m =0;
	  while (char.IsWhiteSpace(*e))
		  e++;
	  t = *e++;
	  while (char.IsDigit(*e))
	   m = m *10 + (*e++ - '0');

	  if (m > 0)
	  {
	   string f = new string(new char[80]);
	   string s = new string(new char[256]);
	   f = string.Format ("%{0:D}s", m);
	   if (fgets (s, m, @in) == null)
	   {
		lua_pushnil();
		return;
	   }
	   else
	   {
		if (s[s.Length-1] == '\n')
		 s = s.Substring(0, s.Length-1);
	   }
	   switch (char.ToLower(t))
	   {
		case 'i':
		{
		 int l;
		 sscanf (s, "%ld", l);
		 lua_pushnumber(l);
		}
		break;
		case 'f':
			case 'g':
				case 'e':
		{
		 float f;
		 sscanf (s, "%f", f);
		 lua_pushnumber(f);
		}
		break;
		default:
		 lua_pushstring(ref s);
		break;
	   }
	  }
	  else
	  {
	   switch (char.ToLower(t))
	   {
		case 'i':
		{
		 int l;
		 if (fscanf (@in, "%ld", l) == EOF)
		   lua_pushnil();
		   else
			   lua_pushnumber(l);
		}
		break;
		case 'f':
			case 'g':
				case 'e':
		{
		 float f;
		 if (fscanf (@in, "%f", f) == EOF)
		   lua_pushnil();
		   else
			   lua_pushnumber(f);
		}
		break;
		default:
		{
		 string s = new string(new char[256]);
		 if (fscanf (@in, "%s", s) == EOF)
		   lua_pushnil();
		   else
			   lua_pushstring(ref s);
		}
		break;
	   }
	  }
	 }
	}
//C++ TO C# CONVERTER NOTE: This was formerly a static local variable declaration (not allowed in C#):
private static string buffer = new string(new char[512]);
//C++ TO C# CONVERTER NOTE: This was formerly a static local variable declaration (not allowed in C#):
private static string f = new string(new char[80]);


	//
	//** Write a variable. On error put 0 on stack, otherwise put 1.
	//** LUA interface:
	//**			status = write (variable [,format])
	//**
	//** O formato pode ter um dos seguintes especificadores:
	//**
	//**	s ou S -> para string
	//**	f ou F, g ou G, e ou E -> para reais
	//**	i ou I -> para inteiros
	//**
	//**	Estes especificadores podem vir seguidos de:
	//**
	//**		[?][m][.n]
	//**
	//**	onde:
	//**		? -> indica justificacao
	//**			< = esquerda
	//**			| = centro
	//**			> = direita (default)
	//**		m -> numero maximo de campos (se exceder estoura)
	//**		n -> indica precisao para
	//**			reais -> numero de casas decimais
	//**			inteiros -> numero minimo de digitos
	//**			string -> nao se aplica
	//
	internal static string buildformat(ref string e, Object o)
	{
	//C++ TO C# CONVERTER NOTE: This static local variable declaration (not allowed in C#) has been moved just prior to the method:
	// static sbyte buffer[512];
	//C++ TO C# CONVERTER NOTE: This static local variable declaration (not allowed in C#) has been moved just prior to the method:
	// static sbyte f[80];
	 string @string = buffer[255];
	 sbyte t;
	 sbyte j = (sbyte)'r';
	 int m =0;
	 int n =0;
	 int l;
	 while (char.IsWhiteSpace( e))
		 e = e.Substring(1);
	 t = e + +;
	 if ( e == '<' || e == '|' || e == '>')
		 j = e + +;
	 while (char.IsDigit( e))
	  m = m *10 + ( e + + - '0');
	 e = e.Substring(1); // skip point 
	 while (char.IsDigit( e))
	  n = n *10 + ( e + + - '0');

	 f = "%%";
	 if (j == '<' || j == '|')
		 SimulateStringFunctions.StrChr(f,0) = "-";
	 if (m != 0)
		 SimulateStringFunctions.StrChr(f,0) = string.Format("{0:D}", m);
	 if (n != 0)
		 SimulateStringFunctions.StrChr(f,0) = string.Format(".{0:D}", n);
	 SimulateStringFunctions.StrChr(f,0) = string.Format("{0}", t);
	 switch (char.ToLower(t))
	 {
	  case 'i':
		  t = (sbyte)'i';
	   sprintf (@string, f, (int)lua_getnumber(o));
	  break;
	  case 'f':
		  case 'g':
			  case 'e':
				  t = (sbyte)'f';
	   sprintf (@string, f, (float)lua_getnumber(o));
	  break;
	  case 's':
		  t = (sbyte)'s';
	   sprintf (@string, f, lua_getstring(o));
	  break;
	  default:
		  return "";
	 }
	 l = @string.Length;
	 if (m!=0 && l>m)
	 {
	  int i;
	  for (i =0; i<m; i++)
	   @string[i] = '*';
	  @string[i] = 0;
	 }
	 else if (m!=0 && j =='|')
	 {
	  int i =l-1;
	  while (char.IsWhiteSpace(@string[i]))
		  i--;
	  @string -= (m-i) / 2;
	  i =0;
	  while (@string[i]==0)
		  @string[i++] = ' ';
	  @string[l] = 0;
	 }
	 return @string;
	}
	internal static void io_write()
	{
	 Object o1 = lua_getparam (1);
	 Object o2 = lua_getparam (2);
	 if (o1 == null) // new line 
	 {
	  fprintf (@out, "\n");
	  lua_pushnumber(1);
	 }
	 else if (o2 == null) // free format 
	 {
	  int status =0;
	  if (lua_isnumber(o1) != 0)
	   status = fprintf (@out, "%g", lua_getnumber(o1));
	  else if (lua_isstring(o1) != 0)
	   status = fprintf (@out, "%s", lua_getstring(o1));
	  lua_pushnumber(status);
	 }
	 else // formated 
	 {
	  if (lua_isstring(o2) == 0)
	  {
	   lua_error ("incorrect format to function `write'");
	   lua_pushnumber(0);
	   return;
	  }
	  lua_pushnumber(fprintf (@out, "%s", buildformat(ref lua_getstring(o2), o1)));
	 }
	}

	//
	//** Execute a executable program using "system".
	//** Return the result of execution.
	//
	public static void io_execute()
	{
	 Object o = lua_getparam (1);
	 if (o == null || lua_isstring (o) == 0)
	 {
	  lua_error ("incorrect argument to function 'execute`");
	  lua_pushnumber (0);
	 }
	 else
	 {
	  int res = system(lua_getstring(o));
	  lua_pushnumber (res);
	 }
	 return;
	}

	//
	//** Remove a file.
	//** On error put 0 on stack, otherwise put 1.
	//
	public static void io_remove()
	{
	 Object o = lua_getparam (1);
	 if (o == null || lua_isstring (o) == 0)
	 {
	  lua_error ("incorrect argument to function 'execute`");
	  lua_pushnumber (0);
	 }
	 else
	 {
	  if (remove(lua_getstring(o)) == 0)
	   lua_pushnumber (1);
	  else
	   lua_pushnumber (0);
	 }
	 return;
	}

	//
	//** Open io library
	//
	public static void iolib_open()
	{
	  @in = stdin;
	  @out = stdout;
	 (lua_pushcfunction(io_readfrom), lua_storeglobal("readfrom"));
	 (lua_pushcfunction(io_writeto), lua_storeglobal("writeto"));
	 (lua_pushcfunction(io_appendto), lua_storeglobal("appendto"));
	 (lua_pushcfunction(io_read), lua_storeglobal("read"));
	 (lua_pushcfunction(io_write), lua_storeglobal("write"));
	 (lua_pushcfunction(io_execute), lua_storeglobal("execute"));
	 (lua_pushcfunction(io_remove), lua_storeglobal("remove"));
	}
}

//----------------------------------------------------------------------------------------
//	Copyright ? 2006 - 2009 Tangible Software Solutions Inc.
//	This class can be used by anyone provided that the copyright notice remains intact.
//
//	This class provides the ability to simulate various classic C string functions
//	which don't have exact equivalents in the .NET Framework.
//----------------------------------------------------------------------------------------
internal static class SimulateStringFunctions
{
	//------------------------------------------------------------------------------------
	//	This method simulates the classic C string function 'isxdigit' (and 'iswxdigit').
	//------------------------------------------------------------------------------------
	internal static bool IsXDigit(char character)
	{
		if (char.IsDigit(character))
			return true;
		else if ("ABCDEFabcdef".IndexOf(character) > -1)
			return true;
		else
			return false;
	}

	//------------------------------------------------------------------------------------
	//	This method simulates the classic C string function 'strchr' (and 'wcschr').
	//------------------------------------------------------------------------------------
	internal static string StrChr(string stringtosearch, char chartofind)
	{
		int index = stringtosearch.IndexOf(chartofind);
		if (index > -1)
			return stringtosearch.Substring(index);
		else
			return null;
	}

	//------------------------------------------------------------------------------------
	//	This method simulates the classic C string function 'strrchr' (and 'wcsrchr').
	//------------------------------------------------------------------------------------
	internal static string StrRChr(string stringtosearch, char chartofind)
	{
		int index = stringtosearch.LastIndexOf(chartofind);
		if (index > -1)
			return stringtosearch.Substring(index);
		else
			return null;
	}

	//------------------------------------------------------------------------------------
	//	This method simulates the classic C string function 'strstr' (and 'wcsstr').
	//------------------------------------------------------------------------------------
	internal static string StrStr(string stringtosearch, string stringtofind)
	{
		int index = stringtosearch.IndexOf(stringtofind);
		if (index > -1)
			return stringtosearch.Substring(index);
		else
			return null;
	}

	//------------------------------------------------------------------------------------
	//	This method simulates the classic C string function 'strtok' (and 'wcstok').
	//	Note that the .NET string 'Split' method cannot be used to simulate 'strtok' since
	//	it doesn't allow changing the delimiters between each token retrieval.
	//------------------------------------------------------------------------------------
	private static string activestring;
	private static int activeposition;
	internal static string StrTok(string stringtotokenize, string delimiters)
	{
		if (stringtotokenize != null)
		{
			activestring = stringtotokenize;
			activeposition = -1;
		}

		//the stringtotokenize was never set:
		if (activestring == null)
			return null;

		//all tokens have already been extracted:
		if (activeposition == activestring.Length)
			return null;

		//bypass delimiters:
		activeposition++;
		while (activeposition < activestring.Length && delimiters.IndexOf(activestring[activeposition]) > -1)
		{
			activeposition++;
		}

		//only delimiters were left, so return null:
		if (activeposition == activestring.Length)
			return null;

		//get starting position of string to return:
		int startingposition = activeposition;

		//read until next delimiter:
		do
		{
			activeposition++;
		} while (activeposition < activestring.Length && delimiters.IndexOf(activestring[activeposition]) == -1);

		return activestring.Substring(startingposition, activeposition - startingposition);
	}
}
//----------------------------------------------------------------------------------------
//	Copyright ? 2006 - 2009 Tangible Software Solutions Inc.
//	This class can be used by anyone provided that the copyright notice remains intact.
//
//	This class provides miscellaneous helper methods for strings.
//----------------------------------------------------------------------------------------
internal static class StringHelper
{
	//------------------------------------------------------------------------------------
	//	This method allows replacing a single character in a string, to help convert
	//	C++ code where a single character in a character array is replaced.
	//------------------------------------------------------------------------------------
	internal static string ChangeCharacter(string sourcestring, int charindex, char changechar)
	{
		return (charindex > 0 ? sourcestring.Substring(0, charindex) : "")
			+ changechar.ToString() + (charindex < sourcestring.Length - 1 ? sourcestring.Substring(charindex + 1) : "");
	}
}