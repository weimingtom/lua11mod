public static class GlobalMembersLua
{
	//
	//** lua.c
	//** Linguagem para Usuarios de Aplicacao
	//

	public static string rcs_lua ="$Id: lua.c,v 1.1 1993/12/17 18:41:19 celes Exp $";


	//
	//** LUA - Linguagem para Usuarios de Aplicacao
	//** Grupo de Tecnologia em Computacao Grafica
	//** TeCGraf - PUC-Rio
	//** $Id: lua.h,v 1.1 1993/12/17 18:41:19 celes Exp $
	//


	#if ! lua_h
	#define lua_h

	public static delegate void lua_CFunction();
private delegate void fnDelegate(ref string s);
	#define lua_Object_AlternateDefinition1

	#define lua_register_AlternateDefinition1
	//C++ TO C# CONVERTER NOTE: The following #define macro was replaced in-line:
	//ORIGINAL LINE: #define lua_register(n,f) (lua_pushcfunction(f), lua_storeglobal(n))
	#define lua_register


//C++ TO C# CONVERTER TODO TASK: The implementation of the following method could not be found:
	//void lua_errorfunction(fnDelegate fn);
//C++ TO C# CONVERTER TODO TASK: The implementation of the following method could not be found:
	//void lua_error(ref string s);
//C++ TO C# CONVERTER TODO TASK: The implementation of the following method could not be found:
	//int lua_dofile(ref string filename);
//C++ TO C# CONVERTER TODO TASK: The implementation of the following method could not be found:
	//int lua_dostring(ref string string);
//C++ TO C# CONVERTER TODO TASK: The implementation of the following method could not be found:
	//int lua_call(ref string functionname, int nparam);

//C++ TO C# CONVERTER TODO TASK: The implementation of the following method could not be found:
	//Object lua_getparam(int number);
//C++ TO C# CONVERTER TODO TASK: The implementation of the following method could not be found:
	//float lua_getnumber(Object object);
//C++ TO C# CONVERTER TODO TASK: The implementation of the following method could not be found:
	//string lua_getstring(Object object);
//C++ TO C# CONVERTER TODO TASK: The implementation of the following method could not be found:
	//string lua_copystring(Object object);
//C++ TO C# CONVERTER TODO TASK: The implementation of the following method could not be found:
	//lua_CFunction lua_getcfunction(Object object);
//C++ TO C# CONVERTER TODO TASK: The implementation of the following method could not be found:
	//IntPtr lua_getuserdata(Object object);
//C++ TO C# CONVERTER TODO TASK: The implementation of the following method could not be found:
	//Object lua_getfield(Object object, ref string field);
//C++ TO C# CONVERTER TODO TASK: The implementation of the following method could not be found:
	//Object lua_getindexed(Object object, float index);
//C++ TO C# CONVERTER TODO TASK: The implementation of the following method could not be found:
	//Object lua_getglobal(ref string name);

//C++ TO C# CONVERTER TODO TASK: The implementation of the following method could not be found:
	//Object lua_pop();

//C++ TO C# CONVERTER TODO TASK: The implementation of the following method could not be found:
	//int lua_pushnil();
//C++ TO C# CONVERTER TODO TASK: The implementation of the following method could not be found:
	//int lua_pushnumber(float n);
//C++ TO C# CONVERTER TODO TASK: The implementation of the following method could not be found:
	//int lua_pushstring(ref string s);
//C++ TO C# CONVERTER TODO TASK: The implementation of the following method could not be found:
	//int lua_pushcfunction(lua_CFunction fn);
//C++ TO C# CONVERTER TODO TASK: The implementation of the following method could not be found:
	//int lua_pushuserdata(IntPtr u);
//C++ TO C# CONVERTER TODO TASK: The implementation of the following method could not be found:
	//int lua_pushobject(Object object);

//C++ TO C# CONVERTER TODO TASK: The implementation of the following method could not be found:
	//int lua_storeglobal(ref string name);
//C++ TO C# CONVERTER TODO TASK: The implementation of the following method could not be found:
	//int lua_storefield(Object object, ref string field);
//C++ TO C# CONVERTER TODO TASK: The implementation of the following method could not be found:
	//int lua_storeindexed(Object object, float index);

//C++ TO C# CONVERTER TODO TASK: The implementation of the following method could not be found:
	//int lua_isnil(Object object);
//C++ TO C# CONVERTER TODO TASK: The implementation of the following method could not be found:
	//int lua_isnumber(Object object);
//C++ TO C# CONVERTER TODO TASK: The implementation of the following method could not be found:
	//int lua_isstring(Object object);
//C++ TO C# CONVERTER TODO TASK: The implementation of the following method could not be found:
	//int lua_istable(Object object);
//C++ TO C# CONVERTER TODO TASK: The implementation of the following method could not be found:
	//int lua_iscfunction(Object object);
//C++ TO C# CONVERTER TODO TASK: The implementation of the following method could not be found:
	//int lua_isuserdata(Object object);

	#endif


	internal static int Main(int argc, ref string[] argv)
	{
	 int i;
	 if (0)
		 fprintf(stdout, "=================>iolib_open\n");
	 iolib_open ();
	 if (0)
		 fprintf(stdout, "=================>strlib_open\n");
	 strlib_open ();
	 if (0)
		 fprintf(stdout, "=================>mathlib_open\n");
	 mathlib_open ();
	 if (argc < 2)
	 {
	   string buffer = new string(new char[2048]);
	  if (0)
		  fprintf(stdout, "=================>lua_dostring\n");
	   while (gets(buffer) != 0)
		 lua_dostring(ref buffer);
	 }
	 else
	 {
	   if (0)
		   fprintf(stdout, "=================>lua_dofile\n");
	   for (i =1; i<argc; i++)
		lua_dofile (ref argv[i]);

	  }
	  return 0;
	}
}
