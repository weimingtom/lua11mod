public static class GlobalMembersMathlib
{
	//
	//** Math library to LUA
	//** TeCGraf - PUC-Rio
	//** $Id: mathlib.h,v 1.1 1993/12/17 18:41:19 celes Exp $
	//


	#if ! strlib_h

//C++ TO C# CONVERTER TODO TASK: The implementation of the following method could not be found:
	//void mathlib_open();

	#endif
}

