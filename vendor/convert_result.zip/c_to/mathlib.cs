using System;
public static class GlobalMembersMathlib
{
	//
	//** mathlib.c
	//** Mathematics library to LUA
	//

	public static string rcs_mathlib ="$Id: mathlib.c,v 1.1 1993/12/17 18:41:19 celes Exp $";



	//C++ TO C# CONVERTER NOTE: The following #define macro was replaced in-line:
	//ORIGINAL LINE: #define TODEGREE(a) ((a)*180.0/3.14159)
	#define TODEGREE
	//C++ TO C# CONVERTER NOTE: The following #define macro was replaced in-line:
	//ORIGINAL LINE: #define TORAD(a) ((a)*3.14159/180.0)
	#define TORAD

	internal static void math_abs()
	{
	 double d;
	#if lua_Object_AlternateDefinition1
	 Object o = lua_getparam (1);
	#elif lua_Object_AlternateDefinition2
	 Object o = lua_getparam (1);
	#endif
	 if (o == null)
	 {
		 lua_error ("too few arguments to function `abs'");
		 return;
	 }
	 if (lua_isnumber(o) == 0)
	 {
		 lua_error ("incorrect arguments to function `abs'");
		 return;
	 }
	 d = lua_getnumber(o);
	 if (d < 0)
		 d = -d;
	 lua_pushnumber (d);
	}


	internal static void math_sin()
	{
	 double d;
	#if lua_Object_AlternateDefinition1
	 Object o = lua_getparam (1);
	#elif lua_Object_AlternateDefinition2
	 Object o = lua_getparam (1);
	#endif
	 if (o == null)
	 {
		 lua_error ("too few arguments to function `sin'");
		 return;
	 }
	 if (lua_isnumber(o) == 0)
	 {
		 lua_error ("incorrect arguments to function `sin'");
		 return;
	 }
	 d = lua_getnumber(o);
	 lua_pushnumber (Math.Sin(((d)*3.14159/180.0)));
	}



	internal static void math_cos()
	{
	 double d;
	#if lua_Object_AlternateDefinition1
	 Object o = lua_getparam (1);
	#elif lua_Object_AlternateDefinition2
	 Object o = lua_getparam (1);
	#endif
	 if (o == null)
	 {
		 lua_error ("too few arguments to function `cos'");
		 return;
	 }
	 if (lua_isnumber(o) == 0)
	 {
		 lua_error ("incorrect arguments to function `cos'");
		 return;
	 }
	 d = lua_getnumber(o);
	 lua_pushnumber (Math.Cos(((d)*3.14159/180.0)));
	}



	internal static void math_tan()
	{
	 double d;
	#if lua_Object_AlternateDefinition1
	 Object o = lua_getparam (1);
	#elif lua_Object_AlternateDefinition2
	 Object o = lua_getparam (1);
	#endif
	 if (o == null)
	 {
		 lua_error ("too few arguments to function `tan'");
		 return;
	 }
	 if (lua_isnumber(o) == 0)
	 {
		 lua_error ("incorrect arguments to function `tan'");
		 return;
	 }
	 d = lua_getnumber(o);
	 lua_pushnumber (Math.Tan(((d)*3.14159/180.0)));
	}


	internal static void math_asin()
	{
	 double d;
	#if lua_Object_AlternateDefinition1
	 Object o = lua_getparam (1);
	#elif lua_Object_AlternateDefinition2
	 Object o = lua_getparam (1);
	#endif
	 if (o == null)
	 {
		 lua_error ("too few arguments to function `asin'");
		 return;
	 }
	 if (lua_isnumber(o) == 0)
	 {
		 lua_error ("incorrect arguments to function `asin'");
		 return;
	 }
	 d = lua_getnumber(o);
	 lua_pushnumber (((Math.Asin(d))*180.0/3.14159));
	}


	internal static void math_acos()
	{
	 double d;
	#if lua_Object_AlternateDefinition1
	 Object o = lua_getparam (1);
	#elif lua_Object_AlternateDefinition2
	 Object o = lua_getparam (1);
	#endif
	 if (o == null)
	 {
		 lua_error ("too few arguments to function `acos'");
		 return;
	 }
	 if (lua_isnumber(o) == 0)
	 {
		 lua_error ("incorrect arguments to function `acos'");
		 return;
	 }
	 d = lua_getnumber(o);
	 lua_pushnumber (((Math.Acos(d))*180.0/3.14159));
	}



	internal static void math_atan()
	{
	 double d;
	#if lua_Object_AlternateDefinition1
	 Object o = lua_getparam (1);
	#elif lua_Object_AlternateDefinition2
	 Object o = lua_getparam (1);
	#endif
	 if (o == null)
	 {
		 lua_error ("too few arguments to function `atan'");
		 return;
	 }
	 if (lua_isnumber(o) == 0)
	 {
		 lua_error ("incorrect arguments to function `atan'");
		 return;
	 }
	 d = lua_getnumber(o);
	 lua_pushnumber (((Math.Atan(d))*180.0/3.14159));
	}


	internal static void math_ceil()
	{
	 double d;
	#if lua_Object_AlternateDefinition1
	 Object o = lua_getparam (1);
	#elif lua_Object_AlternateDefinition2
	 Object o = lua_getparam (1);
	#endif
	 if (o == null)
	 {
		 lua_error ("too few arguments to function `ceil'");
		 return;
	 }
	 if (lua_isnumber(o) == 0)
	 {
		 lua_error ("incorrect arguments to function `ceil'");
		 return;
	 }
	 d = lua_getnumber(o);
	 lua_pushnumber (Math.Ceiling(d));
	}


	internal static void math_floor()
	{
	 double d;
	#if lua_Object_AlternateDefinition1
	 Object o = lua_getparam (1);
	#elif lua_Object_AlternateDefinition2
	 Object o = lua_getparam (1);
	#endif
	 if (o == null)
	 {
		 lua_error ("too few arguments to function `floor'");
		 return;
	 }
	 if (lua_isnumber(o) == 0)
	 {
		 lua_error ("incorrect arguments to function `floor'");
		 return;
	 }
	 d = lua_getnumber(o);
	 lua_pushnumber (Math.Floor(d));
	}

	internal static void math_mod()
	{
	 int d1;
	 int d2;
	#if lua_Object_AlternateDefinition1
	 Object o1 = lua_getparam (1);
	#elif lua_Object_AlternateDefinition2
	 Object o1 = lua_getparam (1);
	#endif
	#if lua_Object_AlternateDefinition1
	 Object o2 = lua_getparam (2);
	#elif lua_Object_AlternateDefinition2
	 Object o2 = lua_getparam (2);
	#endif
	 if (lua_isnumber(o1) == 0 || lua_isnumber(o2) == 0)
	 {
		 lua_error ("incorrect arguments to function `mod'");
		 return;
	 }
	 d1 = (int) lua_getnumber(o1);
	 d2 = (int) lua_getnumber(o2);
	 lua_pushnumber (d1%d2);
	}


	internal static void math_sqrt()
	{
	 double d;
	#if lua_Object_AlternateDefinition1
	 Object o = lua_getparam (1);
	#elif lua_Object_AlternateDefinition2
	 Object o = lua_getparam (1);
	#endif
	 if (o == null)
	 {
		 lua_error ("too few arguments to function `sqrt'");
		 return;
	 }
	 if (lua_isnumber(o) == 0)
	 {
		 lua_error ("incorrect arguments to function `sqrt'");
		 return;
	 }
	 d = lua_getnumber(o);
	 lua_pushnumber (Math.Sqrt(d));
	}

	internal static void math_pow()
	{
	 double d1;
	 double d2;
	#if lua_Object_AlternateDefinition1
	 Object o1 = lua_getparam (1);
	#elif lua_Object_AlternateDefinition2
	 Object o1 = lua_getparam (1);
	#endif
	#if lua_Object_AlternateDefinition1
	 Object o2 = lua_getparam (2);
	#elif lua_Object_AlternateDefinition2
	 Object o2 = lua_getparam (2);
	#endif
	 if (lua_isnumber(o1) == 0 || lua_isnumber(o2) == 0)
	 {
		 lua_error ("incorrect arguments to function `pow'");
		 return;
	 }
	 d1 = lua_getnumber(o1);
	 d2 = lua_getnumber(o2);
	 lua_pushnumber (Math.Pow(d1,d2));
	}

	internal static void math_min()
	{
	 int i =1;
	 double d;
	 double dmin;
	#if lua_Object_AlternateDefinition1
	 Object o;
	#elif lua_Object_AlternateDefinition2
	 Object o;
	#endif
	 if ((o = lua_getparam(i++)) == null)
	 {
		 lua_error ("too few arguments to function `min'");
		 return;
	 }
	 if (lua_isnumber(o) == 0)
	 {
		 lua_error ("incorrect arguments to function `min'");
		 return;
	 }
	 dmin = lua_getnumber (o);
	 while ((o = lua_getparam(i++)) != null)
	 {
	  if (lua_isnumber(o) == 0)
	  {
		  lua_error ("incorrect arguments to function `min'");
		  return;
	  }
	  d = lua_getnumber (o);
	  if (d < dmin)
		  dmin = d;
	 }
	 lua_pushnumber (dmin);
	}


	internal static void math_max()
	{
	 int i =1;
	 double d;
	 double dmax;
	#if lua_Object_AlternateDefinition1
	 Object o;
	#elif lua_Object_AlternateDefinition2
	 Object o;
	#endif
	 if ((o = lua_getparam(i++)) == null)
	 {
		 lua_error ("too few arguments to function `max'");
		 return;
	 }
	 if (lua_isnumber(o) == 0)
	 {
		 lua_error ("incorrect arguments to function `max'");
		 return;
	 }
	 dmax = lua_getnumber (o);
	 while ((o = lua_getparam(i++)) != null)
	 {
	  if (lua_isnumber(o) == 0)
	  {
		  lua_error ("incorrect arguments to function `max'");
		  return;
	  }
	  d = lua_getnumber (o);
	  if (d > dmax)
		  dmax = d;
	 }
	 lua_pushnumber (dmax);
	}



	//
	//** Open math library
	//
	public static void mathlib_open()
	{
	#if lua_register_AlternateDefinition1
	 (lua_pushcfunction(math_abs), lua_storeglobal("abs"));
	#elif lua_register_AlternateDefinition2
	 (lua_pushcfunction(math_abs), lua_storeglobal("abs"));
	#endif
	#if lua_register_AlternateDefinition1
	 (lua_pushcfunction(math_sin), lua_storeglobal("sin"));
	#elif lua_register_AlternateDefinition2
	 (lua_pushcfunction(math_sin), lua_storeglobal("sin"));
	#endif
	#if lua_register_AlternateDefinition1
	 (lua_pushcfunction(math_cos), lua_storeglobal("cos"));
	#elif lua_register_AlternateDefinition2
	 (lua_pushcfunction(math_cos), lua_storeglobal("cos"));
	#endif
	#if lua_register_AlternateDefinition1
	 (lua_pushcfunction(math_tan), lua_storeglobal("tan"));
	#elif lua_register_AlternateDefinition2
	 (lua_pushcfunction(math_tan), lua_storeglobal("tan"));
	#endif
	#if lua_register_AlternateDefinition1
	 (lua_pushcfunction(math_asin), lua_storeglobal("asin"));
	#elif lua_register_AlternateDefinition2
	 (lua_pushcfunction(math_asin), lua_storeglobal("asin"));
	#endif
	#if lua_register_AlternateDefinition1
	 (lua_pushcfunction(math_acos), lua_storeglobal("acos"));
	#elif lua_register_AlternateDefinition2
	 (lua_pushcfunction(math_acos), lua_storeglobal("acos"));
	#endif
	#if lua_register_AlternateDefinition1
	 (lua_pushcfunction(math_atan), lua_storeglobal("atan"));
	#elif lua_register_AlternateDefinition2
	 (lua_pushcfunction(math_atan), lua_storeglobal("atan"));
	#endif
	#if lua_register_AlternateDefinition1
	 (lua_pushcfunction(math_ceil), lua_storeglobal("ceil"));
	#elif lua_register_AlternateDefinition2
	 (lua_pushcfunction(math_ceil), lua_storeglobal("ceil"));
	#endif
	#if lua_register_AlternateDefinition1
	 (lua_pushcfunction(math_floor), lua_storeglobal("floor"));
	#elif lua_register_AlternateDefinition2
	 (lua_pushcfunction(math_floor), lua_storeglobal("floor"));
	#endif
	#if lua_register_AlternateDefinition1
	 (lua_pushcfunction(math_mod), lua_storeglobal("mod"));
	#elif lua_register_AlternateDefinition2
	 (lua_pushcfunction(math_mod), lua_storeglobal("mod"));
	#endif
	#if lua_register_AlternateDefinition1
	 (lua_pushcfunction(math_sqrt), lua_storeglobal("sqrt"));
	#elif lua_register_AlternateDefinition2
	 (lua_pushcfunction(math_sqrt), lua_storeglobal("sqrt"));
	#endif
	#if lua_register_AlternateDefinition1
	 (lua_pushcfunction(math_pow), lua_storeglobal("pow"));
	#elif lua_register_AlternateDefinition2
	 (lua_pushcfunction(math_pow), lua_storeglobal("pow"));
	#endif
	#if lua_register_AlternateDefinition1
	 (lua_pushcfunction(math_min), lua_storeglobal("min"));
	#elif lua_register_AlternateDefinition2
	 (lua_pushcfunction(math_min), lua_storeglobal("min"));
	#endif
	#if lua_register_AlternateDefinition1
	 (lua_pushcfunction(math_max), lua_storeglobal("max"));
	#elif lua_register_AlternateDefinition2
	 (lua_pushcfunction(math_max), lua_storeglobal("max"));
	#endif
	}
}
