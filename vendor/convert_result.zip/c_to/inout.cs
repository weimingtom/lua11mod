public static class GlobalMembersInout
{
	//
	//** inout.c
	//** Provide function to realise the input/output function and debugger 
	//** facilities.
	//

	public static string rcs_inout ="$Id: inout.c,v 1.2 1993/12/22 21:15:16 roberto Exp $";


	//
	//** $Id: inout.h,v 1.1 1993/12/17 18:41:19 celes Exp $
	//


	#if ! inout_h
	#define inout_h

//C++ TO C# CONVERTER NOTE: 'extern' variable declarations are not required in C#:
	//extern int lua_linenumber;
//C++ TO C# CONVERTER NOTE: 'extern' variable declarations are not required in C#:
	//extern int lua_debug;
//C++ TO C# CONVERTER NOTE: 'extern' variable declarations are not required in C#:
	//extern int lua_debugline;

//
//** Function to open a file to be input unit. 
//** Return 0 on success or 1 on error.
//

	public static int lua_openfile(ref string fn)
	{
	   if (0)
		   fprintf(stdout, "=============>lua_openfile %s\n", fn);
	 lua_linenumber = 1;
	 lua_setinput (fileinput);
	 if (0)
		 fprintf(stdout, "=============>lua_openfile 2 %s\n", fn);
	 fp = fopen (fn, "r");
	 if (0)
		 fprintf(stdout, "=============>lua_openfile 3 %s\n", fn);
	 if (fp == null)
		 return 1;
	 if (0)
		 fprintf(stdout, "=============>lua_openfile 4 %s\n", fn);
	 if (lua_addfile (ref fn) != 0)
		 return 1;
	 if (0)
		 fprintf(stdout, "=============>lua_openfile 5 %s\n", fn);
	 return 0;
	}

//
//** Function to close an opened file
//
	public static void lua_closefile()
	{
	 if (fp != null)
	 {
	  lua_delfile();
	  fclose (fp);
	  fp = null;
	 }
	}

//
//** Function to open a string to be input unit
//
	public static int lua_openstring(ref string s)
	{
	 lua_linenumber = 1;
	 lua_setinput (stringinput);
	 st = s;
	 {
	  string sn = new string(new char[64]);
//C++ TO C# CONVERTER TODO TASK: C# does not allow setting maximum string width in format specifiers:
//ORIGINAL LINE: sprintf (sn, "String: %10.10s...", s);
	  sn = string.Format ("String: {0,10}...", s);
	  if (lua_addfile (ref sn) != 0)
		  return 1;
	 }
	 return 0;
	}

//
//** Function to close an opened string
//
	public static void lua_closestring()
	{
	 lua_delfile();
	}

//
//** Called to execute  SETFUNCTION opcode, this function pushs a function into
//** function stack. Return 0 on success or 1 on error.
//
	public static int lua_pushfunction(int file, int function)
	{
	 if (nfuncstack >= DefineConstantsInout.MAXFUNCSTACK-1)
	 {
	  lua_error ("function stack overflow");
	  return 1;
	 }
	 funcstack[nfuncstack].file = file;
	 funcstack[nfuncstack].function = function;
	 nfuncstack++;
	 return 0;
	}

//
//** Called to execute  RESET opcode, this function pops a function from 
//** function stack.
//
	public static void lua_popfunction()
	{
	 nfuncstack--;
	}

//
//** Report bug building a message and sending it to lua_error function.
//
	public static void lua_reportbug(ref string s)
	{
	 string msg = new string(new char[1024]);
	 msg = s;
	 if (lua_debugline != 0)
	 {
	  int i;
	  if (nfuncstack > 0)
	  {
	   SimulateStringFunctions.StrChr(msg,0) = string.Format ("\n\tin statement begining at line {0:D} in function \"{1}\" of file \"{2}\"", lua_debugline, (lua_table[funcstack[nfuncstack-1].function].name), lua_file[funcstack[nfuncstack-1].file]);
	   SimulateStringFunctions.StrChr(msg,0) = "\n\tactive stack\n";
	   for (i =nfuncstack-1; i>=0; i--)
		SimulateStringFunctions.StrChr(msg,0) = string.Format ("\t-> function \"{0}\" of file \"{1}\"\n", (lua_table[funcstack[i].function].name), lua_file[funcstack[i].file]);
	  }
	  else
	  {
	   SimulateStringFunctions.StrChr(msg,0) = string.Format ("\n\tin statement begining at line {0:D} of file \"{1}\"", lua_debugline, lua_filename());
	  }
	 }
	 lua_error (ref msg);
	}

	#endif


	// Exported variables 
	public static int lua_linenumber;
	public static int lua_debug;
	public static int lua_debugline;

	// Internal variables 
	#if ! MAXFUNCSTACK
	#define MAXFUNCSTACK
	#endif
	public static AnonymousClass[] funcstack = new AnonymousClass[DefineConstantsInout.MAXFUNCSTACK];
	internal static int nfuncstack =0;

	internal static FILE fp;
	internal static string st;
	internal delegate static void usererrorDelegate(ref string s);
	public static usererrorDelegate usererror;
private delegate void fnDelegate(ref string s);

	//
	//** Function to set user function to handle errors.
	//
	public static void lua_errorfunction(fnDelegate fn)
	{
	 usererror = fn;
	}

	//
	//** Function to get the next character from the input file
	//
	internal static int fileinput()
	{
	 int c = fgetc (fp);
	   if (0)
		   fprintf(stdout, "=============>fileinput %c\n", c);
	 return (c == EOF ? 0 : c);
	}

	//
	//** Function to get the next character from the input string
	//
	internal static int stringinput()
	{
	 st = st.Substring(1);
	 return (*(st-1));
	}

	//
	//** Call user function to handle error messages, if registred. Or report error
	//** using standard function (fprintf).
	//
	public static void lua_error(ref string s)
	{
	 if (usererror != null)
		 usererror (s);
	 else
		 fprintf (stderr, "lua: %s\n", s);
	}
}
//C++ TO C# CONVERTER NOTE: Classes must be named in C#, so the following class has been named AnonymousClass:
public static class AnonymousClass
{
	public int file;
	public int function;
}


//----------------------------------------------------------------------------------------
//	Copyright ? 2006 - 2009 Tangible Software Solutions Inc.
//	This class can be used by anyone provided that the copyright notice remains intact.
//
//	This class provides the ability to simulate various classic C string functions
//	which don't have exact equivalents in the .NET Framework.
//----------------------------------------------------------------------------------------
internal static class SimulateStringFunctions
{
	//------------------------------------------------------------------------------------
	//	This method simulates the classic C string function 'isxdigit' (and 'iswxdigit').
	//------------------------------------------------------------------------------------
	internal static bool IsXDigit(char character)
	{
		if (char.IsDigit(character))
			return true;
		else if ("ABCDEFabcdef".IndexOf(character) > -1)
			return true;
		else
			return false;
	}

	//------------------------------------------------------------------------------------
	//	This method simulates the classic C string function 'strchr' (and 'wcschr').
	//------------------------------------------------------------------------------------
	internal static string StrChr(string stringtosearch, char chartofind)
	{
		int index = stringtosearch.IndexOf(chartofind);
		if (index > -1)
			return stringtosearch.Substring(index);
		else
			return null;
	}

	//------------------------------------------------------------------------------------
	//	This method simulates the classic C string function 'strrchr' (and 'wcsrchr').
	//------------------------------------------------------------------------------------
	internal static string StrRChr(string stringtosearch, char chartofind)
	{
		int index = stringtosearch.LastIndexOf(chartofind);
		if (index > -1)
			return stringtosearch.Substring(index);
		else
			return null;
	}

	//------------------------------------------------------------------------------------
	//	This method simulates the classic C string function 'strstr' (and 'wcsstr').
	//------------------------------------------------------------------------------------
	internal static string StrStr(string stringtosearch, string stringtofind)
	{
		int index = stringtosearch.IndexOf(stringtofind);
		if (index > -1)
			return stringtosearch.Substring(index);
		else
			return null;
	}

	//------------------------------------------------------------------------------------
	//	This method simulates the classic C string function 'strtok' (and 'wcstok').
	//	Note that the .NET string 'Split' method cannot be used to simulate 'strtok' since
	//	it doesn't allow changing the delimiters between each token retrieval.
	//------------------------------------------------------------------------------------
	private static string activestring;
	private static int activeposition;
	internal static string StrTok(string stringtotokenize, string delimiters)
	{
		if (stringtotokenize != null)
		{
			activestring = stringtotokenize;
			activeposition = -1;
		}

		//the stringtotokenize was never set:
		if (activestring == null)
			return null;

		//all tokens have already been extracted:
		if (activeposition == activestring.Length)
			return null;

		//bypass delimiters:
		activeposition++;
		while (activeposition < activestring.Length && delimiters.IndexOf(activestring[activeposition]) > -1)
		{
			activeposition++;
		}

		//only delimiters were left, so return null:
		if (activeposition == activestring.Length)
			return null;

		//get starting position of string to return:
		int startingposition = activeposition;

		//read until next delimiter:
		do
		{
			activeposition++;
		} while (activeposition < activestring.Length && delimiters.IndexOf(activestring[activeposition]) == -1);

		return activestring.Substring(startingposition, activeposition - startingposition);
	}
}