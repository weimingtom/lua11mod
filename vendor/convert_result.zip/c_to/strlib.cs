using System;
public static class GlobalMembersStrlib
{
	//
	//** strlib.c
	//** String library to LUA
	//

	public static string rcs_strlib ="$Id: strlib.c,v 1.2 1994/03/28 15:14:02 celes Exp $";





	//
	//** Return the position of the first caracter of a substring into a string
	//** LUA interface:
	//**			n = strfind (string, substring)
	//
	internal static void str_find()
	{
	 string s1;
	 string s2;
	 string f;
	#if lua_Object_AlternateDefinition1
	 Object o1 = lua_getparam (1);
	#elif lua_Object_AlternateDefinition2
	 Object o1 = lua_getparam (1);
	#endif
	#if lua_Object_AlternateDefinition1
	 Object o2 = lua_getparam (2);
	#elif lua_Object_AlternateDefinition2
	 Object o2 = lua_getparam (2);
	#endif
	 if (lua_isstring(o1) == 0 || lua_isstring(o2) == 0)
	 {
		 lua_error ("incorrect arguments to function `strfind'");
		 return;
	 }
	 s1 = lua_getstring(o1);
	 s2 = lua_getstring(o2);
	 f = SimulateStringFunctions.StrStr(s1,s2);
	 if (f != null)
	  lua_pushnumber (f-s1.Substring(1));
	 else
	  lua_pushnil();
	}

	//
	//** Return the string length
	//** LUA interface:
	//**			n = strlen (string)
	//
	internal static void str_len()
	{
	#if lua_Object_AlternateDefinition1
	 Object o = lua_getparam (1);
	#elif lua_Object_AlternateDefinition2
	 Object o = lua_getparam (1);
	#endif
	 if (lua_isstring(o) == 0)
	 {
		 lua_error ("incorrect arguments to function `strlen'");
		 return;
	 }
	 lua_pushnumber(Convert.ToString(lua_getstring(o)).Length);
	}


	//
	//** Return the substring of a string, from start to end
	//** LUA interface:
	//**			substring = strsub (string, start, end)
	//
	internal static void str_sub()
	{
	 int start;
	 int end;
	 string s;
	#if lua_Object_AlternateDefinition1
	 Object o1 = lua_getparam (1);
	#elif lua_Object_AlternateDefinition2
	 Object o1 = lua_getparam (1);
	#endif
	#if lua_Object_AlternateDefinition1
	 Object o2 = lua_getparam (2);
	#elif lua_Object_AlternateDefinition2
	 Object o2 = lua_getparam (2);
	#endif
	#if lua_Object_AlternateDefinition1
	 Object o3 = lua_getparam (3);
	#elif lua_Object_AlternateDefinition2
	 Object o3 = lua_getparam (3);
	#endif
	 if (lua_isstring(o1) == 0 || lua_isnumber(o2) == 0)
	 {
		 lua_error ("incorrect arguments to function `strsub'");
		 return;
	 }
	 if (o3 != null && lua_isnumber(o3) == 0)
	 {
		 lua_error ("incorrect third argument to function `strsub'");
		 return;
	 }
	 s = lua_copystring(o1);
	 start = lua_getnumber (o2);
	 end = o3 == null ? s.Length : lua_getnumber (o3);
	 if (end < start || start < 1 || end > s.Length)
	  lua_pushstring("");
	 else
	 {
	  s = s.Substring(0, end);
	  lua_pushstring (ref s[start-1]);
	 }
//C++ TO C# CONVERTER TODO TASK: The memory management function 'free' has no equivalent in C#:
	 free (s);
	}

	//
	//** Convert a string to lower case.
	//** LUA interface:
	//**			lowercase = strlower (string)
	//
	internal static void str_lower()
	{
	 string s;
	 string c;
	#if lua_Object_AlternateDefinition1
	 Object o = lua_getparam (1);
	#elif lua_Object_AlternateDefinition2
	 Object o = lua_getparam (1);
	#endif
	 if (lua_isstring(o) == 0)
	 {
		 lua_error ("incorrect arguments to function `strlower'");
		 return;
	 }
	 c = s = lua_getstring(o);
	 while ( c != 0)
	 {
	  c = char.ToLower( c);
	  c = c.Substring(1);
	 }
	 lua_pushstring(ref s);
//C++ TO C# CONVERTER TODO TASK: The memory management function 'free' has no equivalent in C#:
	 free(s);
	}


	//
	//** Convert a string to upper case.
	//** LUA interface:
	//**			uppercase = strupper (string)
	//
	internal static void str_upper()
	{
	 string s;
	 string c;
	#if lua_Object_AlternateDefinition1
	 Object o = lua_getparam (1);
	#elif lua_Object_AlternateDefinition2
	 Object o = lua_getparam (1);
	#endif
	 if (lua_isstring(o) == 0)
	 {
		 lua_error ("incorrect arguments to function `strlower'");
		 return;
	 }
	 c = s = lua_getstring(o);
	 while ( c != 0)
	 {
	  c = char.ToUpper( c);
	  c = c.Substring(1);
	 }
	 lua_pushstring(ref s);
//C++ TO C# CONVERTER TODO TASK: The memory management function 'free' has no equivalent in C#:
	 free(s);
	}


	//
	//** Open string library
	//
	public static void strlib_open()
	{
	#if lua_register_AlternateDefinition1
	 (lua_pushcfunction(str_find), lua_storeglobal("strfind"));
	#elif lua_register_AlternateDefinition2
	 (lua_pushcfunction(str_find), lua_storeglobal("strfind"));
	#endif
	#if lua_register_AlternateDefinition1
	 (lua_pushcfunction(str_len), lua_storeglobal("strlen"));
	#elif lua_register_AlternateDefinition2
	 (lua_pushcfunction(str_len), lua_storeglobal("strlen"));
	#endif
	#if lua_register_AlternateDefinition1
	 (lua_pushcfunction(str_sub), lua_storeglobal("strsub"));
	#elif lua_register_AlternateDefinition2
	 (lua_pushcfunction(str_sub), lua_storeglobal("strsub"));
	#endif
	#if lua_register_AlternateDefinition1
	 (lua_pushcfunction(str_lower), lua_storeglobal("strlower"));
	#elif lua_register_AlternateDefinition2
	 (lua_pushcfunction(str_lower), lua_storeglobal("strlower"));
	#endif
	#if lua_register_AlternateDefinition1
	 (lua_pushcfunction(str_upper), lua_storeglobal("strupper"));
	#elif lua_register_AlternateDefinition2
	 (lua_pushcfunction(str_upper), lua_storeglobal("strupper"));
	#endif
	}
}

//----------------------------------------------------------------------------------------
//	Copyright ? 2006 - 2009 Tangible Software Solutions Inc.
//	This class can be used by anyone provided that the copyright notice remains intact.
//
//	This class provides the ability to simulate various classic C string functions
//	which don't have exact equivalents in the .NET Framework.
//----------------------------------------------------------------------------------------
internal static class SimulateStringFunctions
{
	//------------------------------------------------------------------------------------
	//	This method simulates the classic C string function 'isxdigit' (and 'iswxdigit').
	//------------------------------------------------------------------------------------
	internal static bool IsXDigit(char character)
	{
		if (char.IsDigit(character))
			return true;
		else if ("ABCDEFabcdef".IndexOf(character) > -1)
			return true;
		else
			return false;
	}

	//------------------------------------------------------------------------------------
	//	This method simulates the classic C string function 'strchr' (and 'wcschr').
	//------------------------------------------------------------------------------------
	internal static string StrChr(string stringtosearch, char chartofind)
	{
		int index = stringtosearch.IndexOf(chartofind);
		if (index > -1)
			return stringtosearch.Substring(index);
		else
			return null;
	}

	//------------------------------------------------------------------------------------
	//	This method simulates the classic C string function 'strrchr' (and 'wcsrchr').
	//------------------------------------------------------------------------------------
	internal static string StrRChr(string stringtosearch, char chartofind)
	{
		int index = stringtosearch.LastIndexOf(chartofind);
		if (index > -1)
			return stringtosearch.Substring(index);
		else
			return null;
	}

	//------------------------------------------------------------------------------------
	//	This method simulates the classic C string function 'strstr' (and 'wcsstr').
	//------------------------------------------------------------------------------------
	internal static string StrStr(string stringtosearch, string stringtofind)
	{
		int index = stringtosearch.IndexOf(stringtofind);
		if (index > -1)
			return stringtosearch.Substring(index);
		else
			return null;
	}

	//------------------------------------------------------------------------------------
	//	This method simulates the classic C string function 'strtok' (and 'wcstok').
	//	Note that the .NET string 'Split' method cannot be used to simulate 'strtok' since
	//	it doesn't allow changing the delimiters between each token retrieval.
	//------------------------------------------------------------------------------------
	private static string activestring;
	private static int activeposition;
	internal static string StrTok(string stringtotokenize, string delimiters)
	{
		if (stringtotokenize != null)
		{
			activestring = stringtotokenize;
			activeposition = -1;
		}

		//the stringtotokenize was never set:
		if (activestring == null)
			return null;

		//all tokens have already been extracted:
		if (activeposition == activestring.Length)
			return null;

		//bypass delimiters:
		activeposition++;
		while (activeposition < activestring.Length && delimiters.IndexOf(activestring[activeposition]) > -1)
		{
			activeposition++;
		}

		//only delimiters were left, so return null:
		if (activeposition == activestring.Length)
			return null;

		//get starting position of string to return:
		int startingposition = activeposition;

		//read until next delimiter:
		do
		{
			activeposition++;
		} while (activeposition < activestring.Length && delimiters.IndexOf(activestring[activeposition]) == -1);

		return activestring.Substring(startingposition, activeposition - startingposition);
	}
}