public static class GlobalMembersTable
{
	//
	//** table.c
	//** Module to control static tables
	//

	public static string rcs_table ="$Id: table.c,v 2.1 1994/04/20 22:07:57 celes Exp $";



	//
	//** Module to control static tables
	//** TeCGraf - PUC-Rio
	//** $Id: table.h,v 2.1 1994/04/20 22:07:57 celes Exp $
	//

	#if ! table_h
	#define table_h

//C++ TO C# CONVERTER NOTE: 'extern' variable declarations are not required in C#:
	//extern Symbol *lua_table;
	#if Word_AlternateDefinition1
//C++ TO C# CONVERTER NOTE: 'extern' variable declarations are not required in C#:
	//extern ushort lua_ntable;
	#elif Word_AlternateDefinition2
//C++ TO C# CONVERTER NOTE: 'extern' variable declarations are not required in C#:
	//extern ushort lua_ntable;
	#endif

//C++ TO C# CONVERTER NOTE: 'extern' variable declarations are not required in C#:
	//extern sbyte **lua_constant;
	#if Word_AlternateDefinition1
//C++ TO C# CONVERTER NOTE: 'extern' variable declarations are not required in C#:
	//extern ushort lua_nconstant;
	#elif Word_AlternateDefinition2
//C++ TO C# CONVERTER NOTE: 'extern' variable declarations are not required in C#:
	//extern ushort lua_nconstant;
	#endif

//C++ TO C# CONVERTER NOTE: 'extern' variable declarations are not required in C#:
	//extern sbyte **lua_string;
	#if Word_AlternateDefinition1
//C++ TO C# CONVERTER NOTE: 'extern' variable declarations are not required in C#:
	//extern ushort lua_nstring;
	#elif Word_AlternateDefinition2
//C++ TO C# CONVERTER NOTE: 'extern' variable declarations are not required in C#:
	//extern ushort lua_nstring;
	#endif

//C++ TO C# CONVERTER NOTE: 'extern' variable declarations are not required in C#:
	//extern Hash **lua_array;
	#if Word_AlternateDefinition1
//C++ TO C# CONVERTER NOTE: 'extern' variable declarations are not required in C#:
	//extern ushort lua_narray;
	#elif Word_AlternateDefinition2
//C++ TO C# CONVERTER NOTE: 'extern' variable declarations are not required in C#:
	//extern ushort lua_narray;
	#endif

//C++ TO C# CONVERTER NOTE: 'extern' variable declarations are not required in C#:
	//extern sbyte *lua_file[];
//C++ TO C# CONVERTER NOTE: 'extern' variable declarations are not required in C#:
	//extern int lua_nfile;

	#if Word_AlternateDefinition1
//C++ TO C# CONVERTER NOTE: 'extern' variable declarations are not required in C#:
	//extern ushort lua_block;
	#elif Word_AlternateDefinition2
//C++ TO C# CONVERTER NOTE: 'extern' variable declarations are not required in C#:
	//extern ushort lua_block;
	#endif
	#if Word_AlternateDefinition1
//C++ TO C# CONVERTER NOTE: 'extern' variable declarations are not required in C#:
	//extern ushort lua_nentity;
	#elif Word_AlternateDefinition2
//C++ TO C# CONVERTER NOTE: 'extern' variable declarations are not required in C#:
	//extern ushort lua_nentity;
	#endif

//
//** Given a name, search it at symbol table and return its index. If not
//** found, allocate at end of table, checking oveflow and return its index.
//** On error, return -1.
//



	public static int lua_findsymbol(sbyte[] s)
	{
	 List l;
	 List p;
	 for (p =null, l =searchlist; l!=null; p =l, l =l.next)
	  if ((s[0] ==l.s.name[0]&&string.Compare(s+1,l.s.name.Substring(1))==0))
	  {
	   if (p!=null)
	   {
		p.next = l.next;
		l.next = searchlist;
		searchlist = l;
	   }
	   return (l.s-lua_table);
	  }

	 if (lua_ntable >= DefineConstantsTable.MAXSYMBOL-1)
	 {
	  lua_error ("symbol table overflow");
	  return -1;
	 }
	#if s_name_AlternateDefinition1
	 (lua_table[lua_ntable].name) = s;
	#elif s_name_AlternateDefinition2
	 (lua_table[lua_ntable].name) = s;
	#endif
	#if s_name_AlternateDefinition1
	 if ((lua_table[lua_ntable].name) == null)
	#elif s_name_AlternateDefinition2
	 if ((lua_table[lua_ntable].name) == null)
	#endif
	 {
	  lua_error ("not enough memory");
	  return -1;
	 }
	#if s_tag_AlternateDefinition1
	 ((((lua_table[lua_ntable].object)).tag)) = AnonymousEnum.T_NIL;
	#elif s_tag_AlternateDefinition2
	 ((((lua_table[lua_ntable].object)).tag)) = AnonymousEnum.T_NIL;
	#elif s_tag_AlternateDefinition3
	 ((((lua_table[lua_ntable].object)).tag)) = AnonymousEnum.T_NIL;
	#endif
//C++ TO C# CONVERTER TODO TASK: The memory management function 'malloc' has no equivalent in C#:
	 p = malloc(sizeof( p));
	 p.s = lua_table+lua_ntable;
	 p.next = searchlist;
	 searchlist = p;

	 return lua_ntable++;
	}

//
//** Given a constant string, search it at constant table and return its index.
//** If not found, allocate at end of the table, checking oveflow and return 
//** its index.
//**
//** For each allocation, the function allocate a extra char to be used to
//** mark used string (it's necessary to deal with constant and string 
//** uniformily). The function store at the table the second position allocated,
//** that represents the beginning of the real string. On error, return -1.
//** 
//
	public static int lua_findconstant(sbyte[] s)
	{
	 int i;
	 for (i =0; i<lua_nconstant; i++)
	  if ((s[0] ==lua_constant[i][0]&&string.Compare(s+1,lua_constant[i]+1)==0))
	   return i;
	 if (lua_nconstant >= DefineConstantsTable.MAXCONSTANT-1)
	 {
	  lua_error ("lua: constant string table overflow");
	  return -1;
	 }
	 {
//C++ TO C# CONVERTER TODO TASK: Pointer arithmetic is detected on this variable, so pointers on this variable are left unchanged.
//C++ TO C# CONVERTER TODO TASK: The memory management function 'calloc' has no equivalent in C#:
	  sbyte *c = calloc(s.Length+2,sizeof(sbyte));
	  c++; // create mark space
	  lua_constant[lua_nconstant++] = strcpy(c,s);
	 }
	 return (lua_nconstant-1);
	}

//
//** Traverse symbol table objects
//
private delegate void fnDelegate(Object NamelessParameter);
	public static void lua_travsymbol(fnDelegate fn)
	{
	 int i;
	 for (i =0; i<lua_ntable; i++)
	#if s_object_AlternateDefinition1
	  fn(ref (lua_table[i].object));
	#elif s_object_AlternateDefinition2
	  fn(ref (lua_table[i].object));
	#endif
	}

//
//** Mark an object if it is a string or a unmarked array.
//
	public static void lua_markobject(Object o)
	{
	#if tag_AlternateDefinition1
	 if (((o).tag) == AnonymousEnum.T_STRING)
	#elif tag_AlternateDefinition2
	 if (((o).tag) == AnonymousEnum.T_STRING)
	#endif
	#if svalue_AlternateDefinition1
	  (*((((o).value.s))-1)) = 1;
	#elif svalue_AlternateDefinition2
	  (*((((o).value.s))-1)) = 1;
	#endif
	#if tag_AlternateDefinition1
	 else if (((o).tag) == AnonymousEnum.T_ARRAY)
	#elif tag_AlternateDefinition2
	 else if (((o).tag) == AnonymousEnum.T_ARRAY)
	#endif
	#if avalue_AlternateDefinition1
	   lua_hashmark (((o).value.a));
	#elif avalue_AlternateDefinition2
	   lua_hashmark (((o).value.a));
	#endif
	}

//
//** Garbage collection. 
//** Delete all unused strings and arrays.
//
	public static void lua_pack()
	{
	 // mark stack strings
	 lua_travstack(lua_markobject);

	 // mark symbol table strings
	 lua_travsymbol(lua_markobject);

	 lua_stringcollector();
	 lua_hashcollector();

	 lua_nentity = 0; // reset counter
	}

//
//** Garbage collection to atrings.
//** Delete all unmarked strings
//
	public static void lua_stringcollector()
	{
	 int i;
	 int j;
	 for (i =j =0; i<lua_nstring; i++)
	  if ((*((lua_string[i])-1)) == 1)
	  {
	   lua_string[j++] = lua_string[i];
	   (*((lua_string[i])-1)) = 0;
	  }
	  else
	  {
//C++ TO C# CONVERTER TODO TASK: The memory management function 'free' has no equivalent in C#:
	   free (lua_string[i]-1);
	  }
	 lua_nstring = j;
	}

//
//** Allocate a new string at string table. The given string is already 
//** allocated with mark space and the function puts it at the end of the
//** table, checking overflow, and returns its own pointer, or NULL on error.
//
	public static string lua_createstring(sbyte[] s)
	{
	 int i;
	 if (s == null)
		 return null;

	 for (i =0; i<lua_nstring; i++)
	  if ((s[0] ==lua_string[i][0]&&string.Compare(s+1,lua_string[i]+1)==0))
	  {
//C++ TO C# CONVERTER TODO TASK: The memory management function 'free' has no equivalent in C#:
	   free(s-1);
	   return lua_string[i];
	  }

	 if (lua_nentity == lua_block || lua_nstring >= DefineConstantsTable.MAXSTRING-1)
	 {
	  lua_pack ();
	  if (lua_nstring >= DefineConstantsTable.MAXSTRING-1)
	  {
	   lua_error ("string table overflow");
	   return null;
	  }
	 }
	 lua_string[lua_nstring++] = s;
	 lua_nentity++;
	 return s;
	}

//
//** Add a file name at file table, checking overflow. This function also set
//** the external variable "lua_filename" with the function filename set.
//** Return 0 on success or 1 on error.
//
	public static int lua_addfile(ref string fn)
	{
	 if (lua_nfile >= DefineConstantsTable.MAXFILE-1)
	 {
	  lua_error ("too many files");
	  return 1;
	 }
	 if ((lua_file[lua_nfile++] =  fn) == null)
	 {
	  lua_error ("not enough memory");
	  return 1;
	 }
	 return 0;
	}

//
//** Delete a file from file stack
//
	public static int lua_delfile()
	{
	 lua_nfile--;
	 return 1;
	}

//
//** Return the last file name set.
//
	public static string lua_filename()
	{
	 return lua_file[lua_nfile-1];
	}

//
//** Internal function: return next global variable
//
	public static void lua_nextvar()
	{
	 int index;
	 Object o = lua_getparam (1);
	 if (o == null)
	 {
		 lua_error ("too few arguments to function `nextvar'");
		 return;
	 }
	 if (lua_getparam (2) != null)
	 {
		 lua_error ("too many arguments to function `nextvar'");
		 return;
	 }
	#if tag_AlternateDefinition1
	 if (((o).tag) == AnonymousEnum.T_NIL)
	#elif tag_AlternateDefinition2
	 if (((o).tag) == AnonymousEnum.T_NIL)
	#endif
	 {
	  index = 0;
	 }
	#if tag_AlternateDefinition1
	 else if (((o).tag) != AnonymousEnum.T_STRING)
	#elif tag_AlternateDefinition2
	 else if (((o).tag) != AnonymousEnum.T_STRING)
	#endif
	 {
	  lua_error ("incorrect argument to function `nextvar'");
	  return;
	 }
	 else
	 {
	  for (index =0; index<lua_ntable; index++)
	#if svalue_AlternateDefinition1
	#if s_name_AlternateDefinition1
	   if (((lua_table[index].name)[0]==((o).value.s)[0]&&string.Compare((lua_table[index].name)+1,((o).value.s)+1)==0))
	#elif s_name_AlternateDefinition2
	   if (((lua_table[index].name)[0]==((o).value.s)[0]&&string.Compare((lua_table[index].name)+1,((o).value.s)+1)==0))
	#endif
	#elif svalue_AlternateDefinition2
	#if s_name_AlternateDefinition1
	   if (((lua_table[index].name)[0]==((o).value.s)[0]&&string.Compare((lua_table[index].name)+1,((o).value.s)+1)==0))
	#elif s_name_AlternateDefinition2
	   if (((lua_table[index].name)[0]==((o).value.s)[0]&&string.Compare((lua_table[index].name)+1,((o).value.s)+1)==0))
	#endif
	#endif
		   break;
	  if (index == lua_ntable)
	  {
	   lua_error ("name not found in function `nextvar'");
	   return;
	  }
	  index++;
	#if tag_AlternateDefinition1
	#if s_object_AlternateDefinition1
	  while (index < lua_ntable && (((lua_table[index].object)).tag) == AnonymousEnum.T_NIL)
	#elif s_object_AlternateDefinition2
	  while (index < lua_ntable && (((lua_table[index].object)).tag) == AnonymousEnum.T_NIL)
	#endif
	#elif tag_AlternateDefinition2
	#if s_object_AlternateDefinition1
	  while (index < lua_ntable && (((lua_table[index].object)).tag) == AnonymousEnum.T_NIL)
	#elif s_object_AlternateDefinition2
	  while (index < lua_ntable && (((lua_table[index].object)).tag) == AnonymousEnum.T_NIL)
	#endif
	#endif
		  index++;

	  if (index == lua_ntable)
	  {
	   lua_pushnil();
	   lua_pushnil();
	   return;
	  }
	 }
	 {
	  Object name = new Object();
	#if tag_AlternateDefinition1
	  ((name).tag) = AnonymousEnum.T_STRING;
	#elif tag_AlternateDefinition2
	  ((name).tag) = AnonymousEnum.T_STRING;
	#endif
	#if svalue_AlternateDefinition1
	#if s_name_AlternateDefinition1
	  ((name).value.s) = lua_createstring(ref lua_strdup(ref (lua_table[index].name)));
	#elif s_name_AlternateDefinition2
	  ((name).value.s) = lua_createstring(ref lua_strdup(ref (lua_table[index].name)));
	#endif
	#elif svalue_AlternateDefinition2
	#if s_name_AlternateDefinition1
	  ((name).value.s) = lua_createstring(ref lua_strdup(ref (lua_table[index].name)));
	#elif s_name_AlternateDefinition2
	  ((name).value.s) = lua_createstring(ref lua_strdup(ref (lua_table[index].name)));
	#endif
	#endif
	  if (lua_pushobject (name) != 0)
		  return;
	#if s_object_AlternateDefinition1
	  if (lua_pushobject ((lua_table[index].object)) != 0)
	#elif s_object_AlternateDefinition2
	  if (lua_pushobject ((lua_table[index].object)) != 0)
	#endif
		  return;
	 }
	}

	public static int lua_findenclosedconstant(sbyte[] s)
	{
	 int i;
	 int j;
	 int l =s.Length;
//C++ TO C# CONVERTER TODO TASK: The memory management function 'calloc' has no equivalent in C#:
	 sbyte[] c = calloc (l, sizeof(sbyte)); // make a copy

	 c++; // create mark space

	 // introduce scape characters
	 for (i =1,j =0; i<l-1; i++)
	 {
	  if (s[i] == '\\')
	  {
	   switch (s[++i])
	   {
		case 'n':
			c[j++] = '\n';
			break;
		case 't':
			c[j++] = '\t';
			break;
		case 'r':
			c[j++] = '\r';
			break;
		default :
			c[j++] = '\\';
			c[j++] = c[i];
			break;
	   }
	  }
	  else
	   c[j++] = s[i];
	 }
	 c[j++] = 0;

	 for (i =0; i<lua_nconstant; i++)
	  if ((c[0] ==lua_constant[i][0]&&string.Compare(c+1,lua_constant[i]+1)==0))
	  {
//C++ TO C# CONVERTER TODO TASK: The memory management function 'free' has no equivalent in C#:
	   free (c-1);
	   return i;
	  }
	 if (lua_nconstant >= DefineConstantsTable.MAXCONSTANT-1)
	 {
	  lua_error ("lua: constant string table overflow");
	  return -1;
	 }
	 lua_constant[lua_nconstant++] = c;
	 return (lua_nconstant-1);
	}

	#endif


	//C++ TO C# CONVERTER NOTE: The following #define macro was replaced in-line:
	//ORIGINAL LINE: #define streq(s1,s2) (s1[0]==s2[0]&&strcmp(s1+1,s2+1)==0)
	#define streq

	#if ! MAXSYMBOL
	#define MAXSYMBOL
	#endif
	internal static Symbol[] tablebuffer = { new Symbol("type", {AnonymousEnum.T_CFUNCTION,{lua_type, "tonumber", {AnonymousEnum.T_CFUNCTION,{lua_obj2number, "next", {AnonymousEnum.T_CFUNCTION,{lua_next, "nextvar", {AnonymousEnum.T_CFUNCTION,{lua_nextvar, "print", {AnonymousEnum.T_CFUNCTION,{lua_print, "dofile", {AnonymousEnum.T_CFUNCTION,{lua_internaldofile, "dostring", {AnonymousEnum.T_CFUNCTION,{lua_internaldostring) };
	public static Symbol lua_table =tablebuffer;
	#if Word_AlternateDefinition1
	public static ushort lua_ntable =7;
	#elif Word_AlternateDefinition2
	public static ushort lua_ntable =7;
	#endif

	internal static struct List o6= new struct(tablebuffer+6, 0);
	internal static struct List o5= new struct(tablebuffer+5, o6);
	internal static struct List o4= new struct(tablebuffer+4, o5);
	internal static struct List o3= new struct(tablebuffer+3, o4);
	internal static struct List o2= new struct(tablebuffer+2, o3);
	internal static struct List o1= new struct(tablebuffer+1, o2);
	internal static struct List o0= new struct(tablebuffer+0, o1);
	internal static struct List *searchlist=&o0;

	#if ! MAXCONSTANT
	#define MAXCONSTANT
	#endif
	// pre-defined constants need garbage collection extra byte  
	internal static string tm = " mark";
	internal static string ti = " nil";
	internal static string tn = " number";
	internal static string ts = " string";
	internal static string tt = " table";
	internal static string tf = " function";
	internal static string tc = " cfunction";
	internal static string tu = " userdata";
	internal static string[] constantbuffer = {tm.Substring(1), ti.Substring(1), tn.Substring(1), ts.Substring(1), tt.Substring(1), tf.Substring(1), tc.Substring(1), tu.Substring(1) };
	public static string[] lua_constant = constantbuffer;
	#if Word_AlternateDefinition1
	public static ushort lua_nconstant =AnonymousEnum.T_USERDATA+1;
	#elif Word_AlternateDefinition2
	public static ushort lua_nconstant =AnonymousEnum.T_USERDATA+1;
	#endif

	#if ! MAXSTRING
	#define MAXSTRING
	#endif
	internal static string[] stringbuffer = new string[DefineConstantsTable.MAXSTRING];
	public static string[] lua_string = stringbuffer;
	#if Word_AlternateDefinition1
	public static ushort lua_nstring =0;
	#elif Word_AlternateDefinition2
	public static ushort lua_nstring =0;
	#endif

	#define MAXFILE
	public static string[] lua_file = new string[DefineConstantsTable.MAXFILE];
	public static int lua_nfile;


	//C++ TO C# CONVERTER NOTE: The following #define macro was replaced in-line:
	//ORIGINAL LINE: #define markstring(s) (*((s)-1))
	#define markstring


	// Variables to controll garbage collection 
	#if Word_AlternateDefinition1
	public static ushort lua_block =10;
	#elif Word_AlternateDefinition2
	public static ushort lua_block =10;
	#endif
	#if Word_AlternateDefinition1
	public static ushort lua_nentity;
	#elif Word_AlternateDefinition2
	public static ushort lua_nentity;
	#endif
}

public class List
{
 public Symbol s;
 public GlobalMembersTable.List next;
}

