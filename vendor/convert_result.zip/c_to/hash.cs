public static class GlobalMembersHash
{
	//
	//** hash.c
	//** hash manager for lua
	//** Luiz Henrique de Figueiredo - 17 Aug 90
	//

	public static string rcs_hash ="$Id: hash.c,v 2.1 1994/04/20 22:07:57 celes Exp $";
}



internal sealed class DefineConstantsHash
{
	public const int STACKGAP = 128;
	public const int FIELDS_PER_FLUSH = 40;
	public const int ARRAYBLOCK = 50;
	public const int MAXFUNCSTACK = 32;
	public const int MAXSTACK = 256;
	public const int MAXSYMBOL = 512;
	public const int MAXCONSTANT = 256;
	public const int MAXSTRING = 512;
	public const int MAXFILE = 20;
	public const int LISTING = 0;
	public const int GAPCODE = 50;
	public const int MAXVAR = 32;
	public const int WRONGTOKEN = 257;
	public const int NIL = 258;
	public const int IF = 259;
	public const int THEN = 260;
	public const int ELSE = 261;
	public const int ELSEIF = 262;
	public const int WHILE = 263;
	public const int DO = 264;
	public const int REPEAT = 265;
	public const int UNTIL = 266;
	public const int END = 267;
	public const int RETURN = 268;
	public const int LOCAL = 269;
	public const int NUMBER = 270;
	public const int FUNCTION = 271;
	public const int STRING = 272;
	public const int NAME = 273;
	public const int DEBUG = 274;
	public const int AND = 275;
	public const int OR = 276;
	public const int NE = 277;
	public const int LE = 278;
	public const int GE = 279;
	public const int CONC = 280;
	public const int UNARY = 281;
	public const int NOT = 282;
	public const int YYMAXDEPTH = 150;
	public const int YYERRCODE = 256;
	public const int YYNPROD = 103;
	public const int YYLAST = 364;
#if YYDEBUG_AlternateDefinition1
	public const int YYDEBUG = 0;
#elif YYDEBUG_AlternateDefinition2
	public const int YYDEBUG = 1;
#endif
	public const string _POP_ = "Error recovery pops state %d, uncovers state %d\n";
}