using System;
public static class GlobalMembersLex
{
	public static string rcs_lex = "$Id: lex.c,v 2.1 1994/04/15 19:00:28 celes Exp $";
	//$Log: lex.c,v $
	// * Revision 2.1  1994/04/15  19:00:28  celes
	// * Retirar chamada da funcao lua_findsymbol associada a cada
	// * token NAME. A decisao de chamar lua_findsymbol ou lua_findconstant
	// * fica a cargo do modulo "lua.stx".
	// *
	// * Revision 1.3  1993/12/28  16:42:29  roberto
	// * "include"s de string.h e stdlib.h para evitar warnings
	// *
	// * Revision 1.2  1993/12/22  21:39:15  celes
	// * Tratamento do token $debug e $nodebug
	// *
	// * Revision 1.1  1993/12/22  21:15:16  roberto
	// * Initial revision
	// *


	//C++ TO C# CONVERTER WARNING: The following #include directive was ignored:
	//#include "y.tab.h"

	//C++ TO C# CONVERTER NOTE: The following #define macro was replaced in-line:
	//ORIGINAL LINE: #define next() { current = input(); }
	#define next
	//C++ TO C# CONVERTER NOTE: The following #define macro was replaced in-line:
	//ORIGINAL LINE: #define save(x) { *yytextLast++ = (x); }
	#define save
	//C++ TO C# CONVERTER NOTE: The following #define macro was replaced in-line:
	//ORIGINAL LINE: #define save_and_next() { { *yytextLast++ = (current); }; { current = input(); }; }
	#define save_and_next

	internal static int current;
	internal static string yytext = new string(new char[256]);
	internal static string yytextLast;

	internal static Input input = new Input();

	public static void lua_setinput(Input fn)
	{
	  current = ' ';
	  input = fn;
	}

	public static string lua_lasttext()
	{
	  yytextLast = 0;
	  return yytext;
	}
	  public static AnonymousClass[] reserved = { {"and", &}, {"do", DO}, {"else", ELSE}, {"elseif", ELSEIF}, {"end", END}, {"function", FUNCTION}, {"if", IF}, {"local", LOCAL}, {"nil", NIL}, {"not", NOT}, {"or", |}, {"repeat", REPEAT}, {"return", RETURN}, {"then", THEN}, {"until", UNTIL}, {"while", WHILE} };

	//C++ TO C# CONVERTER NOTE: The following #define macro was replaced in-line:
	//ORIGINAL LINE: #define RESERVEDSIZE (sizeof(reserved)/sizeof(reserved[0]))
	#define RESERVEDSIZE


	public static int findReserved(ref string name)
	{
	  int l = 0;
	//C++ TO C# CONVERTER WARNING: This 'sizeof' ratio was replaced with a direct reference to the array length:
	//ORIGINAL LINE: int h = RESERVEDSIZE - 1;
	  int h = reserved.Length - 1;
	  while (l <= h)
	  {
		int m = (l+h)/2;
		int comp = string.Compare(name, reserved[m].name);
		if (comp < 0)
		  h = m-1;
		else if (comp == 0)
		  return reserved[m].token;
		else
		  l = m+1;
	  }
	  return 0;
	}


	public static int yylex()
	{
	  while (1)
	  {
		yytextLast = yytext;
		switch (current)
		{
		  case '\n':
			  lua_linenumber++;
//C++ TO C# CONVERTER TODO TASK: C# does not allow fall-through from a non-empty 'case':
		  case ' ':
		  case '\t':
			{
				current = input();
			}
			continue;

		  case '$':
		{
			current = input();
		}
		while (char.IsLetterOrDigit(current) || current == '_')
			  {
				  {
					  yytextLast + += (current);
				  }
				  {
					  current = input();
				  }
			  }
			yytextLast = 0;
		if (string.Compare(yytext, "debug") == 0)
		{
		  yylval.vInt = 1;
		  return DEBUG;
			}
		else if (string.Compare(yytext, "nodebug") == 0)
		{
		  yylval.vInt = 0;
		  return DEBUG;
			}
		return WRONGTOKEN;

		  case '-':
			{
				{
					yytextLast + += (current);
				}
				{
					current = input();
				}
			}
			if (current != '-')
				return '-';
			do
			{
				{
					current = input();
				}
			} while (current != '\n' && current != 0);
			continue;

		  case '<':
			{
				{
					yytextLast + += (current);
				}
				{
					current = input();
				}
			}
			if (current != '=')
				return '<';
			else
			{
				{
					{
						yytextLast + += (current);
					}
					{
						current = input();
					}
				}
				return LE;
			}

		  case '>':
			{
				{
					yytextLast + += (current);
				}
				{
					current = input();
				}
			}
			if (current != '=')
				return '>';
			else
			{
				{
					{
						yytextLast + += (current);
					}
					{
						current = input();
					}
				}
				return GE;
			}

		  case '~':
			{
				{
					yytextLast + += (current);
				}
				{
					current = input();
				}
			}
			if (current != '=')
				return '~';
			else
			{
				{
					{
						yytextLast + += (current);
					}
					{
						current = input();
					}
				}
				return NE;
			}

		  case '"':
		  case '\'':
		  {
			int del = current;
			{
				current = input();
			}
			while (current != del)
			{
			  switch (current)
			  {
				case 0:
				case '\n':
				  return WRONGTOKEN;
				case '\\':
				  {
					  current = input();
				  }
				  switch (current)
				  {
					case 'n':
						{
							yytextLast + += ('\n');
						}
						{
							current = input();
						}
						break;
					case 't':
						{
							yytextLast + += ('\t');
						}
						{
							current = input();
						}
						break;
					case 'r':
						{
							yytextLast + += ('\r');
						}
						{
							current = input();
						}
						break;
					default :
						{
							yytextLast + += ('\\');
						}
						break;
				  }
				  break;
				default:
				  {
					  {
						  yytextLast + += (current);
					  }
					  {
						  current = input();
					  }
				  }
			  break;
			  }
			}
			{
				current = input();
			}
			yytextLast = 0;
			yylval.vWord = lua_findconstant (ref yytext);
			return STRING;
		  }

		  case 'a':
			  case 'b':
				  case 'c':
					  case 'd':
						  case 'e':
		  case 'f':
			  case 'g':
				  case 'h':
					  case 'i':
						  case 'j':
		  case 'k':
			  case 'l':
				  case 'm':
					  case 'n':
						  case 'o':
		  case 'p':
			  case 'q':
				  case 'r':
					  case 's':
						  case 't':
		  case 'u':
			  case 'v':
				  case 'w':
					  case 'x':
						  case 'y':
		  case 'z':
		  case 'A':
			  case 'B':
				  case 'C':
					  case 'D':
						  case 'E':
		  case 'F':
			  case 'G':
				  case 'H':
					  case 'I':
						  case 'J':
		  case 'K':
			  case 'L':
				  case 'M':
					  case 'N':
						  case 'O':
		  case 'P':
			  case 'Q':
				  case 'R':
					  case 'S':
						  case 'T':
		  case 'U':
			  case 'V':
				  case 'W':
					  case 'X':
						  case 'Y':
		  case 'Z':
		  case '_':
		  {
			int res;
			do
			{
				{
					{
						yytextLast + += (current);
					}
					{
						current = input();
					}
				}
			} while (char.IsLetterOrDigit(current) || current == '_');
			yytextLast = 0;
			res = findReserved(ref yytext);
			if (res != 0)
				return res;
			yylval.pChar = yytext;
			return NAME;
		  }

		  case '.':
			{
				{
					yytextLast + += (current);
				}
				{
					current = input();
				}
			}
			if (current == '.')
			{
			  {
				  {
					  yytextLast + += (current);
				  }
				  {
					  current = input();
				  }
			  }
			  return CONC;
			}
			else if (!char.IsDigit(current))
				return '.';
			// current is a digit: goes through to number 
			goto fraction;

		  case '0':
			  case '1':
				  case '2':
					  case '3':
						  case '4':
		  case '5':
			  case '6':
				  case '7':
					  case '8':
						  case '9':

			do
			{
				{
					{
						yytextLast + += (current);
					}
					{
						current = input();
					}
				}
			} while (char.IsDigit(current));
			if (current == '.')
				{
					{
						yytextLast + += (current);
					}
					{
						current = input();
					}
				}
	fraction:
	while (char.IsDigit(current))
		{
			{
				yytextLast + += (current);
			}
			{
				current = input();
			}
		}
			if (current == 'e' || current == 'E')
			{
			  {
				  {
					  yytextLast + += (current);
				  }
				  {
					  current = input();
				  }
			  }
			  if (current == '+' || current == '-')
				  {
					  {
						  yytextLast + += (current);
					  }
					  {
						  current = input();
					  }
				  }
			  if (!char.IsDigit(current))
				  return WRONGTOKEN;
			  do
			  {
				  {
					  {
						  yytextLast + += (current);
					  }
					  {
						  current = input();
					  }
				  }
			  } while (char.IsDigit(current));
			}
			yytextLast = 0;
			yylval.vFloat = Convert.ToDouble(yytext);
			return NUMBER;

		  default: // also end of file 
		  {
			{
				{
					yytextLast + += (current);
				}
				{
					current = input();
				}
			}
			return *yytext;
		  }
		}
	  }
	}
}


//C++ TO C# CONVERTER NOTE: Classes must be named in C#, so the following class has been named AnonymousClass:
public static class AnonymousClass
  {
	public string name;
	public int token;
  }

