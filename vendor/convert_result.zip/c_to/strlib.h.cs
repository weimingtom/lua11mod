public static class GlobalMembersStrlib
{
	//
	//** String library to LUA
	//** TeCGraf - PUC-Rio
	//** $Id: strlib.h,v 1.1 1993/12/17 18:41:19 celes Exp $
	//


	#if ! strlib_h

//C++ TO C# CONVERTER TODO TASK: The implementation of the following method could not be found:
	//void strlib_open();

	#endif
}

